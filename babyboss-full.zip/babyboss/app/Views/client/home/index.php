<?php
/**
 * @var array $featured @var array $options @var int $serviceCount
 * @var array $testimonials @var array $summary @var int $pointValue @var ?array $me
 */
?>
<section class="hero">
    <div class="wrap hero-grid">
        <div class="hero-copy">
            <h1>Tắm, tỉa lông và nghỉ dưỡng cho bé cưng, đúng giờ bạn hẹn.</h1>
            <p class="lead">Chọn dịch vụ, chọn giờ và theo dõi lịch ngay trên website. Sau mỗi lần spa, bé tích điểm để giảm giá cho lần sau.</p>
            <div class="hero-actions">
                <a class="btn btn-outline btn-lg" href="<?= e(url('services')) ?>">Xem <?= (int) $serviceCount ?> dịch vụ</a>
                <a class="btn btn-ghost btn-lg" href="<?= e(tel_href(shop('hotline'))) ?>"><?= icon('phone', 18) ?> Gọi <?= e(shop('hotline')) ?></a>
            </div>
            <?php if ($summary['count'] > 0): ?>
                <p class="proof">
                    <span class="stars" aria-hidden="true"><?= e(stars((int) round((float) $summary['avg']))) ?></span>
                    Khách chấm trung bình <b><?= e(rating_text($summary['avg'])) ?> trên 5</b> qua <?= (int) $summary['count'] ?> đánh giá.
                </p>
            <?php endif; ?>
        </div>

        <form class="quick" method="get" action="<?= e(BASE_URL . '/index.php') ?>">
            <i class="bubble q1" aria-hidden="true"></i><i class="bubble q2" aria-hidden="true"></i><i class="bubble q3" aria-hidden="true"></i>
            <input type="hidden" name="route" value="book">
            <h2>Đặt lịch nhanh</h2>
            <label class="field">
                <span>Dịch vụ</span>
                <select class="select" name="service" id="quickService">
                    <option value="" data-price="" data-duration="">Chọn dịch vụ</option>
                    <?php foreach ($options as $o): ?>
                        <option value="<?= (int) $o['id'] ?>" data-price="<?= (int) $o['price'] ?>" data-duration="<?= (int) $o['duration'] ?>"><?= e($o['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label class="field">
                <span>Ngày hẹn</span>
                <input class="input" type="date" name="date" min="<?= e(date('Y-m-d')) ?>">
            </label>
            <p class="quick-note" id="quickNote">Chọn dịch vụ để xem giá và thời gian thực hiện.</p>
            <button class="btn btn-primary btn-block btn-lg" type="submit">Tiếp tục đặt lịch</button>
        </form>
    </div>
</section>

<?php if ($featured): ?>
<section class="section">
    <div class="wrap">
        <div class="section-head">
            <div>
                <h2>Dịch vụ được đặt nhiều nhất</h2>
                <p class="muted">Giá và thời gian thực hiện được ghi rõ ở từng dịch vụ.</p>
            </div>
            <a class="link" href="<?= e(url('services')) ?>">Xem tất cả dịch vụ</a>
        </div>
        <div class="cards">
            <?php foreach ($featured as $s): partial('service_card', ['s' => $s]); endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<section class="section how">
    <div class="wrap how-grid">
        <div>
            <h2>Đặt lịch ở BabyBoss diễn ra thế nào</h2>
            <p class="muted">Bạn cần một tài khoản để lưu hồ sơ bé cưng và theo dõi lịch hẹn của mình.</p>
            <?php if (!$me): ?><a class="btn btn-primary" href="<?= e(url('register')) ?>">Tạo tài khoản</a><?php endif; ?>
        </div>
        <ol class="steps">
            <li><b>Thêm hồ sơ cho bé.</b> Tên, giống loài, cân nặng và ảnh đại diện giúp nhân viên chuẩn bị đúng cho từng bé.</li>
            <li><b>Chọn dịch vụ và giờ hẹn.</b> Lịch được gửi đi ở trạng thái "Chờ duyệt", nhân viên sẽ xác nhận trong giờ làm việc.</li>
            <li><b>Tích điểm sau mỗi lần spa.</b> Lịch hoàn thành được cộng điểm theo hạng thành viên. <?= e('1 điểm giảm ' . money($pointValue)) ?> cho lần đặt sau.</li>
        </ol>
    </div>
</section>

<?php if ($testimonials): ?>
<section class="section">
    <div class="wrap">
        <h2>Khách nói gì về BabyBoss</h2>
        <div class="quotes">
            <?php foreach ($testimonials as $t): ?>
                <figure class="quote">
                    <span class="stars" aria-label="<?= (int) $t['rating'] ?> trên 5 sao"><?= e(stars((int) $t['rating'])) ?></span>
                    <blockquote><?= e($t['comment']) ?></blockquote>
                    <figcaption><b><?= e(short_name($t['customer_name'])) ?></b> đã dùng dịch vụ <?= e($t['service_name']) ?></figcaption>
                </figure>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<section class="wrap">
    <div class="cta-band">
        <div>
            <h2>Cần tư vấn trước khi đặt lịch?</h2>
            <p>Gọi hotline hoặc nhắn tin, nhân viên sẽ trả lời trong giờ làm việc (<?= e(shop('hours')) ?>).</p>
        </div>
        <div class="cta-actions">
            <a class="btn btn-primary btn-lg" href="<?= e(tel_href(shop('hotline'))) ?>"><?= icon('phone', 18) ?> <?= e(shop('hotline')) ?></a>
            <a class="btn btn-light btn-lg" href="<?= e(url('contact')) ?>">Nhắn tin cho BabyBoss</a>
        </div>
    </div>
</section>
