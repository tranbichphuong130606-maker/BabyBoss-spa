<?php /** @var array $service @var array $summary @var array $reviews @var array $others */ ?>
<div class="wrap page">
    <nav class="crumbs" aria-label="Đường dẫn">
        <a href="<?= e(url('services')) ?>">Dịch vụ</a> <span aria-hidden="true">/</span> <span><?= e($service['name']) ?></span>
    </nav>

    <div class="detail">
        <div class="detail-art"><?= service_art($service) ?></div>
        <div class="detail-info">
            <h1><?= e($service['name']) ?></h1>
            <p class="rating-line">
                <?php if ($summary['count'] > 0): ?>
                    <span class="stars" aria-hidden="true"><?= e(stars((int) round((float) $summary['avg']))) ?></span>
                    <b><?= e(rating_text($summary['avg'])) ?> trên 5</b> từ <?= (int) $summary['count'] ?> đánh giá
                <?php else: ?>
                    <span class="muted">Chưa có đánh giá. Khách sẽ đánh giá sau khi dùng dịch vụ.</span>
                <?php endif; ?>
            </p>
            <dl class="facts-row">
                <div><dt>Giá</dt><dd class="price"><?= e(money($service['price'])) ?></dd></div>
                <div><dt>Thời gian thực hiện</dt><dd><?= e(duration_text((int) $service['duration'])) ?></dd></div>
            </dl>
            <div class="prose"><p><?= nl2br(e($service['description'] ?? '')) ?></p></div>
            <a class="btn btn-primary btn-lg" href="<?= e(url('book', ['service' => $service['id']])) ?>">Đặt lịch dịch vụ này</a>
        </div>
    </div>

    <section class="reviews">
        <h2>Đánh giá của khách</h2>
        <?php if ($reviews): ?>
            <ul class="review-list">
                <?php foreach ($reviews as $r): ?>
                    <li>
                        <div class="review-top">
                            <span class="stars" aria-label="<?= (int) $r['rating'] ?> trên 5 sao"><?= e(stars((int) $r['rating'])) ?></span>
                            <b><?= e(short_name($r['customer_name'])) ?></b>
                            <span class="muted small"><?= e(fmt_date($r['created_at'], 'd/m/Y')) ?></span>
                        </div>
                        <?php if (trim((string) $r['comment']) !== ''): ?><p><?= e($r['comment']) ?></p><?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php else: ?>
            <p class="muted">Dịch vụ này chưa có đánh giá nào.</p>
        <?php endif; ?>
    </section>

    <?php if ($others): ?>
    <section class="section tight">
        <div class="section-head"><h2>Dịch vụ khác</h2><a class="link" href="<?= e(url('services')) ?>">Xem tất cả</a></div>
        <div class="cards">
            <?php foreach ($others as $s): partial('service_card', ['s' => $s]); endforeach; ?>
        </div>
    </section>
    <?php endif; ?>
</div>
