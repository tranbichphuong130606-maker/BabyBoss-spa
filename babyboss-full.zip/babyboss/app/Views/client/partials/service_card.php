<?php /** @var array $s dịch vụ (có thể kèm avg_rating) */ ?>
<article class="svc-card">
    <?= service_art($s) ?>
    <div class="svc-body">
        <h3><a href="<?= e(url('services/' . $s['id'])) ?>"><?= e($s['name']) ?></a></h3>
        <p class="clamp"><?= e($s['description']) ?></p>
        <div class="svc-meta">
            <span class="price"><?= e(money($s['price'])) ?></span>
            <span class="muted small"><?= icon('clock', 14) ?> <?= e(duration_text((int) $s['duration'])) ?></span>
            <?php if (($s['avg_rating'] ?? null) !== null): ?>
                <span class="rating" title="Điểm đánh giá trung bình">★ <?= e(rating_text($s['avg_rating'])) ?></span>
            <?php endif; ?>
        </div>
    </div>
</article>
