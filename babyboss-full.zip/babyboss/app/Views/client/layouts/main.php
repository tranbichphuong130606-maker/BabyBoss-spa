<?php
/** @var string $content @var ?array $me @var array $flashes */
$active = $active ?? '';
$nav    = [['home', '', 'Trang chủ'], ['services', 'services', 'Dịch vụ'], ['about', 'about', 'Giới thiệu'], ['contact', 'contact', 'Liên hệ']];
?>
<!doctype html>
<html lang="vi">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= !empty($title) ? e($title) . ' – ' : '' ?><?= e(shop('name')) ?></title>
    <meta name="description" content="Spa, cắt tỉa lông và khách sạn cho chó mèo. Đặt lịch trực tuyến, tích điểm sau mỗi lần chăm sóc.">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Baloo+2:wght@600;700;800&amp;family=Be+Vietnam+Pro:wght@400;500;600;700&amp;display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= e(asset('css/base.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('css/site.css')) ?>">
</head>
<body class="site">
<a class="skip" href="#main">Bỏ qua phần điều hướng</a>

<header class="site-header">
    <div class="wrap bar">
        <a class="logo" href="<?= e(url()) ?>">
            <span class="brand-mark"><?= paw_icon(22) ?></span>
            <span class="logo-text">BabyBoss<small>Pet Spa</small></span>
        </a>
        <button class="menu-btn" id="menuBtn" type="button" aria-label="Mở menu" aria-expanded="false" aria-controls="siteMenu"><?= icon('menu', 22) ?></button>
        <div class="site-menu" id="siteMenu">
            <nav class="site-nav" aria-label="Điều hướng chính">
                <?php foreach ($nav as [$key, $route, $label]): ?>
                    <a class="<?= $active === $key ? 'active' : '' ?>" href="<?= e(url($route)) ?>"><?= e($label) ?></a>
                <?php endforeach; ?>
            </nav>
            <div class="head-actions">
                <a class="hotline" href="<?= e(tel_href(shop('hotline'))) ?>"><?= icon('phone', 16) ?> <?= e(shop('hotline')) ?></a>
                <?php if ($me): ?>
                    <?php if ($me['role'] !== 'admin'): ?>
                        <a class="btn btn-primary btn-sm" href="<?= e(url('book')) ?>">Đặt lịch</a>
                    <?php endif; ?>
                    <details class="usermenu">
                        <summary>
                            <span class="avatar sm"><?= e(initial($me['full_name'])) ?></span>
                            <span class="uname"><?= e(first_name($me['full_name'])) ?></span>
                            <?= icon('chevdown', 16) ?>
                        </summary>
                        <div class="menu">
                            <div class="menu-head"><b><?= e($me['full_name']) ?></b><span class="muted small"><?= number_format((int) $me['points'], 0, ',', '.') ?> điểm thưởng</span></div>
                            <?php if ($me['role'] === 'admin'): ?>
                                <a href="<?= e(admin_url('dashboard')) ?>"><?= icon('shield', 17) ?> Trang quản trị</a>
                            <?php else: ?>
                                <a href="<?= e(url('pets')) ?>"><?= icon('heart', 17) ?> Thú cưng của tôi</a>
                                <a href="<?= e(url('appointments')) ?>"><?= icon('calendar', 17) ?> Lịch hẹn của tôi</a>
                                <a href="<?= e(url('loyalty')) ?>"><?= icon('gift', 17) ?> Điểm thưởng</a>
                                <a href="<?= e(url('contact')) ?>#chat"><?= icon('message', 17) ?> Tin nhắn</a>
                            <?php endif; ?>
                            <hr>
                            <form method="post" action="<?= e(url('logout')) ?>">
                                <?= csrf_field() ?>
                                <button type="submit"><?= icon('logout', 17) ?> Đăng xuất</button>
                            </form>
                        </div>
                    </details>
                <?php else: ?>
                    <a class="btn btn-ghost btn-sm" href="<?= e(url('login')) ?>">Đăng nhập</a>
                    <a class="btn btn-primary btn-sm" href="<?= e(url('register')) ?>">Đăng ký</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</header>

<main id="main">
    <?php if ($flashes): ?>
        <div class="wrap flashes">
            <?php foreach ($flashes as $f): ?>
                <div class="alert alert-<?= e($f['type']) ?>" role="status">
                    <span><?= e($f['message']) ?></span>
                    <button class="alert-x" type="button" aria-label="Đóng thông báo"><?= icon('x', 16) ?></button>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
    <?= $content ?>
</main>

<footer class="site-footer">
    <div class="wrap foot-grid">
        <div>
            <a class="logo" href="<?= e(url()) ?>">
                <span class="brand-mark"><?= paw_icon(22) ?></span>
                <span class="logo-text">BabyBoss<small>Pet Spa</small></span>
            </a>
            <p class="foot-about">Spa, cắt tỉa lông và khách sạn cho chó mèo. Đặt lịch trực tuyến, theo dõi trạng thái và tích điểm sau mỗi lần chăm sóc.</p>
        </div>
        <div>
            <h4>Khám phá</h4>
            <ul>
                <li><a href="<?= e(url('services')) ?>">Dịch vụ spa</a></li>
                <li><a href="<?= e(url('about')) ?>">Giới thiệu</a></li>
                <li><a href="<?= e(url('book')) ?>">Đặt lịch</a></li>
                <li><a href="<?= e(url('contact')) ?>">Liên hệ</a></li>
            </ul>
        </div>
        <div>
            <h4>Liên hệ</h4>
            <ul>
                <li><?= icon('phone', 15) ?> <a href="<?= e(tel_href(shop('hotline'))) ?>"><?= e(shop('hotline')) ?></a></li>
                <li><?= icon('mail', 15) ?> <?= e(shop('email')) ?></li>
                <li><?= icon('pin', 15) ?> <?= e(shop('address')) ?></li>
                <li><?= icon('clock', 15) ?> <?= e(shop('hours')) ?></li>
            </ul>
        </div>
    </div>
    <div class="wrap foot-bottom">
        <span>© <?= date('Y') ?> <?= e(shop('name')) ?></span>
        <a href="<?= e(admin_url('login')) ?>">Đăng nhập quản trị</a>
    </div>
</footer>

<dialog id="confirmDialog" class="modal" aria-labelledby="confirmTitle">
    <form method="dialog" class="modal-box">
        <h3 id="confirmTitle">Xác nhận thao tác</h3>
        <p id="confirmText"></p>
        <div class="modal-actions">
            <button class="btn btn-ghost" value="cancel">Quay lại</button>
            <button class="btn btn-danger" value="ok" id="confirmOk">Đồng ý</button>
        </div>
    </form>
</dialog>
<script src="<?= e(asset('js/site.js')) ?>"></script>
</body>
</html>
