<div class="wrap page">
    <div class="page-head">
        <div>
            <h1>Giới thiệu BabyBoss</h1>
            <p class="lead">Tiệm spa dành cho chó mèo, nơi mỗi bé có một khung giờ riêng để được chăm sóc kỹ mà không phải chờ lâu.</p>
        </div>
    </div>

    <div class="about-grid">
        <div class="prose">
            <h2>Chúng tôi làm gì</h2>
            <p>BabyBoss cung cấp tắm sấy, cắt tỉa tạo kiểu, vệ sinh tai và cắt móng, spa dưỡng lông và khách sạn thú cưng. Mỗi dịch vụ có giá và thời gian thực hiện ghi rõ trên website; bạn chọn giờ phù hợp rồi đặt lịch trực tuyến.</p>

            <h2>Một lần đến spa</h2>
            <p>Sau khi bạn gửi lịch, nhân viên xác nhận trong giờ làm việc. Đến giờ hẹn, bé được thực hiện đúng dịch vụ đã chọn, bạn theo dõi trạng thái lịch ngay trong tài khoản của mình.</p>

            <h2>Điểm thưởng và hạng thành viên</h2>
            <p>Mỗi lịch hoàn thành đều được cộng điểm theo hạng thành viên (Bạc, Vàng, Kim Cương). Điểm dùng để giảm trực tiếp vào hóa đơn ở lần đặt lịch sau.</p>

            <p class="about-actions">
                <a class="btn btn-primary btn-lg" href="<?= e(url('services')) ?>">Xem dịch vụ</a>
                <a class="btn btn-outline btn-lg" href="<?= e(url('book')) ?>">Đặt lịch</a>
            </p>
        </div>

        <aside class="panel info-box">
            <h2>Thông tin tiệm</h2>
            <dl class="kv stack">
                <div><dt>Địa chỉ</dt><dd><?= e(shop('address')) ?></dd></div>
                <div><dt>Giờ làm việc</dt><dd><?= e(shop('hours')) ?></dd></div>
                <div><dt>Hotline</dt><dd><a class="link" href="<?= e(tel_href(shop('hotline'))) ?>"><?= e(shop('hotline')) ?></a></dd></div>
                <div><dt>Email</dt><dd><?= e(shop('email')) ?></dd></div>
            </dl>
        </aside>
    </div>
</div>
