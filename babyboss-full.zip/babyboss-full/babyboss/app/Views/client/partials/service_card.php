<?php
/** @var array $s */
$id = (int) ($s['id'] ?? 0);
$nameLower = mb_strtolower((string) ($s['name'] ?? ''), 'UTF-8');

// 7+ ảnh thú cưng dễ thương khác nhau cho từng dịch vụ
$cuteGallery = [
    'https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?auto=format&fit=crop&w=900&q=85', // 0: Cún áo vàng xinh xắn
    'https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?auto=format&fit=crop&w=900&q=85', // 1: Mèo mắt tròn đáng yêu
    'https://images.unsplash.com/photo-1548199973-03cce0bbc87b?auto=format&fit=crop&w=900&q=85', // 2: Hai bé cún chạy vui
    'https://images.unsplash.com/photo-1573865526739-10659fec78a5?auto=format&fit=crop&w=900&q=85', // 3: Mèo nằm nghỉ thư giãn
    'https://images.unsplash.com/photo-1537151625747-768eb6cf92b2?auto=format&fit=crop&w=900&q=85', // 4: Cún mặt ngây thơ
    'https://images.unsplash.com/photo-1516734212186-a967f81ad0d7?auto=format&fit=crop&w=900&q=85', // 5: Spa chải lông cho bé
    'https://images.unsplash.com/photo-1592194996308-7b43878e84a6?auto=format&fit=crop&w=900&q=85', // 6: Mèo trắng xinh
    'https://images.unsplash.com/photo-1601758228041-f3b2795255f1?auto=format&fit=crop&w=900&q=85', // 7: Cún cưng thân thiện
];

$imgUrl = '';
if (!empty($s['image'])) {
    $rawImg = trim((string) $s['image']);
    if (preg_match('#^https?://#i', $rawImg)) {
        $imgUrl = $rawImg;
    } else {
        $cleanPath = ltrim($rawImg, '/');
        if (strpos($cleanPath, 'uploads/') !== 0) {
            $cleanPath = 'uploads/services/' . $cleanPath;
        }
        $imgUrl = BASE_URL . '/' . $cleanPath;
    }
}

// Nếu chưa có ảnh riêng trong CSDL thì gán theo từng dịch vụ riêng biệt
if ($imgUrl === '') {
    if (strpos($nameLower, 'tai') !== false || strpos($nameLower, 'móng') !== false) {
        $imgUrl = $cuteGallery[4];
    } elseif (strpos($nameLower, 'tỉa') !== false || strpos($nameLower, 'tạo kiểu') !== false) {
        $imgUrl = $cuteGallery[0];
    } elseif (strpos($nameLower, 'tắm sấy') !== false || strpos($nameLower, 'tắm') !== false) {
        $imgUrl = $cuteGallery[5];
    } elseif (strpos($nameLower, 'răng') !== false || strpos($nameLower, 'miệng') !== false) {
        $imgUrl = $cuteGallery[6];
    } elseif (strpos($nameLower, 'khách sạn') !== false || strpos($nameLower, 'nghỉ dưỡng') !== false) {
        $imgUrl = $cuteGallery[3];
    } elseif (strpos($nameLower, 'massage') !== false || strpos($nameLower, 'dưỡng lông') !== false) {
        $imgUrl = $cuteGallery[1];
    } else {
        $imgUrl = $cuteGallery[$id > 0 ? ($id - 1) % count($cuteGallery) : 2];
    }
}

$toneIndex = $id % 6;
?>
<article class="svc-card">
    <div class="art has-img tone-<?= $toneIndex ?>">
        <img
            class="svc-photo"
            src="<?= e($imgUrl) ?>"
            alt="<?= e($s['name'] ?? 'Dịch vụ BabyBoss Pet Spa') ?>"
            loading="lazy"
            onerror="this.onerror=null;this.src='<?= e($cuteGallery[$id % count($cuteGallery)]) ?>';"
        >
    </div>

    <div class="svc-body">
        <h3>
            <a href="<?= e(url('services/show', ['id' => $id])) ?>">
                <?= e($s['name'] ?? '') ?>
            </a>
        </h3>

        <?php if (!empty($s['description'])): ?>
            <p><?= e($s['description']) ?></p>
        <?php endif; ?>

        <div class="svc-meta">
            <span class="price"><?= e(money((int) ($s['price'] ?? 0))) ?></span>
            <?php if (!empty($s['duration'])): ?>
                <span class="muted">⏱ <?= (int) $s['duration'] ?> phút</span>
            <?php endif; ?>
        </div>
    </div>
</article>
