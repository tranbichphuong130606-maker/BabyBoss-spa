<?php
/** Front controller của khu vực Admin — mọi request /admin/... đều đi qua file này. */
require dirname(__DIR__) . '/app/bootstrap.php';

use App\Core\{Request, Router};

$router = new Router();
require BASE_PATH . '/config/routes.php';
$router->dispatch(Request::capture());
