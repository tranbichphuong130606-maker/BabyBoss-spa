/* BabyBoss Admin — JavaScript thuần, không cần thư viện */
(function () {
  'use strict';
  var body = document.body;

  // Menu trượt trên điện thoại
  var menuBtn = document.getElementById('menuBtn');
  var scrim = document.getElementById('scrim');
  if (menuBtn) menuBtn.addEventListener('click', function () { body.classList.toggle('nav-open'); });
  if (scrim) scrim.addEventListener('click', function () { body.classList.remove('nav-open'); });

  // Đóng thông báo; thông báo thành công tự ẩn sau 6 giây
  document.querySelectorAll('.alert').forEach(function (alertBox) {
    var close = alertBox.querySelector('.alert-x');
    if (close) close.addEventListener('click', function () { alertBox.classList.add('hide'); });
    if (alertBox.classList.contains('alert-success')) {
      setTimeout(function () { alertBox.classList.add('hide'); }, 6000);
    }
  });

  // Hộp thoại xác nhận cho mọi form có thuộc tính data-confirm
  var confirmDialog = document.getElementById('confirmDialog');
  var pendingForm = null;
  if (confirmDialog && typeof confirmDialog.showModal === 'function') {
    document.addEventListener('submit', function (e) {
      var form = e.target;
      if (!form.dataset || !form.dataset.confirm || form.dataset.confirmed) return;
      e.preventDefault();
      pendingForm = form;
      document.getElementById('confirmText').textContent = form.dataset.confirm;
      var ok = document.getElementById('confirmOk');
      ok.textContent = form.dataset.confirmLabel || 'Đồng ý';
      ok.className = 'btn ' + (form.dataset.confirmTone === 'primary' ? 'btn-primary' : 'btn-danger');
      confirmDialog.showModal();
    });
    confirmDialog.addEventListener('close', function () {
      if (confirmDialog.returnValue === 'ok' && pendingForm) {
        pendingForm.dataset.confirmed = '1';
        pendingForm.submit();
      }
      pendingForm = null;
      confirmDialog.returnValue = '';
    });
    confirmDialog.addEventListener('click', function (e) { if (e.target === confirmDialog) confirmDialog.close(); });
  } else {
    document.addEventListener('submit', function (e) {
      var form = e.target;
      if (form.dataset && form.dataset.confirm && !window.confirm(form.dataset.confirm)) e.preventDefault();
    });
  }

  // Hộp thoại điều chỉnh điểm thưởng
  var adjust = document.getElementById('adjustDialog');
  if (adjust) {
    var who = document.getElementById('adjWho');
    var userField = document.getElementById('adjUser');
    var amount = document.getElementById('adjAmount');
    var label = document.getElementById('adjAmountLabel');
    var labels = { add: 'Số điểm cộng thêm', sub: 'Số điểm trừ đi', set: 'Số dư mới (điểm)' };

    document.querySelectorAll('.js-adjust').forEach(function (btn) {
      btn.addEventListener('click', function () {
        userField.value = btn.dataset.userId;
        who.textContent = btn.dataset.name + ' đang có ' + Number(btn.dataset.points).toLocaleString('vi-VN') + ' điểm.';
        adjust.querySelector('input[name="mode"][value="add"]').checked = true;
        adjust.querySelector('input[name="note"]').value = '';
        label.textContent = labels.add;
        amount.value = '';
        adjust.showModal();
        amount.focus();
      });
    });
    adjust.querySelectorAll('input[name="mode"]').forEach(function (radio) {
      radio.addEventListener('change', function () { label.textContent = labels[radio.value]; });
    });
    adjust.querySelectorAll('[data-close]').forEach(function (btn) {
      btn.addEventListener('click', function () { adjust.close(); });
    });
    adjust.addEventListener('click', function (e) { if (e.target === adjust) adjust.close(); });
  }

  // Xem trước ảnh dịch vụ trước khi tải lên
  document.querySelectorAll('input[type=file][data-preview]').forEach(function (input) {
    input.addEventListener('change', function () {
      var img = document.getElementById(input.dataset.preview);
      var placeholder = document.getElementById('previewPh');
      var file = input.files && input.files[0];
      if (!file || !img) return;
      img.src = URL.createObjectURL(file);
      img.hidden = false;
      if (placeholder) placeholder.hidden = true;
    });
  });

  // Hiện / ẩn mật khẩu ở trang đăng nhập
  document.querySelectorAll('[data-toggle-pw]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var input = btn.parentElement.querySelector('input');
      var show = input.type === 'password';
      input.type = show ? 'text' : 'password';
      btn.setAttribute('aria-label', show ? 'Ẩn mật khẩu' : 'Hiện mật khẩu');
    });
  });

  // Cuộn hội thoại xuống tin nhắn mới nhất
  var chat = document.getElementById('chat');
  if (chat) chat.scrollTop = chat.scrollHeight;
})();
