<?php
/**
 * Khởi tạo dùng chung cho Client (Phần 1) và Admin (Phần 2):
 * hằng số đường dẫn, autoload, cấu hình, session, xử lý lỗi.
 */
use App\Core\{Config, Session};

define('BASE_PATH', dirname(__DIR__));
define('APP_PATH', __DIR__);
define('UPLOAD_PATH', BASE_PATH . '/uploads');

// Autoload theo chuẩn PSR-4: App\Models\User  ->  app/Models/User.php
spl_autoload_register(function (string $class): void {
    if (strncmp($class, 'App\\', 4) !== 0) {
        return;
    }
    $file = APP_PATH . '/' . str_replace('\\', '/', substr($class, 4)) . '.php';
    if (is_file($file)) {
        require $file;
    }
});

require APP_PATH . '/Core/helpers.php';

Config::load(require BASE_PATH . '/config/config.php');
date_default_timezone_set((string) Config::get('app.timezone', 'Asia/Ho_Chi_Minh'));
mb_internal_encoding('UTF-8');

// Tự nhận diện BASE_URL = đường dẫn của dự án so với thư mục gốc của web server
$baseUrl = (string) Config::get('app.base_url', '');
if ($baseUrl === '') {
    $docRootRaw = (string) ($_SERVER['DOCUMENT_ROOT'] ?? '');
    $docRoot    = $docRootRaw !== '' ? realpath($docRootRaw) : false;
    $root       = str_replace('\\', '/', (string) realpath(BASE_PATH));
    if ($docRoot !== false) {
        $docRoot = str_replace('\\', '/', $docRoot);
        if (stripos($root, $docRoot) === 0) {
            $baseUrl = substr($root, strlen($docRoot));
        }
    }
}
define('BASE_URL', rtrim($baseUrl, '/'));

error_reporting(E_ALL);
ini_set('display_errors', Config::get('app.debug') ? '1' : '0');

set_exception_handler(function (Throwable $e): void {
    error_log((string) $e);
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    http_response_code(500);
    header('Content-Type: text/html; charset=utf-8');
    $detail = Config::get('app.debug')
        ? '<pre style="white-space:pre-wrap;background:#f1f6f9;padding:14px;border-radius:8px;font-size:13px">' . htmlspecialchars((string) $e) . '</pre>'
        : '<p>Vui lòng thử lại sau hoặc liên hệ quản trị viên.</p>';
    echo '<!doctype html><meta charset="utf-8"><title>Lỗi hệ thống</title>'
        . '<body style="font-family:system-ui,sans-serif;max-width:780px;margin:60px auto;padding:0 16px;color:#14283d">'
        . '<h1>Đã xảy ra lỗi hệ thống</h1>' . $detail . '</body>';
});

Session::start();
