<?php
namespace App\Core;

/** Đóng gói dữ liệu gửi lên (GET, POST, FILES). */
final class Request
{
    public function __construct(
        private array $get,
        private array $post,
        private array $files,
        private string $method
    ) {}

    public static function capture(): self
    {
        return new self($_GET, $_POST, $_FILES, strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET'));
    }

    public function method(): string { return $this->method; }
    public function isPost(): bool   { return $this->method === 'POST'; }

    /** Route hiện tại, ví dụ "users/5/toggle-lock" (mặc định: dashboard). */
    public function path(): string
    {
        $route = is_string($this->get['route'] ?? null) ? trim($this->get['route'], '/') : '';
        return $route === '' ? 'dashboard' : $route;
    }

    /** Giá trị GET dạng chuỗi đã trim. */
    public function query(string $key, string $default = ''): string
    {
        $v = $this->get[$key] ?? $default;
        return is_string($v) ? trim($v) : $default;
    }

    /** Giá trị POST dạng chuỗi đã trim. */
    public function input(string $key, string $default = ''): string
    {
        $v = $this->post[$key] ?? $default;
        return is_string($v) ? trim($v) : $default;
    }

    /** Giá trị POST giữ nguyên (dùng cho mật khẩu, không trim). */
    public function raw(string $key): string
    {
        $v = $this->post[$key] ?? '';
        return is_string($v) ? $v : '';
    }

    public function inputArray(string $key): array
    {
        return is_array($this->post[$key] ?? null) ? $this->post[$key] : [];
    }

    public function file(string $key): ?array
    {
        return is_array($this->files[$key] ?? null) ? $this->files[$key] : null;
    }

    public function page(): int
    {
        return max(1, (int) $this->query('page', '1'));
    }
}
