<?php
namespace App\Core;

use App\Models\{Appointment, Message};

/** Lớp cha của các Controller khu vực admin. */
abstract class Controller
{
    public function __construct(protected Request $request) {}

    /** Hiển thị view (mặc định bọc trong layout admin). */
    protected function view(string $template, array $data = [], ?string $layout = 'layouts/main'): void
    {
        $data['flashes'] = Session::pullFlash();
        if ($layout !== null) {
            $data['admin']     = Auth::user();
            $data['navCounts'] = [
                'appointments' => (new Appointment())->countPending(),
                'messages'     => (new Message())->countAwaiting(),
            ];
        }
        View::render($template, $data, $layout);
    }

    protected function flash(string $type, string $message): void
    {
        Session::flash($type, $message);
    }

    protected function redirect(string $route, array $query = []): void
    {
        header('Location: ' . admin_url($route, $query));
        exit;
    }

    /** Quay lại trang trước (giữ nguyên bộ lọc / trang); nếu không có thì về route dự phòng. */
    protected function back(string $fallbackRoute): void
    {
        $ref     = (string) ($_SERVER['HTTP_REFERER'] ?? '');
        $refHost = parse_url($ref, PHP_URL_HOST);
        $refPath = (string) parse_url($ref, PHP_URL_PATH);
        $myHost  = parse_url('//' . ($_SERVER['HTTP_HOST'] ?? ''), PHP_URL_HOST);

        if ($refHost !== null && $refHost === $myHost && str_starts_with($refPath, BASE_URL . '/admin/')) {
            $query = parse_url($ref, PHP_URL_QUERY);
            header('Location: ' . $refPath . ($query ? '?' . $query : ''));
            exit;
        }
        $this->redirect($fallbackRoute);
    }

    protected function notFound(string $message = 'Không tìm thấy dữ liệu yêu cầu.'): void
    {
        View::error(404, $message);
        exit;
    }
}
