<?php
namespace App\Core;

/** Bộ định tuyến: ghép "route" trên URL với Controller@method. */
final class Router
{
    private const CONTROLLER_NS = 'App\\Controllers\\Admin\\';

    private array $routes = [];

    public function get(string $pattern, string $handler, array $middleware = []): void
    {
        $this->add('GET', $pattern, $handler, $middleware);
    }

    public function post(string $pattern, string $handler, array $middleware = []): void
    {
        $this->add('POST', $pattern, $handler, $middleware);
    }

    private function add(string $method, string $pattern, string $handler, array $middleware): void
    {
        // {id} -> nhóm số nguyên
        $regex          = '#^' . preg_replace('/\{\w+\}/', '([0-9]+)', $pattern) . '$#';
        $this->routes[] = compact('method', 'regex', 'handler', 'middleware');
    }

    public function dispatch(Request $request): void
    {
        $path       = $request->path();
        $pathExists = false;

        foreach ($this->routes as $route) {
            if (!preg_match($route['regex'], $path, $matches)) {
                continue;
            }
            $pathExists = true;
            if ($route['method'] !== $request->method()) {
                continue;
            }
            array_shift($matches);

            // Mọi form POST đều phải kèm CSRF token hợp lệ
            if ($request->isPost() && !Csrf::verify($request->input('_token'))) {
                View::error(419, 'Phiên làm việc đã hết hạn. Hãy tải lại trang rồi thử lại.');
                return;
            }
            foreach ($route['middleware'] as $middleware) {
                (new $middleware())->handle($request);
            }

            [$controller, $action] = explode('@', $route['handler']);
            $class = self::CONTROLLER_NS . $controller;
            (new $class($request))->$action(...array_map('intval', $matches));
            return;
        }

        $pathExists
            ? View::error(405, 'Phương thức yêu cầu không được hỗ trợ.')
            : View::error(404, 'Không tìm thấy trang bạn yêu cầu.');
    }
}
