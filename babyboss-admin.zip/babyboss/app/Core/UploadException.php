<?php
namespace App\Core;

/** Lỗi khi tải file lên (thông báo có thể hiển thị trực tiếp cho người dùng). */
final class UploadException extends \RuntimeException
{
}
