<?php
namespace App\Core;

use PDO;
use PDOStatement;

/** Lớp cha của mọi Model: gói gọn việc chạy prepared statement. */
abstract class Model
{
    protected PDO $db;

    public function __construct()
    {
        $this->db = Database::connection();
    }

    /** Chạy câu lệnh với tham số tên (:name) hoặc vị trí (?), tự nhận kiểu dữ liệu. */
    protected function run(string $sql, array $params = []): PDOStatement
    {
        $stmt = $this->db->prepare($sql);
        foreach ($params as $key => $value) {
            $type = match (true) {
                is_int($value)  => PDO::PARAM_INT,
                is_bool($value) => PDO::PARAM_BOOL,
                $value === null => PDO::PARAM_NULL,
                default         => PDO::PARAM_STR,
            };
            $stmt->bindValue(is_int($key) ? $key + 1 : ':' . $key, $value, $type);
        }
        $stmt->execute();
        return $stmt;
    }

    protected function fetchAll(string $sql, array $params = []): array
    {
        return $this->run($sql, $params)->fetchAll();
    }

    protected function fetchOne(string $sql, array $params = []): ?array
    {
        $row = $this->run($sql, $params)->fetch();
        return $row === false ? null : $row;
    }

    protected function scalar(string $sql, array $params = [])
    {
        $value = $this->run($sql, $params)->fetchColumn();
        return $value === false ? null : $value;
    }

    protected function insertId(): int
    {
        return (int) $this->db->lastInsertId();
    }

    /** Chuẩn hóa từ khóa cho mệnh đề LIKE (escape % và _). */
    protected function like(string $keyword): string
    {
        return '%' . addcslashes($keyword, '%_\\') . '%';
    }
}
