<?php
namespace App\Core;

/** Render template PHP trong app/Views/admin, có hỗ trợ layout và partial. */
final class View
{
    public static function render(string $template, array $data = [], ?string $layout = 'layouts/main'): void
    {
        $content = self::capture($template, $data);
        if ($layout !== null) {
            $content = self::capture($layout, array_merge($data, ['content' => $content]));
        }
        echo $content;
    }

    public static function partial(string $name, array $data = []): void
    {
        echo self::capture('partials/' . $name, $data);
    }

    public static function error(int $code, string $message): void
    {
        http_response_code($code);
        self::render('errors/error', ['code' => $code, 'message' => $message, 'title' => 'Lỗi ' . $code], null);
    }

    private static function capture(string $template, array $__data): string
    {
        $__file = APP_PATH . '/Views/admin/' . $template . '.php';
        if (!is_file($__file)) {
            throw new \RuntimeException('Không tìm thấy view: ' . $template);
        }
        extract($__data, EXTR_SKIP);
        ob_start();
        try {
            require $__file;
        } catch (\Throwable $e) {
            ob_end_clean();
            throw $e;
        }
        return (string) ob_get_clean();
    }
}
