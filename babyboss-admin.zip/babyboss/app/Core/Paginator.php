<?php
namespace App\Core;

/** Tính toán phân trang cho LIMIT / OFFSET. */
final class Paginator
{
    public int $total;
    public int $perPage;
    public int $pages;
    public int $page;

    public function __construct(int $total, int $perPage, int $page)
    {
        $this->total   = max(0, $total);
        $this->perPage = max(1, $perPage);
        $this->pages   = max(1, (int) ceil($this->total / $this->perPage));
        $this->page    = min(max(1, $page), $this->pages);
    }

    public function offset(): int { return ($this->page - 1) * $this->perPage; }
    public function from(): int   { return $this->total === 0 ? 0 : $this->offset() + 1; }
    public function to(): int     { return min($this->total, $this->offset() + $this->perPage); }

    /** Danh sách số trang cần hiển thị; null = dấu "…". */
    public function window(int $radius = 2): array
    {
        $items = [];
        $last  = 0;
        for ($i = 1; $i <= $this->pages; $i++) {
            if ($i === 1 || $i === $this->pages || abs($i - $this->page) <= $radius) {
                if ($last && $i - $last > 1) {
                    $items[] = null;
                }
                $items[] = $i;
                $last    = $i;
            }
        }
        return $items;
    }
}
