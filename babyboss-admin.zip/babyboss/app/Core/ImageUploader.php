<?php
namespace App\Core;

/** Tải ảnh lên: kiểm tra định dạng (.jpg/.png/.webp), dung lượng, nội dung thật và đổi tên bằng uniqid(). */
final class ImageUploader
{
    private const TYPES = ['jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp'];

    public function __construct(private string $directory, private int $maxBytes = 2097152) {}

    /** @return string|null tên file đã lưu, hoặc null nếu người dùng không chọn ảnh */
    public function save(?array $file, string $prefix = 'img_'): ?string
    {
        if ($file === null || !isset($file['error']) || !is_int($file['error'])) {
            return null;
        }
        if ($file['error'] === UPLOAD_ERR_NO_FILE) {
            return null;
        }
        if ($file['error'] !== UPLOAD_ERR_OK) {
            $tooBig = in_array($file['error'], [UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE], true);
            throw new UploadException($tooBig ? $this->sizeMessage() : 'Tải ảnh lên không thành công, vui lòng thử lại.');
        }
        if ($file['size'] > $this->maxBytes) {
            throw new UploadException($this->sizeMessage());
        }

        $ext = strtolower(pathinfo((string) $file['name'], PATHINFO_EXTENSION));
        if (!isset(self::TYPES[$ext])) {
            throw new UploadException('Chỉ chấp nhận ảnh định dạng .jpg, .png hoặc .webp.');
        }
        // Kiểm tra nội dung thật của file, không tin vào đuôi file do người dùng gửi
        $mime = (new \finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
        if ($mime !== self::TYPES[$ext] || @getimagesize($file['tmp_name']) === false) {
            throw new UploadException('File tải lên không phải là ảnh hợp lệ.');
        }

        if (!is_dir($this->directory) && !mkdir($this->directory, 0755, true)) {
            throw new UploadException('Không tạo được thư mục uploads.');
        }
        $name = uniqid($prefix) . '.' . ($ext === 'jpeg' ? 'jpg' : $ext);
        if (!move_uploaded_file($file['tmp_name'], $this->directory . '/' . $name)) {
            throw new UploadException('Không lưu được file, vui lòng thử lại.');
        }
        return $name;
    }

    public function delete(?string $name): void
    {
        if ($name && preg_match('/^[\w.\-]+$/', $name)) {
            $path = $this->directory . '/' . $name;
            if (is_file($path)) {
                @unlink($path);
            }
        }
    }

    private function sizeMessage(): string
    {
        return 'Ảnh vượt quá dung lượng cho phép (tối đa ' . round($this->maxBytes / 1048576, 1) . ' MB).';
    }
}
