<?php
namespace App\Core;

use App\Models\User;

/** Đăng nhập / đăng xuất / lấy người dùng hiện tại (dựa trên $_SESSION['user_id']). */
final class Auth
{
    private static ?array $user = null;
    private static bool $resolved = false;

    /** Người dùng đang đăng nhập — luôn đọc mới từ CSDL để quyền và trạng thái luôn chính xác. */
    public static function user(): ?array
    {
        if (!self::$resolved) {
            self::$resolved = true;
            $id             = (int) ($_SESSION['user_id'] ?? 0);
            self::$user     = $id > 0 ? (new User())->find($id) : null;
        }
        return self::$user;
    }

    public static function id(): int
    {
        return (int) (self::user()['id'] ?? 0);
    }

    /** Kiểm tra thông tin đăng nhập khu vực quản trị. @return array{0: ?array, 1: ?string} [user, thông báo lỗi] */
    public static function attempt(string $email, string $password): array
    {
        $users = new User();
        $user  = $users->findByEmail($email);

        if ($user === null || !password_verify($password, $user['password'])) {
            return [null, 'Email hoặc mật khẩu không đúng.'];
        }
        if ($user['role'] !== 'admin') {
            return [null, 'Tài khoản này không có quyền truy cập khu vực quản trị.'];
        }
        if ($user['status'] !== 'active') {
            return [null, 'Tài khoản quản trị đã bị khóa.'];
        }
        if (password_needs_rehash($user['password'], PASSWORD_DEFAULT)) {
            $users->updatePassword((int) $user['id'], password_hash($password, PASSWORD_DEFAULT));
        }
        unset($user['password']);
        return [$user, null];
    }

    public static function login(array $user): void
    {
        session_regenerate_id(true);          // chống session fixation
        unset($_SESSION['_csrf']);
        $_SESSION['user_id'] = (int) $user['id'];
        self::$resolved      = false;
    }

    public static function logout(): void
    {
        unset($_SESSION['user_id'], $_SESSION['_csrf']);
        session_regenerate_id(true);
        self::$user     = null;
        self::$resolved = true;
    }
}
