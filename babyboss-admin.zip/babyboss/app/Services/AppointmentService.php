<?php
namespace App\Services;

use App\Core\Database;
use App\Models\Appointment;
use PDO;

/** Đổi trạng thái lịch hẹn và xử lý điểm thưởng đi kèm trong MỘT transaction. */
final class AppointmentService
{
    private Appointment $appointments;
    private LoyaltyService $loyalty;
    private PDO $db;

    public function __construct()
    {
        $this->appointments = new Appointment();
        $this->loyalty      = new LoyaltyService();
        $this->db           = Database::connection();
    }

    /** @return array{ok: bool, message: string} */
    public function changeStatus(int $id, string $newStatus, int $adminId): array
    {
        if (!isset(Appointment::STATUSES[$newStatus])) {
            return ['ok' => false, 'message' => 'Trạng thái mới không hợp lệ.'];
        }

        $this->db->beginTransaction();
        try {
            $appt = $this->appointments->lockForUpdate($id);   // khóa dòng để tránh bấm 2 lần / 2 admin cùng xử lý
            if ($appt === null) {
                $this->db->rollBack();
                return ['ok' => false, 'message' => 'Không tìm thấy lịch hẹn.'];
            }
            if (!in_array($newStatus, Appointment::TRANSITIONS[$appt['status']], true)) {
                $this->db->rollBack();
                return [
                    'ok'      => false,
                    'message' => sprintf('Lịch %s đang ở trạng thái "%s", không thể chuyển sang "%s".',
                        appt_code($id), Appointment::STATUSES[$appt['status']], Appointment::STATUSES[$newStatus]),
                ];
            }

            $this->appointments->updateStatus($id, $newStatus);

            $extra = '';
            if ($newStatus === 'completed') {
                $earned = $this->loyalty->awardForAppointment($appt, $adminId);
                $this->appointments->setPointsEarned($id, $earned);
                $extra = $earned > 0 ? sprintf(' Khách được cộng %d điểm thưởng.', $earned) : '';
            } elseif ($newStatus === 'cancelled' && (int) $appt['points_used'] > 0) {
                $this->loyalty->refundForAppointment($appt, $adminId);
                $extra = sprintf(' Đã hoàn %d điểm cho khách.', (int) $appt['points_used']);
            }

            $this->db->commit();
        } catch (\Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            throw $e;
        }

        return ['ok' => true, 'message' => sprintf('Lịch %s đã chuyển sang "%s".%s', appt_code($id), Appointment::STATUSES[$newStatus], $extra)];
    }
}
