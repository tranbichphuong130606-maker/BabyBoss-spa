<?php
namespace App\Services;

use App\Core\Database;
use App\Models\{LoyaltyTransaction, MembershipTier, Setting, User};
use PDO;

/**
 * Nghiệp vụ điểm thưởng: tích điểm khi hoàn thành lịch, hoàn điểm khi hủy lịch,
 * admin điều chỉnh thủ công, tính tiến độ lên hạng.
 *
 * awardForAppointment() và refundForAppointment() được gọi BÊN TRONG transaction
 * của AppointmentService; adjust() tự mở transaction riêng.
 */
final class LoyaltyService
{
    private User $users;
    private MembershipTier $tiers;
    private Setting $settings;
    private LoyaltyTransaction $log;
    private PDO $db;

    public function __construct()
    {
        $this->users    = new User();
        $this->tiers    = new MembershipTier();
        $this->settings = new Setting();
        $this->log      = new LoyaltyTransaction();
        $this->db       = Database::connection();
    }

    /** Giá trị quy đổi của 1 điểm, tính bằng VNĐ (mặc định 1.000). */
    public function pointValue(): int
    {
        return max(1, (int) $this->settings->get('point_value', '1000'));
    }

    /**
     * Cộng điểm khi lịch hoàn thành: điểm = giá trị hóa đơn x tỷ lệ của hạng hiện tại / giá trị 1 điểm.
     * Đồng thời cộng dồn tổng chi tiêu để xét nâng hạng. Trả về số điểm được cộng.
     */
    public function awardForAppointment(array $appt, int $adminId): int
    {
        $user = $this->users->lockForUpdate((int) $appt['user_id']);
        if ($user === null) {
            return 0;
        }
        $total   = (int) $appt['total_amount'];
        $tier    = $this->tiers->forSpent((int) $user['total_spent']);
        $rateBp  = (int) round((float) $tier['earn_rate'] * 100);              // 3.00% -> 300 (tính số nguyên, tránh sai số)
        $earned  = intdiv($total * $rateBp, 10000 * $this->pointValue());
        $balance = (int) $user['points'] + $earned;

        $this->users->applyPoints((int) $user['id'], $balance, $total);
        if ($earned > 0) {
            $this->log->record(
                (int) $user['id'], 'earn', $earned, $balance, (int) $appt['id'],
                sprintf('Tích %s%% (hạng %s) cho lịch %s', (float) $tier['earn_rate'], $tier['name'], appt_code((int) $appt['id'])),
                $adminId
            );
        }
        return $earned;
    }

    /** Hoàn lại số điểm khách đã dùng khi đặt lịch nếu lịch bị hủy. */
    public function refundForAppointment(array $appt, int $adminId): void
    {
        $points = (int) $appt['points_used'];
        $user   = $points > 0 ? $this->users->lockForUpdate((int) $appt['user_id']) : null;
        if ($user === null) {
            return;
        }
        $balance = (int) $user['points'] + $points;
        $this->users->applyPoints((int) $user['id'], $balance, 0);
        $this->log->record(
            (int) $user['id'], 'refund', $points, $balance, (int) $appt['id'],
            'Hoàn điểm do lịch ' . appt_code((int) $appt['id']) . ' bị hủy', $adminId
        );
    }

    /**
     * Admin điều chỉnh điểm thủ công.
     * @param string $mode add = cộng | sub = trừ | set = đặt lại số dư
     * @return array{ok: bool, message: string}
     */
    public function adjust(int $userId, string $mode, int $amount, string $note, int $adminId): array
    {
        if (!in_array($mode, ['add', 'sub', 'set'], true)) {
            return $this->fail('Hình thức điều chỉnh không hợp lệ.');
        }
        if ($amount < 0 || $amount > 1000000 || ($mode !== 'set' && $amount === 0)) {
            return $this->fail('Số điểm phải là số nguyên dương, tối đa 1.000.000.');
        }
        if (mb_strlen($note) < 3 || mb_strlen($note) > 255) {
            return $this->fail('Hãy nhập lý do điều chỉnh (từ 3 đến 255 ký tự).');
        }

        $this->db->beginTransaction();
        try {
            $user = $this->users->lockForUpdate($userId);
            if ($user === null) {
                $this->db->rollBack();
                return $this->fail('Không tìm thấy tài khoản khách hàng.');
            }
            $old = (int) $user['points'];
            $new = match ($mode) {
                'add' => $old + $amount,
                'sub' => $old - $amount,
                'set' => $amount,
            };
            if ($new < 0) {
                $this->db->rollBack();
                return $this->fail(sprintf('%s chỉ có %s điểm nên không thể trừ %s điểm.', $user['full_name'], number_format($old, 0, ',', '.'), number_format($amount, 0, ',', '.')));
            }
            if ($new === $old) {
                $this->db->rollBack();
                return $this->fail('Số dư điểm không thay đổi.');
            }
            $this->users->applyPoints($userId, $new, 0);
            $this->log->record($userId, 'adjust', $new - $old, $new, null, $note, $adminId);
            $this->db->commit();
        } catch (\Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            throw $e;
        }

        return [
            'ok'      => true,
            'message' => sprintf('Đã cập nhật điểm của %s: %s → %s điểm.', $user['full_name'], number_format($old, 0, ',', '.'), number_format($new, 0, ',', '.')),
        ];
    }

    /**
     * Tiến độ lên hạng của một khách hàng.
     * @param array $tiers danh sách hạng đã sắp xếp theo min_spent tăng dần
     */
    public static function progress(int $spent, array $tiers): array
    {
        $current = $tiers[0];
        $next    = $tiers[1] ?? null;
        foreach ($tiers as $i => $tier) {
            if ($spent >= (int) $tier['min_spent']) {
                $current = $tier;
                $next    = $tiers[$i + 1] ?? null;
            }
        }
        $percent   = 100;
        $remaining = 0;
        if ($next !== null) {
            $span      = max(1, (int) $next['min_spent'] - (int) $current['min_spent']);
            $percent   = (int) floor(($spent - (int) $current['min_spent']) / $span * 100);
            $remaining = (int) $next['min_spent'] - $spent;
        }
        return ['current' => $current, 'next' => $next, 'percent' => $percent, 'remaining' => $remaining];
    }

    private function fail(string $message): array
    {
        return ['ok' => false, 'message' => $message];
    }
}
