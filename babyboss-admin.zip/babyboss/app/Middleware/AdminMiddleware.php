<?php
namespace App\Middleware;

use App\Core\{Auth, Request, Session};

/**
 * Middleware phân quyền: chỉ tài khoản có role = 'admin' (và đang hoạt động) mới vào được khu vực quản trị.
 *  - Chưa đăng nhập        -> chuyển tới trang đăng nhập admin
 *  - Khách hàng thường     -> chặn và đưa về trang chủ
 */
final class AdminMiddleware
{
    public function handle(Request $request): void
    {
        $user = Auth::user();

        if ($user === null) {
            Session::flash('warning', 'Vui lòng đăng nhập để vào khu vực quản trị.');
            $this->go(admin_url('login'));
        }
        if ($user['status'] !== 'active') {
            Auth::logout();
            Session::flash('error', 'Tài khoản của bạn đã bị khóa.');
            $this->go(admin_url('login'));
        }
        if ($user['role'] !== 'admin') {
            Session::flash('error', 'Bạn không có quyền truy cập khu vực quản trị.');
            $this->go(base_url());
        }
    }

    private function go(string $url): void
    {
        header('Location: ' . $url);
        exit;
    }
}
