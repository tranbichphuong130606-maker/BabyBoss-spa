<?php
/** @var array $tiers @var int $pointValue @var array $errors @var ?array $old */
$err = fn(string $k): string => isset($errors[$k]) ? '<small class="field-error">' . e($errors[$k]) . '</small>' : '';

// Ví dụ minh họa lấy từ hạng thứ hai (hoặc hạng đầu nếu chỉ có một hạng)
$sample     = $tiers[1] ?? $tiers[0];
$sampleBill = 300000;
$samplePts  = intdiv($sampleBill * (int) round((float) $sample['earn_rate'] * 100), 10000 * $pointValue);
?>
<div class="page-head">
    <div>
        <h1>Hạng thành viên</h1>
        <p class="muted">Cấu hình tỷ lệ tích điểm (1% – 5%) và mức chi tiêu để khách tự động lên hạng.</p>
    </div>
</div>

<form class="config-layout" method="post" action="<?= e(admin_url('loyalty/config')) ?>" novalidate>
    <?= csrf_field() ?>

    <section class="card pad">
        <h2>Quy đổi điểm</h2>
        <label class="field <?= isset($errors['point_value']) ? 'has-error' : '' ?>">
            <span>Giá trị của 1 điểm (₫)</span>
            <input class="input" name="point_value" inputmode="numeric" value="<?= e($old['point_value'] ?? $pointValue) ?>" required>
            <?= $err('point_value') ?>
        </label>
        <p class="muted small">Khách dùng điểm để giảm trực tiếp vào hóa đơn khi đặt lịch. Mặc định 1 điểm = 1.000 ₫.</p>
        <div class="note">
            <b>Cách tính điểm tích lũy</b>
            <p>Điểm = giá trị hóa đơn × tỷ lệ của hạng ÷ giá trị 1 điểm, làm tròn xuống.</p>
            <p class="muted small">Ví dụ: hóa đơn <?= e(money($sampleBill)) ?> ở hạng <?= e($sample['name']) ?> (<?= e((string) (float) $sample['earn_rate']) ?>%) được cộng <b><?= $samplePts ?> điểm</b>.</p>
        </div>
    </section>

    <section class="card pad">
        <h2>Hạng và tỷ lệ tích điểm</h2>
        <div class="table-wrap">
            <table class="table tiers">
                <thead><tr><th>Hạng</th><th>Tổng chi tiêu từ (₫)</th><th>Tỷ lệ tích điểm (%)</th></tr></thead>
                <tbody>
                <?php foreach ($tiers as $i => $t): ?>
                    <?php
                    $id   = (int) $t['id'];
                    $min  = $old['tiers'][$id]['min_spent'] ?? number_format((int) $t['min_spent'], 0, ',', '.');
                    $rate = $old['tiers'][$id]['earn_rate'] ?? (string) (float) $t['earn_rate'];
                    ?>
                    <tr>
                        <td><span class="tier tier-<?= e(tier_class($t['name'])) ?>"><?= e($t['name']) ?></span></td>
                        <td>
                            <div class="<?= isset($errors['min_' . $id]) ? 'has-error' : '' ?>">
                                <?php if ($i === 0): ?>
                                    <input class="input" value="0" disabled aria-label="Hạng đầu tiên bắt đầu từ 0 ₫">
                                    <small class="muted">Hạng khởi điểm của mọi thành viên.</small>
                                <?php else: ?>
                                    <input class="input" name="tiers[<?= $id ?>][min_spent]" inputmode="numeric" value="<?= e($min) ?>" aria-label="Chi tiêu tối thiểu hạng <?= e($t['name']) ?>">
                                    <?= $err('min_' . $id) ?>
                                <?php endif; ?>
                            </div>
                        </td>
                        <td>
                            <div class="<?= isset($errors['rate_' . $id]) ? 'has-error' : '' ?>">
                                <input class="input" name="tiers[<?= $id ?>][earn_rate]" inputmode="decimal" value="<?= e($rate) ?>" aria-label="Tỷ lệ tích điểm hạng <?= e($t['name']) ?>">
                                <?= $err('rate_' . $id) ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <p class="muted small">Tổng chi tiêu của khách là tổng giá trị các lịch đã hoàn thành. Khi đạt ngưỡng, khách tự động lên hạng và được tích điểm theo tỷ lệ mới cho lịch kế tiếp.</p>
    </section>

    <div class="form-actions"><button class="btn btn-primary" type="submit">Lưu cấu hình</button></div>
</form>
