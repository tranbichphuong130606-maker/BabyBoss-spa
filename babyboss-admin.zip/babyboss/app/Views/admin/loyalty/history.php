<?php
/** @var array $transactions @var array $filters @var \App\Core\Paginator $pager @var ?array $customer */
use App\Models\LoyaltyTransaction;

$hasFilter = $filters['q'] !== '' || $filters['type'] !== '' || $filters['user_id'] > 0;
?>
<div class="page-head">
    <div>
        <h1>Lịch sử điểm</h1>
        <p class="muted">
            <?php if ($customer): ?>
                Đang xem giao dịch của <b><?= e($customer['full_name']) ?></b>.
                <a class="link" href="<?= e(admin_url('loyalty/history')) ?>">Xem toàn bộ khách hàng</a>
            <?php else: ?>
                Mọi lần cộng, trừ, dùng và hoàn điểm, kèm mã lịch và thời gian.
            <?php endif; ?>
        </p>
    </div>
</div>

<section class="card">
    <form class="toolbar" method="get" action="<?= e(admin_url()) ?>">
        <?= route_field('loyalty/history') ?>
        <?php if ($filters['user_id'] > 0): ?><input type="hidden" name="user_id" value="<?= (int) $filters['user_id'] ?>"><?php endif; ?>
        <label class="search"><?= icon('search') ?>
            <input type="search" name="q" value="<?= e($filters['q']) ?>" placeholder="Tìm theo khách hàng hoặc mã lịch (LH0007)">
        </label>
        <select class="select" name="type" aria-label="Lọc theo loại giao dịch">
            <option value="">Mọi loại giao dịch</option>
            <?php foreach (LoyaltyTransaction::TYPES as $key => $label): ?>
                <option value="<?= e($key) ?>" <?= $filters['type'] === $key ? 'selected' : '' ?>><?= e($label) ?></option>
            <?php endforeach; ?>
        </select>
        <button class="btn btn-primary" type="submit">Lọc</button>
        <?php if ($hasFilter): ?><a class="btn btn-ghost" href="<?= e(admin_url('loyalty/history')) ?>">Bỏ lọc</a><?php endif; ?>
    </form>

    <div class="table-wrap">
        <table class="table">
            <thead>
            <tr><th>Thời gian</th><th>Khách hàng</th><th>Loại</th><th class="num">Điểm</th><th class="num">Số dư sau</th><th>Mã lịch</th><th class="wide">Ghi chú</th></tr>
            </thead>
            <tbody>
            <?php foreach ($transactions as $t): ?>
                <?php $pts = (int) $t['points']; ?>
                <tr>
                    <td class="muted nowrap"><?= e(fmt_date($t['created_at'])) ?></td>
                    <td><b><?= e($t['customer_name']) ?></b><div class="muted small"><?= e($t['customer_email']) ?></div></td>
                    <td><?= badge('ty-' . $t['type'], LoyaltyTransaction::TYPES[$t['type']]) ?></td>
                    <td class="num"><b class="<?= $pts >= 0 ? 'pos' : 'neg' ?>"><?= $pts > 0 ? '+' : '−' ?><?= number_format(abs($pts), 0, ',', '.') ?></b></td>
                    <td class="num"><?= number_format((int) $t['balance_after'], 0, ',', '.') ?></td>
                    <td>
                        <?php if ($t['appointment_id']): ?>
                            <a class="link" href="<?= e(admin_url('appointments', ['q' => appt_code((int) $t['appointment_id'])])) ?>"><?= e(appt_code((int) $t['appointment_id'])) ?></a>
                        <?php else: ?><span class="muted">–</span><?php endif; ?>
                    </td>
                    <td class="wide">
                        <?= e($t['note']) ?>
                        <div class="muted small"><?= $t['admin_name'] ? 'Thực hiện bởi ' . e($t['admin_name']) : 'Hệ thống tự động' ?></div>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$transactions): ?>
                <tr><td colspan="7">
                    <div class="empty">
                        <p><b><?= $hasFilter ? 'Không có giao dịch nào khớp bộ lọc.' : 'Chưa có giao dịch điểm nào.' ?></b></p>
                        <p class="muted">Điểm được ghi nhận khi lịch hoàn thành, khi khách dùng điểm hoặc khi bạn điều chỉnh thủ công.</p>
                    </div>
                </td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php partial('pagination', ['pager' => $pager, 'route' => 'loyalty/history', 'query' => $filters]); ?>
</section>
