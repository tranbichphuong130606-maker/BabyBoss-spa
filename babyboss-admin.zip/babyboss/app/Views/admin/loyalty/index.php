<?php
/** @var array $customers @var array $filters @var \App\Core\Paginator $pager @var int $pointValue */
$hasFilter = $filters['q'] !== '';
?>
<div class="page-head">
    <div>
        <h1>Ví điểm thưởng</h1>
        <p class="muted">Điểm hiện có và tiến độ lên hạng của từng khách. Mỗi điểm quy đổi được <?= e(money($pointValue)) ?> khi khách đặt lịch.</p>
    </div>
</div>

<section class="card">
    <form class="toolbar" method="get" action="<?= e(admin_url()) ?>">
        <?= route_field('loyalty') ?>
        <label class="search"><?= icon('search') ?>
            <input type="search" name="q" value="<?= e($filters['q']) ?>" placeholder="Tìm theo tên, email hoặc số điện thoại">
        </label>
        <button class="btn btn-primary" type="submit">Tìm</button>
        <?php if ($hasFilter): ?><a class="btn btn-ghost" href="<?= e(admin_url('loyalty')) ?>">Bỏ lọc</a><?php endif; ?>
    </form>

    <div class="table-wrap">
        <table class="table">
            <thead>
            <tr><th>Khách hàng</th><th>Hạng</th><th class="num">Điểm hiện có</th><th class="num">Tổng chi tiêu</th><th class="wide">Tiến độ lên hạng</th><th class="actions">Thao tác</th></tr>
            </thead>
            <tbody>
            <?php foreach ($customers as $c): ?>
                <?php $p = $c['progress']; ?>
                <tr>
                    <td>
                        <div class="person">
                            <span class="avatar"><?= e(initial($c['full_name'])) ?></span>
                            <div><b><?= e($c['full_name']) ?></b><div class="muted small"><?= e($c['phone']) ?></div></div>
                        </div>
                    </td>
                    <td><span class="tier tier-<?= e(tier_class($p['current']['name'])) ?>"><?= e($p['current']['name']) ?></span></td>
                    <td class="num"><b><?= number_format((int) $c['points'], 0, ',', '.') ?></b><div class="muted small">≈ <?= e(money((int) $c['points'] * $pointValue)) ?></div></td>
                    <td class="num"><?= e(money($c['total_spent'])) ?></td>
                    <td class="wide">
                        <?php if ($p['next']): ?>
                            <div class="progress" role="progressbar" aria-valuenow="<?= (int) $p['percent'] ?>" aria-valuemin="0" aria-valuemax="100"><span style="width:<?= max(2, min(100, (int) $p['percent'])) ?>%"></span></div>
                            <div class="muted small">Còn <?= e(money($p['remaining'])) ?> để lên hạng <?= e($p['next']['name']) ?></div>
                        <?php else: ?>
                            <div class="muted small">Đã đạt hạng cao nhất.</div>
                        <?php endif; ?>
                    </td>
                    <td class="actions">
                        <button class="btn btn-sm btn-primary js-adjust" type="button"
                                data-user-id="<?= (int) $c['id'] ?>" data-name="<?= e($c['full_name']) ?>" data-points="<?= (int) $c['points'] ?>">
                            <?= icon('sliders', 15) ?> Điều chỉnh
                        </button>
                        <a class="btn btn-sm btn-outline" href="<?= e(admin_url('loyalty/history', ['user_id' => $c['id']])) ?>"><?= icon('list', 15) ?> Lịch sử</a>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$customers): ?>
                <tr><td colspan="6">
                    <div class="empty">
                        <p><b><?= $hasFilter ? 'Không tìm thấy khách hàng nào.' : 'Chưa có khách hàng nào.' ?></b></p>
                        <p class="muted">Thử tìm bằng tên, email hoặc số điện thoại khác.</p>
                    </div>
                </td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php partial('pagination', ['pager' => $pager, 'route' => 'loyalty', 'query' => $filters]); ?>
</section>

<dialog id="adjustDialog" class="modal" aria-labelledby="adjTitle">
    <form class="modal-box" method="post" action="<?= e(admin_url('loyalty/adjust')) ?>">
        <?= csrf_field() ?>
        <input type="hidden" name="user_id" id="adjUser">
        <h3 id="adjTitle">Điều chỉnh điểm thưởng</h3>
        <p class="muted" id="adjWho"></p>

        <div class="choice" role="radiogroup" aria-label="Hình thức điều chỉnh">
            <label><input type="radio" name="mode" value="add" checked><span>Cộng điểm</span></label>
            <label><input type="radio" name="mode" value="sub"><span>Trừ điểm</span></label>
            <label><input type="radio" name="mode" value="set"><span>Đặt lại số dư</span></label>
        </div>
        <label class="field">
            <span id="adjAmountLabel">Số điểm cộng thêm</span>
            <input class="input" name="amount" id="adjAmount" inputmode="numeric" autocomplete="off" required>
        </label>
        <label class="field">
            <span>Lý do (lưu vào lịch sử điểm)</span>
            <input class="input" name="note" maxlength="255" placeholder="Ví dụ: Tặng điểm sinh nhật bé" required>
        </label>
        <div class="modal-actions">
            <button class="btn btn-ghost" type="button" data-close>Hủy bỏ</button>
            <button class="btn btn-primary" type="submit">Lưu điều chỉnh</button>
        </div>
    </form>
</dialog>
