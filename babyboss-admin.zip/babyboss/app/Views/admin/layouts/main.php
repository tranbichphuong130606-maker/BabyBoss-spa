<?php
/** @var string $content @var array $admin @var array $flashes @var array $navCounts */
$active = $active ?? '';
$groups = [
    'Vận hành' => [
        ['appointments',    'appointments',    'Lịch đặt spa',    'calendar', $navCounts['appointments'] ?? 0],
        ['services',        'services',        'Dịch vụ spa',     'scissors', 0],
        ['messages',        'messages',        'Tin nhắn',        'message',  $navCounts['messages'] ?? 0],
        ['reviews',         'reviews',         'Đánh giá',        'star',     0],
    ],
    'Khách hàng' => [
        ['users',           'users',           'Người dùng',      'users',    0],
        ['loyalty',         'loyalty',         'Ví điểm thưởng',  'gift',     0],
        ['loyalty-history', 'loyalty/history', 'Lịch sử điểm',    'list',     0],
        ['loyalty-config',  'loyalty/config',  'Hạng thành viên', 'award',    0],
    ],
];
?>
<!doctype html>
<html lang="vi">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($title ?? 'Quản trị') ?> – BabyBoss Admin</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:wght@400;500;600;700&amp;display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= e(admin_asset('css/admin.css')) ?>">
</head>
<body>
<div class="app">
    <aside class="sidebar" id="sidebar">
        <a class="brand" href="<?= e(admin_url('dashboard')) ?>">
            <span class="brand-mark"><?= paw_icon(22) ?></span>
            <span><b>BabyBoss</b><small>Quản trị Pet Spa</small></span>
        </a>
        <nav class="nav" aria-label="Menu quản trị">
            <a class="<?= $active === 'dashboard' ? 'active' : '' ?>" href="<?= e(admin_url('dashboard')) ?>">
                <?= icon('home') ?><span>Tổng quan</span>
            </a>
            <?php foreach ($groups as $label => $items): ?>
                <div class="nav-group"><?= e($label) ?></div>
                <?php foreach ($items as [$key, $route, $text, $ico, $count]): ?>
                    <a class="<?= $active === $key ? 'active' : '' ?>" href="<?= e(admin_url($route)) ?>">
                        <?= icon($ico) ?><span><?= e($text) ?></span>
                        <?php if ($count > 0): ?><em class="count" title="Cần xử lý"><?= (int) $count ?></em><?php endif; ?>
                    </a>
                <?php endforeach; ?>
            <?php endforeach; ?>
        </nav>
        <div class="sidebar-foot">
            <div class="me">
                <span class="avatar sm"><?= e(initial($admin['full_name'])) ?></span>
                <div><b><?= e($admin['full_name']) ?></b><small>Quản trị viên</small></div>
            </div>
            <form method="post" action="<?= e(admin_url('logout')) ?>">
                <?= csrf_field() ?>
                <button class="btn-side" type="submit"><?= icon('logout') ?> Đăng xuất</button>
            </form>
        </div>
    </aside>
    <div class="scrim" id="scrim"></div>

    <div class="main">
        <header class="topbar">
            <button class="menu-btn" id="menuBtn" type="button" aria-label="Mở menu"><?= icon('menu', 20) ?></button>
            <span class="topbar-date"><?= e(today_vi()) ?></span>
            <a class="btn btn-ghost btn-sm" href="<?= e(base_url()) ?>" target="_blank" rel="noopener">Xem trang khách hàng</a>
        </header>
        <main class="content">
            <?php foreach ($flashes as $f): ?>
                <div class="alert alert-<?= e($f['type']) ?>" role="status">
                    <span><?= e($f['message']) ?></span>
                    <button class="alert-x" type="button" aria-label="Đóng thông báo"><?= icon('x', 16) ?></button>
                </div>
            <?php endforeach; ?>
            <?= $content ?>
        </main>
    </div>
</div>

<dialog id="confirmDialog" class="modal" aria-labelledby="confirmTitle">
    <form method="dialog" class="modal-box">
        <h3 id="confirmTitle">Xác nhận thao tác</h3>
        <p id="confirmText"></p>
        <div class="modal-actions">
            <button class="btn btn-ghost" value="cancel">Quay lại</button>
            <button class="btn btn-danger" value="ok" id="confirmOk">Đồng ý</button>
        </div>
    </form>
</dialog>
<script src="<?= e(admin_asset('js/admin.js')) ?>"></script>
</body>
</html>
