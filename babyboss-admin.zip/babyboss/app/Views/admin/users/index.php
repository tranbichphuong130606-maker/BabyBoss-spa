<?php
/** @var array $customers @var array $filters @var \App\Core\Paginator $pager */
$hasFilter = $filters['q'] !== '' || $filters['status'] !== '';
?>
<div class="page-head">
    <div>
        <h1>Người dùng</h1>
        <p class="muted">Tài khoản khách hàng đã đăng ký. Khóa tài khoản để chặn đăng nhập, hoặc xóa hẳn tài khoản vi phạm.</p>
    </div>
</div>

<section class="card">
    <form class="toolbar" method="get" action="<?= e(admin_url()) ?>">
        <?= route_field('users') ?>
        <label class="search"><?= icon('search') ?>
            <input type="search" name="q" value="<?= e($filters['q']) ?>" placeholder="Tìm theo tên, email hoặc số điện thoại">
        </label>
        <select class="select" name="status" aria-label="Lọc theo trạng thái">
            <option value="">Mọi trạng thái</option>
            <option value="active" <?= $filters['status'] === 'active' ? 'selected' : '' ?>>Đang hoạt động</option>
            <option value="locked" <?= $filters['status'] === 'locked' ? 'selected' : '' ?>>Đã khóa</option>
        </select>
        <button class="btn btn-primary" type="submit">Lọc</button>
        <?php if ($hasFilter): ?><a class="btn btn-ghost" href="<?= e(admin_url('users')) ?>">Bỏ lọc</a><?php endif; ?>
    </form>

    <div class="table-wrap">
        <table class="table">
            <thead>
            <tr>
                <th>Khách hàng</th><th>Điện thoại</th><th>Hạng và điểm</th>
                <th class="num">Thú cưng</th><th class="num">Lịch đặt</th><th>Ngày đăng ký</th><th>Trạng thái</th><th class="actions">Thao tác</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($customers as $c): ?>
                <?php $locked = $c['status'] === 'locked'; ?>
                <tr class="<?= $locked ? 'is-muted' : '' ?>">
                    <td>
                        <div class="person">
                            <span class="avatar"><?= e(initial($c['full_name'])) ?></span>
                            <div><b><?= e($c['full_name']) ?></b><div class="muted small"><?= e($c['email']) ?></div></div>
                        </div>
                    </td>
                    <td><?= e($c['phone']) ?></td>
                    <td>
                        <span class="tier tier-<?= e(tier_class($c['tier_name'])) ?>"><?= e($c['tier_name'] ?? 'Bạc') ?></span>
                        <span class="muted small"><?= number_format((int) $c['points'], 0, ',', '.') ?> điểm</span>
                    </td>
                    <td class="num"><?= (int) $c['pet_count'] ?></td>
                    <td class="num"><?= (int) $c['appointment_count'] ?></td>
                    <td class="muted"><?= e(fmt_date($c['created_at'], 'd/m/Y')) ?></td>
                    <td><?= $locked ? badge('st-hidden', 'Đã khóa') : badge('st-completed', 'Hoạt động') ?></td>
                    <td class="actions">
                        <form method="post" action="<?= e(admin_url('users/' . $c['id'] . '/toggle-lock')) ?>"
                            <?= $locked ? '' : 'data-confirm="' . e('Khóa tài khoản ' . $c['full_name'] . '? Khách sẽ không đăng nhập được cho đến khi bạn mở khóa.') . '" data-confirm-label="Khóa tài khoản"' ?>>
                            <?= csrf_field() ?>
                            <button class="btn btn-sm btn-outline" type="submit"><?= icon($locked ? 'unlock' : 'lock', 15) ?> <?= $locked ? 'Mở khóa' : 'Khóa' ?></button>
                        </form>
                        <form method="post" action="<?= e(admin_url('users/' . $c['id'] . '/delete')) ?>"
                              data-confirm="<?= e('Xóa vĩnh viễn tài khoản ' . $c['full_name'] . '? Thú cưng, lịch hẹn, đánh giá và điểm thưởng của khách cũng bị xóa theo. Không thể hoàn tác.') ?>"
                              data-confirm-label="Xóa tài khoản">
                            <?= csrf_field() ?>
                            <button class="btn btn-sm btn-danger-ghost" type="submit" aria-label="Xóa <?= e($c['full_name']) ?>" title="Xóa tài khoản"><?= icon('trash', 15) ?></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$customers): ?>
                <tr><td colspan="8">
                    <div class="empty">
                        <p><b><?= $hasFilter ? 'Không có khách hàng nào khớp bộ lọc.' : 'Chưa có khách hàng nào đăng ký.' ?></b></p>
                        <p class="muted"><?= $hasFilter ? 'Thử đổi từ khóa hoặc bỏ lọc để xem toàn bộ danh sách.' : 'Tài khoản mới sẽ xuất hiện ở đây khi khách đăng ký trên trang chủ.' ?></p>
                    </div>
                </td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php partial('pagination', ['pager' => $pager, 'route' => 'users', 'query' => $filters]); ?>
</section>
