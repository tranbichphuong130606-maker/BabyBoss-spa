<?php
/** @var array $reviews @var array $filters @var \App\Core\Paginator $pager @var array $stats */
use App\Models\Review;

$hasFilter = $filters['q'] !== '' || $filters['rating'] !== '' || $filters['status'] !== '';
?>
<div class="page-head">
    <div>
        <h1>Đánh giá</h1>
        <p class="muted">Kiểm duyệt phản hồi của khách. Đánh giá bị ẩn sẽ không hiện ở trang dịch vụ và không tính vào điểm trung bình.</p>
    </div>
    <div class="head-stats">
        <div><strong><?= (int) $stats['total'] ?></strong><span>đánh giá</span></div>
        <div><strong><?= $stats['avg_rating'] !== null ? e(number_format((float) $stats['avg_rating'], 1, ',', '.')) : '–' ?> ★</strong><span>trung bình</span></div>
        <div><strong><?= (int) $stats['hidden'] ?></strong><span>đang ẩn</span></div>
    </div>
</div>

<section class="card">
    <form class="toolbar" method="get" action="<?= e(admin_url()) ?>">
        <?= route_field('reviews') ?>
        <label class="search"><?= icon('search') ?>
            <input type="search" name="q" value="<?= e($filters['q']) ?>" placeholder="Tìm theo khách hàng, dịch vụ hoặc nội dung">
        </label>
        <select class="select" name="rating" aria-label="Lọc theo số sao">
            <option value="">Mọi số sao</option>
            <?php for ($i = 5; $i >= 1; $i--): ?>
                <option value="<?= $i ?>" <?= $filters['rating'] === (string) $i ? 'selected' : '' ?>><?= $i ?> sao</option>
            <?php endfor; ?>
        </select>
        <select class="select" name="status" aria-label="Lọc theo trạng thái">
            <option value="">Mọi trạng thái</option>
            <?php foreach (Review::STATUSES as $key => $label): ?>
                <option value="<?= e($key) ?>" <?= $filters['status'] === $key ? 'selected' : '' ?>><?= e($label) ?></option>
            <?php endforeach; ?>
        </select>
        <button class="btn btn-primary" type="submit">Lọc</button>
        <?php if ($hasFilter): ?><a class="btn btn-ghost" href="<?= e(admin_url('reviews')) ?>">Bỏ lọc</a><?php endif; ?>
    </form>

    <div class="table-wrap">
        <table class="table">
            <thead>
            <tr><th>Khách hàng</th><th>Dịch vụ</th><th class="wide">Đánh giá</th><th>Ngày gửi</th><th>Trạng thái</th><th class="actions">Thao tác</th></tr>
            </thead>
            <tbody>
            <?php foreach ($reviews as $r): ?>
                <?php $hidden = $r['status'] === 'hidden'; ?>
                <tr class="<?= $hidden ? 'is-muted' : '' ?>">
                    <td>
                        <div class="person"><span class="avatar sm"><?= e(initial($r['customer_name'])) ?></span><b><?= e($r['customer_name']) ?></b></div>
                    </td>
                    <td><?= e($r['service_name']) ?><div class="muted small"><?= e(appt_code((int) $r['appointment_id'])) ?></div></td>
                    <td class="wide">
                        <span class="stars" aria-label="<?= (int) $r['rating'] ?> trên 5 sao"><?= e(stars((int) $r['rating'])) ?></span>
                        <?php if (trim((string) $r['comment']) !== ''): ?>
                            <p class="review-text"><?= e($r['comment']) ?></p>
                        <?php else: ?>
                            <p class="muted small">Khách không để lại nhận xét.</p>
                        <?php endif; ?>
                    </td>
                    <td class="muted"><?= e(fmt_date($r['created_at'], 'd/m/Y')) ?></td>
                    <td><?= $hidden ? badge('st-hidden', 'Đã ẩn') : badge('st-completed', 'Đang hiển thị') ?></td>
                    <td class="actions">
                        <form method="post" action="<?= e(admin_url('reviews/' . $r['id'] . '/toggle')) ?>"
                            <?= $hidden ? '' : 'data-confirm="Ẩn đánh giá này? Khách sẽ không còn thấy nó ở trang dịch vụ." data-confirm-label="Ẩn đánh giá"' ?>>
                            <?= csrf_field() ?>
                            <button class="btn btn-sm btn-outline" type="submit"><?= icon($hidden ? 'eye' : 'eyeoff', 15) ?> <?= $hidden ? 'Hiện' : 'Ẩn' ?></button>
                        </form>
                        <form method="post" action="<?= e(admin_url('reviews/' . $r['id'] . '/delete')) ?>"
                              data-confirm="Xóa vĩnh viễn đánh giá này? Không thể hoàn tác." data-confirm-label="Xóa đánh giá">
                            <?= csrf_field() ?>
                            <button class="btn btn-sm btn-danger-ghost" type="submit" aria-label="Xóa đánh giá" title="Xóa đánh giá"><?= icon('trash', 15) ?></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$reviews): ?>
                <tr><td colspan="6">
                    <div class="empty">
                        <p><b><?= $hasFilter ? 'Không có đánh giá nào khớp bộ lọc.' : 'Chưa có đánh giá nào.' ?></b></p>
                        <p class="muted"><?= $hasFilter ? 'Thử đổi số sao, trạng thái hoặc bỏ lọc.' : 'Khách chỉ đánh giá được sau khi lịch spa đã hoàn thành.' ?></p>
                    </div>
                </td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php partial('pagination', ['pager' => $pager, 'route' => 'reviews', 'query' => $filters]); ?>
</section>
