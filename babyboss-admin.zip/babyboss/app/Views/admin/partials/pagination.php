<?php
/**
 * Thanh phân trang dùng chung.
 * @var \App\Core\Paginator $pager
 * @var string $route   route của danh sách (vd: 'users')
 * @var array  $query   bộ lọc hiện tại, được giữ nguyên khi chuyển trang
 */
$query = $query ?? [];
$url   = fn(int $p): string => admin_url($route, $query + ['page' => $p > 1 ? $p : null]);
?>
<?php if ($pager->total > 0): ?>
<div class="pager">
    <span class="muted">Hiển thị <?= $pager->from() ?>–<?= $pager->to() ?> trên <?= number_format($pager->total, 0, ',', '.') ?></span>
    <?php if ($pager->pages > 1): ?>
        <nav class="pages" aria-label="Phân trang">
            <?php if ($pager->page > 1): ?><a href="<?= e($url($pager->page - 1)) ?>" aria-label="Trang trước">‹</a><?php else: ?><span class="disabled">‹</span><?php endif; ?>
            <?php foreach ($pager->window() as $p): ?>
                <?php if ($p === null): ?>
                    <span class="gap">…</span>
                <?php else: ?>
                    <a class="<?= $p === $pager->page ? 'current' : '' ?>" href="<?= e($url($p)) ?>" <?= $p === $pager->page ? 'aria-current="page"' : '' ?>><?= $p ?></a>
                <?php endif; ?>
            <?php endforeach; ?>
            <?php if ($pager->page < $pager->pages): ?><a href="<?= e($url($pager->page + 1)) ?>" aria-label="Trang sau">›</a><?php else: ?><span class="disabled">›</span><?php endif; ?>
        </nav>
    <?php endif; ?>
</div>
<?php endif; ?>
