<?php
/** @var array $customer @var array $thread @var ?string $error @var string $draft */
?>
<div class="page-head">
    <div>
        <a class="back-link" href="<?= e(admin_url('messages')) ?>"><?= icon('back', 16) ?> Danh sách tin nhắn</a>
        <h1>Hội thoại với <?= e($customer['full_name']) ?></h1>
        <p class="muted"><?= e($customer['phone']) ?> – <?= e($customer['email']) ?></p>
    </div>
    <a class="btn btn-outline" href="<?= e(admin_url('appointments', ['q' => $customer['phone']])) ?>"><?= icon('calendar', 16) ?> Xem lịch đặt của khách</a>
</div>

<section class="card chat-card">
    <div class="chat" id="chat" tabindex="0" aria-label="Nội dung hội thoại">
        <?php foreach ($thread as $m): ?>
            <div class="msg msg-<?= e($m['sender']) ?>">
                <?php if ($m['sender'] === 'system'): ?>
                    <small class="msg-who">Tự động trả lời</small>
                <?php elseif ($m['sender'] === 'admin'): ?>
                    <small class="msg-who"><?= e($m['admin_name'] ?? 'Quản trị viên') ?></small>
                <?php endif; ?>
                <div class="bubble"><?= nl2br(e($m['content'])) ?></div>
                <time><?= e(fmt_date($m['created_at'], 'd/m/Y H:i')) ?></time>
            </div>
        <?php endforeach; ?>
        <?php if (!$thread): ?><div class="empty compact"><p class="muted">Chưa có tin nhắn nào trong hội thoại này.</p></div><?php endif; ?>
    </div>

    <form class="reply" method="post" action="<?= e(admin_url('messages/' . $customer['id'] . '/reply')) ?>">
        <?= csrf_field() ?>
        <label class="field <?= $error ? 'has-error' : '' ?>">
            <span>Phản hồi của bạn</span>
            <textarea class="input" name="content" rows="3" maxlength="2000" placeholder="Nhập nội dung gửi tới <?= e(first_name($customer['full_name'])) ?>…" required><?= e($draft) ?></textarea>
            <?php if ($error): ?><small class="field-error"><?= e($error) ?></small><?php endif; ?>
        </label>
        <div class="form-actions"><button class="btn btn-primary" type="submit"><?= icon('send', 16) ?> Gửi phản hồi</button></div>
    </form>
</section>
