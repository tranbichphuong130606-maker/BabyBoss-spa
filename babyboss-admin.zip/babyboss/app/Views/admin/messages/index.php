<?php
/** @var array $conversations @var array $filters @var \App\Core\Paginator $pager */
$hasFilter = $filters['q'] !== '' || $filters['status'] !== '';
$tabs      = ['' => 'Tất cả', 'waiting' => 'Chờ phản hồi', 'answered' => 'Đã phản hồi'];
?>
<div class="page-head">
    <div>
        <h1>Tin nhắn</h1>
        <p class="muted">Tin nhắn khách gửi qua trang liên hệ. Hệ thống đã tự động trả lời, đang chờ nhân viên phản hồi thật.</p>
    </div>
</div>

<section class="card">
    <nav class="tabs" aria-label="Lọc theo trạng thái">
        <?php foreach ($tabs as $key => $label): ?>
            <a class="<?= $filters['status'] === $key ? 'active' : '' ?>" href="<?= e(admin_url('messages', ['q' => $filters['q'], 'status' => $key])) ?>"><?= e($label) ?></a>
        <?php endforeach; ?>
    </nav>

    <form class="toolbar" method="get" action="<?= e(admin_url()) ?>">
        <?= route_field('messages') ?>
        <?php if ($filters['status'] !== ''): ?><input type="hidden" name="status" value="<?= e($filters['status']) ?>"><?php endif; ?>
        <label class="search"><?= icon('search') ?>
            <input type="search" name="q" value="<?= e($filters['q']) ?>" placeholder="Tìm theo tên, email hoặc số điện thoại khách">
        </label>
        <button class="btn btn-primary" type="submit">Tìm</button>
        <?php if ($hasFilter): ?><a class="btn btn-ghost" href="<?= e(admin_url('messages')) ?>">Bỏ lọc</a><?php endif; ?>
    </form>

    <div class="table-wrap">
        <table class="table">
            <thead>
            <tr><th>Khách hàng</th><th class="wide">Tin nhắn gần nhất</th><th>Cập nhật</th><th>Trạng thái</th><th class="actions">Thao tác</th></tr>
            </thead>
            <tbody>
            <?php foreach ($conversations as $c): ?>
                <?php
                $waiting = (int) $c['pending_count'] > 0;
                $who     = match ($c['last_sender']) { 'admin' => 'Bạn: ', 'system' => 'Tự động: ', default => '' };
                ?>
                <tr>
                    <td>
                        <div class="person">
                            <span class="avatar"><?= e(initial($c['full_name'])) ?></span>
                            <div><b><?= e($c['full_name']) ?></b><div class="muted small"><?= e($c['phone']) ?></div></div>
                        </div>
                    </td>
                    <td class="wide"><span class="clamp"><span class="muted"><?= e($who) ?></span><?= e($c['last_content']) ?></span></td>
                    <td class="muted"><?= e(fmt_date($c['last_at'], 'd/m H:i')) ?></td>
                    <td><?= $waiting ? badge('st-pending', 'Chờ phản hồi (' . (int) $c['pending_count'] . ')') : badge('st-completed', 'Đã phản hồi') ?></td>
                    <td class="actions">
                        <a class="btn btn-sm <?= $waiting ? 'btn-primary' : 'btn-outline' ?>" href="<?= e(admin_url('messages/' . $c['user_id'])) ?>"><?= icon('message', 15) ?> <?= $waiting ? 'Trả lời' : 'Xem hội thoại' ?></a>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$conversations): ?>
                <tr><td colspan="5">
                    <div class="empty">
                        <p><b><?= $hasFilter ? 'Không có hội thoại nào khớp bộ lọc.' : 'Chưa có tin nhắn nào từ khách.' ?></b></p>
                        <p class="muted"><?= $hasFilter ? 'Thử đổi từ khóa hoặc chọn tab "Tất cả".' : 'Khi khách gửi tin ở trang liên hệ, hội thoại sẽ hiện ở đây.' ?></p>
                    </div>
                </td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php partial('pagination', ['pager' => $pager, 'route' => 'messages', 'query' => $filters]); ?>
</section>
