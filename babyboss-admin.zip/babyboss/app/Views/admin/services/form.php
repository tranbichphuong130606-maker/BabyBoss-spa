<?php
/** @var ?array $service @var array $old @var array $errors */
$editing = $service !== null;
$val     = fn(string $k, $d = '') => $old[$k] ?? $d;
$action  = $editing ? admin_url('services/' . $service['id'] . '/update') : admin_url('services/store');
$image   = $editing ? $service['image'] : null;
$maxMb   = round((int) config('upload.max_size', 2097152) / 1048576, 1);
$err     = fn(string $k): string => isset($errors[$k]) ? '<small class="field-error">' . e($errors[$k]) . '</small>' : '';
?>
<div class="page-head">
    <div>
        <a class="back-link" href="<?= e(admin_url('services')) ?>"><?= icon('back', 16) ?> Danh sách dịch vụ</a>
        <h1><?= $editing ? 'Sửa dịch vụ' : 'Thêm dịch vụ' ?></h1>
    </div>
</div>

<form class="form-layout" method="post" action="<?= e($action) ?>" enctype="multipart/form-data" novalidate>
    <?= csrf_field() ?>
    <section class="card pad">
        <label class="field <?= isset($errors['name']) ? 'has-error' : '' ?>">
            <span>Tên dịch vụ</span>
            <input class="input" name="name" value="<?= e($val('name')) ?>" maxlength="150" placeholder="Ví dụ: Tắm sấy cao cấp" required>
            <?= $err('name') ?>
        </label>
        <div class="row-2">
            <label class="field <?= isset($errors['price']) ? 'has-error' : '' ?>">
                <span>Giá (₫)</span>
                <input class="input" name="price" inputmode="numeric" value="<?= e($val('price')) ?>" placeholder="250000" required>
                <?= $err('price') ?>
            </label>
            <label class="field <?= isset($errors['duration']) ? 'has-error' : '' ?>">
                <span>Thời gian thực hiện (phút)</span>
                <input class="input" name="duration" inputmode="numeric" value="<?= e($val('duration')) ?>" placeholder="60" required>
                <?= $err('duration') ?>
            </label>
        </div>
        <label class="field <?= isset($errors['description']) ? 'has-error' : '' ?>">
            <span>Mô tả</span>
            <textarea class="input" name="description" rows="5" maxlength="2000" placeholder="Dịch vụ gồm những bước nào, phù hợp với bé nào?"><?= e($val('description')) ?></textarea>
            <?= $err('description') ?>
        </label>
        <label class="field">
            <span>Trạng thái</span>
            <select class="select" name="is_active">
                <option value="1" <?= (int) $val('is_active', 1) === 1 ? 'selected' : '' ?>>Đang hiển thị cho khách</option>
                <option value="0" <?= (int) $val('is_active', 1) === 0 ? 'selected' : '' ?>>Tạm ẩn</option>
            </select>
        </label>
    </section>

    <aside class="card pad">
        <h2>Ảnh minh họa</h2>
        <div class="preview">
            <img id="previewImg" alt="Ảnh dịch vụ" <?= $image ? 'src="' . e(upload_url($image)) . '"' : 'hidden' ?>>
            <span class="ph" id="previewPh" <?= $image ? 'hidden' : '' ?>><?= paw_icon(34) ?><small>Chưa có ảnh</small></span>
        </div>
        <label class="btn btn-outline file-btn">
            <?= icon('upload', 16) ?> <?= $image ? 'Đổi ảnh' : 'Chọn ảnh' ?>
            <input type="file" name="image" accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp" data-preview="previewImg">
        </label>
        <small class="muted">JPG, PNG hoặc WebP, tối đa <?= e($maxMb) ?> MB. Ảnh được đổi tên tự động khi lưu vào thư mục uploads.</small>
        <?= $err('image') ?>
    </aside>

    <div class="form-actions">
        <a class="btn btn-ghost" href="<?= e(admin_url('services')) ?>">Hủy bỏ</a>
        <button class="btn btn-primary" type="submit"><?= $editing ? 'Lưu thay đổi' : 'Thêm dịch vụ' ?></button>
    </div>
</form>
