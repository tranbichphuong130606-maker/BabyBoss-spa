<?php
/** @var array $services @var array $filters @var \App\Core\Paginator $pager */
$hasFilter = $filters['q'] !== '' || $filters['status'] !== '';
?>
<div class="page-head">
    <div>
        <h1>Dịch vụ spa</h1>
        <p class="muted">Thêm, sửa giá và mô tả, hoặc gỡ các dịch vụ khách có thể đặt.</p>
    </div>
    <a class="btn btn-primary" href="<?= e(admin_url('services/create')) ?>"><?= icon('plus') ?> Thêm dịch vụ</a>
</div>

<section class="card">
    <form class="toolbar" method="get" action="<?= e(admin_url()) ?>">
        <?= route_field('services') ?>
        <label class="search"><?= icon('search') ?>
            <input type="search" name="q" value="<?= e($filters['q']) ?>" placeholder="Tìm theo tên hoặc mô tả dịch vụ">
        </label>
        <select class="select" name="status" aria-label="Lọc theo trạng thái">
            <option value="">Mọi trạng thái</option>
            <option value="1" <?= $filters['status'] === '1' ? 'selected' : '' ?>>Đang hiển thị</option>
            <option value="0" <?= $filters['status'] === '0' ? 'selected' : '' ?>>Tạm ẩn</option>
        </select>
        <button class="btn btn-primary" type="submit">Lọc</button>
        <?php if ($hasFilter): ?><a class="btn btn-ghost" href="<?= e(admin_url('services')) ?>">Bỏ lọc</a><?php endif; ?>
    </form>

    <div class="table-wrap">
        <table class="table">
            <thead>
            <tr><th>Dịch vụ</th><th class="num">Giá</th><th>Thời gian</th><th class="num">Lượt đặt</th><th>Đánh giá</th><th>Trạng thái</th><th class="actions">Thao tác</th></tr>
            </thead>
            <tbody>
            <?php foreach ($services as $s): ?>
                <tr class="<?= $s['is_active'] ? '' : 'is-muted' ?>">
                    <td>
                        <div class="svc">
                            <?php if ($s['image']): ?>
                                <img class="thumb" src="<?= e(upload_url($s['image'])) ?>" alt="" loading="lazy">
                            <?php else: ?>
                                <span class="thumb ph"><?= paw_icon(20) ?></span>
                            <?php endif; ?>
                            <div><b><?= e($s['name']) ?></b><div class="muted small clamp"><?= e($s['description']) ?></div></div>
                        </div>
                    </td>
                    <td class="num"><b><?= e(money($s['price'])) ?></b></td>
                    <td><?= e(duration_text((int) $s['duration'])) ?></td>
                    <td class="num"><?= (int) $s['booking_count'] ?></td>
                    <td><?= $s['avg_rating'] !== null ? '<span class="rating">★ ' . e(number_format((float) $s['avg_rating'], 1, ',', '.')) . '</span>' : '<span class="muted">Chưa có</span>' ?></td>
                    <td><?= $s['is_active'] ? badge('st-completed', 'Đang hiển thị') : badge('st-hidden', 'Tạm ẩn') ?></td>
                    <td class="actions">
                        <a class="btn btn-sm btn-outline" href="<?= e(admin_url('services/' . $s['id'] . '/edit')) ?>"><?= icon('edit', 15) ?> Sửa</a>
                        <form method="post" action="<?= e(admin_url('services/' . $s['id'] . '/delete')) ?>"
                              data-confirm="<?= e('Xóa dịch vụ "' . $s['name'] . '"? Ảnh minh họa cũng bị xóa khỏi thư mục uploads. Không thể hoàn tác.') ?>"
                              data-confirm-label="Xóa dịch vụ">
                            <?= csrf_field() ?>
                            <button class="btn btn-sm btn-danger-ghost" type="submit" aria-label="Xóa <?= e($s['name']) ?>" title="Xóa dịch vụ"><?= icon('trash', 15) ?></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$services): ?>
                <tr><td colspan="7">
                    <div class="empty">
                        <p><b><?= $hasFilter ? 'Không có dịch vụ nào khớp bộ lọc.' : 'Chưa có dịch vụ nào.' ?></b></p>
                        <p class="muted"><?= $hasFilter ? 'Thử đổi từ khóa hoặc bỏ lọc.' : 'Bấm "Thêm dịch vụ" để tạo dịch vụ spa đầu tiên.' ?></p>
                    </div>
                </td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php partial('pagination', ['pager' => $pager, 'route' => 'services', 'query' => $filters]); ?>
</section>
