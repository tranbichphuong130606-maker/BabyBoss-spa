<?php /** @var string $email @var ?string $error @var array $flashes */ ?>
<!doctype html>
<html lang="vi">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($title) ?> – BabyBoss</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:wght@400;500;600;700&amp;display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= e(admin_asset('css/admin.css')) ?>">
</head>
<body class="plain">
<div class="auth">
    <section class="auth-art" aria-hidden="true">
        <span class="bubble b1"></span><span class="bubble b2"></span><span class="bubble b3"></span><span class="bubble b4"></span>
        <div class="auth-brand"><span class="brand-mark"><?= paw_icon(24) ?></span><b>BabyBoss</b></div>
        <h2>Mỗi bé cưng một buổi spa trọn vẹn.</h2>
        <p>Duyệt lịch, trả lời khách và chăm sóc hội viên ở cùng một nơi.</p>
    </section>

    <section class="auth-form">
        <form class="auth-card" method="post" action="<?= e(admin_url('login')) ?>">
            <h1>Đăng nhập quản trị</h1>
            <p class="muted">Dùng tài khoản quản trị viên của BabyBoss.</p>

            <?php foreach ($flashes as $f): ?>
                <div class="alert alert-<?= e($f['type']) ?>" role="status"><span><?= e($f['message']) ?></span></div>
            <?php endforeach; ?>
            <?php if ($error): ?>
                <div class="alert alert-error" role="alert"><span><?= e($error) ?></span></div>
            <?php endif; ?>

            <?= csrf_field() ?>
            <label class="field">
                <span>Email</span>
                <input class="input" type="email" name="email" value="<?= e($email) ?>" autocomplete="username" required autofocus>
            </label>
            <label class="field">
                <span>Mật khẩu</span>
                <span class="pw">
                    <input class="input" type="password" name="password" autocomplete="current-password" required>
                    <button type="button" class="pw-toggle" data-toggle-pw aria-label="Hiện mật khẩu"><?= icon('eye') ?></button>
                </span>
            </label>
            <button class="btn btn-primary btn-block" type="submit">Đăng nhập</button>

            <?php if (config('app.debug')): ?>
                <p class="hint">Tài khoản demo: <b>admin@babyboss.vn</b> / <b>Admin@123</b></p>
            <?php endif; ?>
            <a class="back-link" href="<?= e(base_url()) ?>"><?= icon('back', 16) ?> Về trang chủ</a>
        </form>
    </section>
</div>
<script src="<?= e(admin_asset('js/admin.js')) ?>"></script>
</body>
</html>
