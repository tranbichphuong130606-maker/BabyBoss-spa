<?php
/** @var array $appointments @var array $filters @var \App\Core\Paginator $pager @var array $counts */
use App\Models\Appointment;

$hasFilter = $filters['q'] !== '' || $filters['date'] !== '';
$tabUrl    = fn(string $status): string => admin_url('appointments', array_merge($filters, ['status' => $status, 'page' => null]));
?>
<div class="page-head">
    <div>
        <h1>Lịch đặt spa</h1>
        <p class="muted">Duyệt lịch khách gửi lên, đánh dấu hoàn thành để cộng điểm thưởng, hoặc hủy lịch.</p>
    </div>
</div>

<section class="card">
    <nav class="tabs" aria-label="Lọc theo trạng thái">
        <a class="<?= $filters['status'] === '' ? 'active' : '' ?>" href="<?= e($tabUrl('')) ?>">Tất cả <span><?= array_sum($counts) ?></span></a>
        <?php foreach (Appointment::STATUSES as $key => $label): ?>
            <a class="<?= $filters['status'] === $key ? 'active' : '' ?>" href="<?= e($tabUrl($key)) ?>"><?= e($label) ?> <span><?= (int) $counts[$key] ?></span></a>
        <?php endforeach; ?>
    </nav>

    <form class="toolbar" method="get" action="<?= e(admin_url()) ?>">
        <?= route_field('appointments') ?>
        <?php if ($filters['status'] !== ''): ?><input type="hidden" name="status" value="<?= e($filters['status']) ?>"><?php endif; ?>
        <label class="search"><?= icon('search') ?>
            <input type="search" name="q" value="<?= e($filters['q']) ?>" placeholder="Tìm theo tên khách, SĐT, thú cưng hoặc mã lịch (LH0007)">
        </label>
        <input class="input" type="date" name="date" value="<?= e($filters['date']) ?>" aria-label="Lọc theo ngày">
        <select class="select" name="date_type" aria-label="Loại ngày">
            <option value="appointment" <?= $filters['date_type'] === 'appointment' ? 'selected' : '' ?>>Ngày hẹn</option>
            <option value="created" <?= $filters['date_type'] === 'created' ? 'selected' : '' ?>>Ngày đặt lịch</option>
        </select>
        <button class="btn btn-primary" type="submit">Lọc</button>
        <?php if ($hasFilter): ?><a class="btn btn-ghost" href="<?= e(admin_url('appointments', ['status' => $filters['status']])) ?>">Bỏ lọc</a><?php endif; ?>
    </form>

    <div class="table-wrap">
        <table class="table">
            <thead>
            <tr><th>Mã lịch</th><th>Khách hàng</th><th>Thú cưng</th><th>Dịch vụ</th><th>Giờ hẹn</th><th class="num">Thanh toán</th><th>Trạng thái</th><th class="actions">Thao tác</th></tr>
            </thead>
            <tbody>
            <?php foreach ($appointments as $a): ?>
                <?php $code = appt_code((int) $a['id']); ?>
                <tr>
                    <td><b><?= e($code) ?></b><div class="muted small">Đặt <?= e(fmt_date($a['created_at'], 'd/m H:i')) ?></div></td>
                    <td><b><?= e($a['customer_name']) ?></b><div class="muted small"><?= e($a['customer_phone']) ?></div></td>
                    <td><?php if ($a['pet_name'] !== null): ?><b><?= e($a['pet_name']) ?></b><div class="muted small"><?= e($a['pet_species']) ?></div><?php else: ?><span class="muted">Đã xóa hồ sơ</span><?php endif; ?></td>
                    <td><?= e($a['service_name']) ?></td>
                    <td>
                        <b><?= e(fmt_date($a['appointment_date'])) ?></b>
                        <?php if ($a['note']): ?><div class="muted small clamp" title="<?= e($a['note']) ?>">Ghi chú: <?= e($a['note']) ?></div><?php endif; ?>
                    </td>
                    <td class="num">
                        <b><?= e(money($a['total_amount'])) ?></b>
                        <?php if ((int) $a['points_used'] > 0): ?><div class="muted small">Dùng <?= (int) $a['points_used'] ?> điểm (−<?= e(money($a['discount'])) ?>)</div><?php endif; ?>
                    </td>
                    <td>
                        <?= badge('st-' . $a['status'], Appointment::STATUSES[$a['status']]) ?>
                        <?php if ((int) $a['points_earned'] > 0): ?><div class="muted small">Đã cộng <?= (int) $a['points_earned'] ?> điểm</div><?php endif; ?>
                    </td>
                    <td class="actions">
                        <?php foreach (Appointment::TRANSITIONS[$a['status']] as $to): ?>
                            <?php
                            $confirm = match ($to) {
                                'completed' => ['Đánh dấu lịch ' . $code . ' là đã hoàn thành? Hệ thống sẽ cộng điểm thưởng cho khách.', 'Hoàn thành lịch', 'primary'],
                                'cancelled' => ['Hủy lịch ' . $code . ' của ' . $a['customer_name'] . '? Nếu khách đã dùng điểm, điểm sẽ được hoàn lại.', 'Hủy lịch', 'danger'],
                                default     => null,
                            };
                            ?>
                            <form method="post" action="<?= e(admin_url('appointments/' . $a['id'] . '/status')) ?>"
                                <?= $confirm ? 'data-confirm="' . e($confirm[0]) . '" data-confirm-label="' . e($confirm[1]) . '" data-confirm-tone="' . $confirm[2] . '"' : '' ?>>
                                <?= csrf_field() ?>
                                <input type="hidden" name="status" value="<?= e($to) ?>">
                                <?php if ($to === 'confirmed'): ?>
                                    <button class="btn btn-sm btn-primary" type="submit"><?= icon('check', 15) ?> Duyệt lịch</button>
                                <?php elseif ($to === 'completed'): ?>
                                    <button class="btn btn-sm btn-outline" type="submit"><?= icon('check', 15) ?> Hoàn thành</button>
                                <?php else: ?>
                                    <button class="btn btn-sm btn-danger-ghost" type="submit"><?= icon('x', 15) ?> Hủy lịch</button>
                                <?php endif; ?>
                            </form>
                        <?php endforeach; ?>
                        <?php if (!Appointment::TRANSITIONS[$a['status']]): ?><span class="muted small">Đã đóng</span><?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$appointments): ?>
                <tr><td colspan="8">
                    <div class="empty">
                        <p><b>Không có lịch hẹn nào khớp điều kiện lọc.</b></p>
                        <p class="muted">Thử chọn tab "Tất cả", đổi ngày hoặc bỏ từ khóa tìm kiếm.</p>
                    </div>
                </td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php partial('pagination', ['pager' => $pager, 'route' => 'appointments', 'query' => $filters]); ?>
</section>
