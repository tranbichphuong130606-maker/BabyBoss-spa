<?php
/**
 * @var array $admin
 * @var array $stats
 * @var array $statusCounts
 * @var array $todayList
 * @var array $waiting
 */
use App\Models\Appointment;

$n     = fn($v): string => number_format((int) $v, 0, ',', '.');
$total = max(1, array_sum($statusCounts));
?>
<div class="page-head">
    <div>
        <h1>Xin chào, <?= e(first_name($admin['full_name'])) ?></h1>
        <p class="muted">Hôm nay là <?= e(mb_strtolower(today_vi())) ?>.</p>
    </div>
</div>

<section class="summary" aria-label="Số liệu tổng quan">
    <div class="sum-item">
        <span class="sum-label">Khách hàng</span>
        <strong><?= $n($stats['customers']) ?></strong>
        <span class="sum-note">tài khoản đã đăng ký</span>
    </div>
    <div class="sum-item">
        <span class="sum-label">Thú cưng</span>
        <strong><?= $n($stats['pets']) ?></strong>
        <span class="sum-note">hồ sơ đã được tạo</span>
    </div>
    <a class="sum-item sum-focus" href="<?= e(admin_url('appointments', ['status' => 'pending', 'date' => date('Y-m-d')])) ?>">
        <span class="sum-label">Chờ duyệt hôm nay</span>
        <strong><?= $n($stats['pendingToday']) ?></strong>
        <span class="sum-note">trong tổng <?= $n($stats['pendingTotal']) ?> lịch đang chờ duyệt</span>
    </a>
</section>

<div class="dash-grid">
    <section class="card schedule">
        <div class="card-head">
            <h2>Lịch hôm nay</h2>
            <a class="link" href="<?= e(admin_url('appointments', ['date' => date('Y-m-d')])) ?>">Xem trong danh sách lịch</a>
        </div>
        <?php if (!$todayList): ?>
            <div class="empty">
                <p><b>Hôm nay chưa có lịch hẹn nào.</b></p>
                <p class="muted">Lịch khách mới đặt cho hôm nay sẽ hiện ở đây.</p>
            </div>
        <?php else: ?>
            <ol class="timeline">
                <?php foreach ($todayList as $a): ?>
                    <li class="slot slot-<?= e($a['status']) ?>">
                        <time class="slot-time"><?= e(fmt_date($a['appointment_date'], 'H:i')) ?></time>
                        <div class="slot-body">
                            <div class="slot-title">
                                <b><?= e($a['pet_name'] ?? 'Thú cưng đã xóa') ?></b>
                                <span class="muted">của <?= e($a['customer_name']) ?></span>
                            </div>
                            <div class="muted small"><?= e($a['service_name']) ?>, <?= e(duration_text((int) $a['service_duration'])) ?></div>
                        </div>
                        <div class="slot-action">
                            <?php if ($a['status'] === 'pending' || $a['status'] === 'confirmed'): ?>
                                <?php $next = $a['status'] === 'pending' ? 'confirmed' : 'completed'; ?>
                                <form method="post" action="<?= e(admin_url('appointments/' . $a['id'] . '/status')) ?>"
                                      <?= $next === 'completed' ? 'data-confirm="Đánh dấu lịch ' . e(appt_code((int) $a['id'])) . ' là đã hoàn thành? Hệ thống sẽ cộng điểm thưởng cho khách." data-confirm-label="Hoàn thành lịch" data-confirm-tone="primary"' : '' ?>>
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="status" value="<?= e($next) ?>">
                                    <button class="btn btn-sm <?= $next === 'confirmed' ? 'btn-primary' : 'btn-outline' ?>" type="submit">
                                        <?= $next === 'confirmed' ? 'Duyệt lịch' : 'Hoàn thành' ?>
                                    </button>
                                </form>
                            <?php else: ?>
                                <?= badge('st-' . $a['status'], Appointment::STATUSES[$a['status']]) ?>
                            <?php endif; ?>
                        </div>
                    </li>
                <?php endforeach; ?>
            </ol>
        <?php endif; ?>
    </section>

    <div class="stack">
        <section class="card">
            <div class="card-head"><h2>Trạng thái lịch hẹn</h2></div>
            <div class="stackbar" role="img" aria-label="Tỷ lệ lịch hẹn theo trạng thái">
                <?php foreach (Appointment::STATUSES as $key => $label): ?>
                    <?php if ($statusCounts[$key] > 0): ?><span class="seg seg-<?= e($key) ?>" style="flex:<?= (int) $statusCounts[$key] ?>"></span><?php endif; ?>
                <?php endforeach; ?>
            </div>
            <ul class="legend">
                <?php foreach (Appointment::STATUSES as $key => $label): ?>
                    <li>
                        <i class="dot seg-<?= e($key) ?>"></i>
                        <a href="<?= e(admin_url('appointments', ['status' => $key])) ?>"><?= e($label) ?></a>
                        <b><?= $n($statusCounts[$key]) ?></b>
                    </li>
                <?php endforeach; ?>
            </ul>
            <dl class="facts">
                <div><dt>Dịch vụ đang hiển thị</dt><dd><?= $n($stats['services']) ?></dd></div>
                <div><dt>Đánh giá trung bình</dt><dd><?= $stats['rating'] !== null ? e(number_format((float) $stats['rating'], 1, ',', '.')) . ' / 5' : 'Chưa có' ?></dd></div>
            </dl>
        </section>

        <section class="card">
            <div class="card-head">
                <h2>Tin nhắn chờ phản hồi</h2>
                <a class="link" href="<?= e(admin_url('messages', ['status' => 'waiting'])) ?>">Xem tất cả</a>
            </div>
            <?php if (!$waiting): ?>
                <div class="empty compact"><p class="muted">Không còn tin nhắn nào đang chờ bạn trả lời.</p></div>
            <?php else: ?>
                <ul class="mini-list">
                    <?php foreach ($waiting as $c): ?>
                        <li>
                            <a href="<?= e(admin_url('messages/' . $c['user_id'])) ?>">
                                <span class="avatar sm"><?= e(initial($c['full_name'])) ?></span>
                                <span class="mini-text">
                                    <b><?= e($c['full_name']) ?></b>
                                    <span class="muted small clamp"><?= e($c['last_content']) ?></span>
                                </span>
                                <em class="count"><?= (int) $c['pending_count'] ?></em>
                            </a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        </section>
    </div>
</div>
