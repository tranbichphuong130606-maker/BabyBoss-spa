<?php /** @var int $code @var string $message */ ?>
<!doctype html>
<html lang="vi">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($title) ?> – BabyBoss Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:wght@400;600;700&amp;display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= e(admin_asset('css/admin.css')) ?>">
</head>
<body class="plain">
<main class="error-box">
    <div class="error-code"><?= (int) $code ?></div>
    <h1><?= e($message) ?></h1>
    <p class="muted">Nếu lỗi vẫn lặp lại, hãy quay về trang tổng quan và thao tác lại từ đầu.</p>
    <a class="btn btn-primary" href="<?= e(admin_url('dashboard')) ?>">Về trang tổng quan</a>
</main>
</body>
</html>
