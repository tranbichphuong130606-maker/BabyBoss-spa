<?php
namespace App\Models;

use App\Core\Model;

/** Lịch sử giao dịch điểm thưởng (points mang dấu: + cộng, - trừ). */
final class LoyaltyTransaction extends Model
{
    public const TYPES = [
        'earn'   => 'Tích điểm',
        'redeem' => 'Dùng điểm',
        'refund' => 'Hoàn điểm',
        'adjust' => 'Admin điều chỉnh',
    ];

    private function where(array $f): array
    {
        $where  = ['1 = 1'];
        $params = [];
        if (($f['q'] ?? '') !== '') {
            $like    = $this->like($f['q']);
            $where[] = "(u.full_name LIKE :q1 OR u.email LIKE :q2 OR u.phone LIKE :q3 OR CONCAT('LH', LPAD(t.appointment_id, 4, '0')) LIKE :q4)";
            $params += ['q1' => $like, 'q2' => $like, 'q3' => $like, 'q4' => $like];
        }
        if (isset(self::TYPES[$f['type'] ?? ''])) {
            $where[]        = 't.type = :type';
            $params['type'] = $f['type'];
        }
        if ((int) ($f['user_id'] ?? 0) > 0) {
            $where[]       = 't.user_id = :uid';
            $params['uid'] = (int) $f['user_id'];
        }
        return [implode(' AND ', $where), $params];
    }

    public function count(array $f = []): int
    {
        [$where, $params] = $this->where($f);
        return (int) $this->scalar(
            "SELECT COUNT(*) FROM loyalty_transactions t JOIN users u ON u.id = t.user_id WHERE $where",
            $params
        );
    }

    public function paginate(array $f, int $limit, int $offset): array
    {
        [$where, $params] = $this->where($f);
        return $this->fetchAll(
            "SELECT t.*, u.full_name AS customer_name, u.email AS customer_email, ad.full_name AS admin_name
             FROM loyalty_transactions t
             JOIN users u ON u.id = t.user_id
             LEFT JOIN users ad ON ad.id = t.admin_id
             WHERE $where ORDER BY t.created_at DESC, t.id DESC LIMIT :limit OFFSET :offset",
            $params + ['limit' => $limit, 'offset' => $offset]
        );
    }

    public function record(int $userId, string $type, int $points, int $balanceAfter, ?int $appointmentId, string $note, ?int $adminId): void
    {
        $this->run(
            'INSERT INTO loyalty_transactions (user_id, type, points, balance_after, appointment_id, note, admin_id)
             VALUES (:u, :t, :p, :b, :a, :n, :ad)',
            ['u' => $userId, 't' => $type, 'p' => $points, 'b' => $balanceAfter, 'a' => $appointmentId, 'n' => $note, 'ad' => $adminId]
        );
    }
}
