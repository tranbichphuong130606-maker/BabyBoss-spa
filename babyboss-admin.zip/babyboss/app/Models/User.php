<?php
namespace App\Models;

use App\Core\Model;

final class User extends Model
{
    public function find(int $id): ?array
    {
        $user = $this->fetchOne('SELECT * FROM users WHERE id = :id', ['id' => $id]);
        if ($user) {
            unset($user['password']);   // không đưa mật khẩu băm ra khỏi model
        }
        return $user;
    }

    public function findByEmail(string $email): ?array
    {
        return $this->fetchOne('SELECT * FROM users WHERE email = :email', ['email' => $email]);
    }

    /** Khóa dòng người dùng trong transaction (dùng khi cộng/trừ điểm). */
    public function lockForUpdate(int $id): ?array
    {
        return $this->fetchOne("SELECT id, full_name, points, total_spent FROM users WHERE id = :id AND role = 'customer' FOR UPDATE", ['id' => $id]);
    }

    public function updatePassword(int $id, string $hash): void
    {
        $this->run('UPDATE users SET password = :p WHERE id = :id', ['p' => $hash, 'id' => $id]);
    }

    public function setStatus(int $id, string $status): void
    {
        $this->run("UPDATE users SET status = :s WHERE id = :id AND role = 'customer'", ['s' => $status, 'id' => $id]);
    }

    public function delete(int $id): void
    {
        $this->run("DELETE FROM users WHERE id = :id AND role = 'customer'", ['id' => $id]);
    }

    /** Ghi số dư điểm mới và cộng dồn tổng chi tiêu (dùng xét hạng thành viên). */
    public function applyPoints(int $id, int $newPoints, int $addSpent = 0): void
    {
        $this->run('UPDATE users SET points = :p, total_spent = total_spent + :s WHERE id = :id', ['p' => $newPoints, 's' => $addSpent, 'id' => $id]);
    }

    private function customerWhere(array $f): array
    {
        $where  = ["u.role = 'customer'"];
        $params = [];
        if (($f['q'] ?? '') !== '') {
            $like    = $this->like($f['q']);
            $where[] = '(u.full_name LIKE :q1 OR u.email LIKE :q2 OR u.phone LIKE :q3)';
            $params += ['q1' => $like, 'q2' => $like, 'q3' => $like];
        }
        if (in_array($f['status'] ?? '', ['active', 'locked'], true)) {
            $where[]          = 'u.status = :status';
            $params['status'] = $f['status'];
        }
        return [implode(' AND ', $where), $params];
    }

    public function countCustomers(array $f = []): int
    {
        [$where, $params] = $this->customerWhere($f);
        return (int) $this->scalar("SELECT COUNT(*) FROM users u WHERE $where", $params);
    }

    /** Danh sách khách hàng kèm số thú cưng, số lịch hẹn và hạng thành viên. */
    public function customers(array $f, int $limit, int $offset): array
    {
        [$where, $params] = $this->customerWhere($f);
        return $this->fetchAll(
            "SELECT u.id, u.full_name, u.email, u.phone, u.status, u.points, u.total_spent, u.created_at,
                    (SELECT COUNT(*) FROM pets p WHERE p.user_id = u.id) AS pet_count,
                    (SELECT COUNT(*) FROM appointments a WHERE a.user_id = u.id) AS appointment_count,
                    (SELECT t.name FROM membership_tiers t WHERE t.min_spent <= u.total_spent ORDER BY t.min_spent DESC LIMIT 1) AS tier_name
             FROM users u WHERE $where
             ORDER BY u.id DESC LIMIT :limit OFFSET :offset",
            $params + ['limit' => $limit, 'offset' => $offset]
        );
    }
}
