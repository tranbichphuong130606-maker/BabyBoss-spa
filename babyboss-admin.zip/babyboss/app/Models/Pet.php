<?php
namespace App\Models;

use App\Core\Model;
use PDO;

final class Pet extends Model
{
    public function count(): int
    {
        return (int) $this->scalar('SELECT COUNT(*) FROM pets');
    }

    /** Tên file avatar của các thú cưng thuộc một khách hàng (để dọn file khi xóa tài khoản). */
    public function avatarsOfUser(int $userId): array
    {
        return $this->run('SELECT avatar FROM pets WHERE user_id = :u AND avatar IS NOT NULL', ['u' => $userId])->fetchAll(PDO::FETCH_COLUMN);
    }
}
