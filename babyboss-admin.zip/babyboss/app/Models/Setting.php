<?php
namespace App\Models;

use App\Core\Model;

/** Cấu hình dạng khóa - giá trị (ví dụ: point_value = số VNĐ cho 1 điểm). */
final class Setting extends Model
{
    public function get(string $key, string $default = ''): string
    {
        $value = $this->scalar('SELECT setting_value FROM settings WHERE setting_key = :k', ['k' => $key]);
        return $value === null ? $default : (string) $value;
    }

    public function set(string $key, string $value): void
    {
        $this->run(
            'INSERT INTO settings (setting_key, setting_value) VALUES (:k, :v) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)',
            ['k' => $key, 'v' => $value]
        );
    }
}
