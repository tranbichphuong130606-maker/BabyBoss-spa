<?php
namespace App\Models;

use App\Core\Model;

/** Hạng thành viên: Bạc / Vàng / Kim Cương (ngưỡng chi tiêu + tỷ lệ tích điểm %). */
final class MembershipTier extends Model
{
    public function all(): array
    {
        return $this->fetchAll('SELECT * FROM membership_tiers ORDER BY min_spent ASC, id ASC');
    }

    /** Hạng cao nhất mà tổng chi tiêu đạt được. */
    public function forSpent(int $spent): array
    {
        return $this->fetchOne('SELECT * FROM membership_tiers WHERE min_spent <= :s ORDER BY min_spent DESC LIMIT 1', ['s' => $spent])
            ?? $this->fetchOne('SELECT * FROM membership_tiers ORDER BY min_spent ASC LIMIT 1')
            ?? ['id' => 0, 'name' => 'Bạc', 'min_spent' => 0, 'earn_rate' => '1.00'];
    }

    public function save(int $id, int $minSpent, float $earnRate): void
    {
        $this->run(
            'UPDATE membership_tiers SET min_spent = :m, earn_rate = :r WHERE id = :id',
            ['m' => $minSpent, 'r' => number_format($earnRate, 2, '.', ''), 'id' => $id]
        );
    }
}
