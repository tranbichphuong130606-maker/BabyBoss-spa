<?php
namespace App\Models;

use App\Core\Model;

final class Appointment extends Model
{
    public const STATUSES = [
        'pending'   => 'Chờ duyệt',
        'confirmed' => 'Đã xác nhận',
        'completed' => 'Đã hoàn thành',
        'cancelled' => 'Đã hủy',
    ];

    /** Luồng trạng thái hợp lệ: hoàn thành / hủy là trạng thái cuối. */
    public const TRANSITIONS = [
        'pending'   => ['confirmed', 'cancelled'],
        'confirmed' => ['completed', 'cancelled'],
        'completed' => [],
        'cancelled' => [],
    ];

    private const SELECT = "SELECT a.*, u.full_name AS customer_name, u.phone AS customer_phone,
                                   p.name AS pet_name, p.species AS pet_species, s.name AS service_name, s.duration AS service_duration
                            FROM appointments a
                            JOIN users u ON u.id = a.user_id
                            LEFT JOIN pets p ON p.id = a.pet_id
                            JOIN services s ON s.id = a.service_id";

    private function where(array $f): array
    {
        $where  = ['1 = 1'];
        $params = [];
        $q      = $f['q'] ?? '';
        if ($q !== '') {
            if (preg_match('/^#?LH0*(\d+)$/i', $q, $m)) {        // tìm theo mã lịch: LH0007
                $where[]        = 'a.id = :code';
                $params['code'] = (int) $m[1];
            } else {
                $like    = $this->like($q);
                $where[] = '(u.full_name LIKE :q1 OR u.phone LIKE :q2 OR p.name LIKE :q3 OR s.name LIKE :q4)';
                $params += ['q1' => $like, 'q2' => $like, 'q3' => $like, 'q4' => $like];
            }
        }
        if (!empty($f['date'])) {
            $col      = ($f['date_type'] ?? '') === 'created' ? 'a.created_at' : 'a.appointment_date';
            $where[]  = "$col >= :d1 AND $col < :d2";
            $params['d1'] = $f['date'] . ' 00:00:00';
            $params['d2'] = date('Y-m-d', strtotime($f['date'] . ' +1 day')) . ' 00:00:00';
        }
        if (!empty($f['status'])) {
            $where[]          = 'a.status = :status';
            $params['status'] = $f['status'];
        }
        return [implode(' AND ', $where), $params];
    }

    public function count(array $f = []): int
    {
        [$where, $params] = $this->where($f);
        return (int) $this->scalar(
            "SELECT COUNT(*) FROM appointments a
             JOIN users u ON u.id = a.user_id LEFT JOIN pets p ON p.id = a.pet_id JOIN services s ON s.id = a.service_id
             WHERE $where",
            $params
        );
    }

    public function paginate(array $f, int $limit, int $offset): array
    {
        [$where, $params] = $this->where($f);
        return $this->fetchAll(
            self::SELECT . " WHERE $where ORDER BY a.appointment_date DESC, a.id DESC LIMIT :limit OFFSET :offset",
            $params + ['limit' => $limit, 'offset' => $offset]
        );
    }

    /** Các lịch hẹn diễn ra trong ngày hôm nay, theo giờ hẹn. */
    public function today(int $limit = 10): array
    {
        return $this->fetchAll(
            self::SELECT . ' WHERE a.appointment_date >= CURDATE() AND a.appointment_date < CURDATE() + INTERVAL 1 DAY
                             ORDER BY a.appointment_date ASC, a.id ASC LIMIT :limit',
            ['limit' => $limit]
        );
    }

    public function find(int $id): ?array
    {
        return $this->fetchOne('SELECT * FROM appointments WHERE id = :id', ['id' => $id]);
    }

    public function lockForUpdate(int $id): ?array
    {
        return $this->fetchOne('SELECT * FROM appointments WHERE id = :id FOR UPDATE', ['id' => $id]);
    }

    public function updateStatus(int $id, string $status): void
    {
        $this->run('UPDATE appointments SET status = :s WHERE id = :id', ['s' => $status, 'id' => $id]);
    }

    public function setPointsEarned(int $id, int $points): void
    {
        $this->run('UPDATE appointments SET points_earned = :p WHERE id = :id', ['p' => $points, 'id' => $id]);
    }

    /** Đếm theo từng trạng thái (luôn đủ 4 khóa). */
    public function countByStatus(): array
    {
        $counts = array_fill_keys(array_keys(self::STATUSES), 0);
        foreach ($this->fetchAll('SELECT status, COUNT(*) AS c FROM appointments GROUP BY status') as $row) {
            $counts[$row['status']] = (int) $row['c'];
        }
        return $counts;
    }

    public function countPending(): int
    {
        return (int) $this->scalar("SELECT COUNT(*) FROM appointments WHERE status = 'pending'");
    }

    /** Lịch đang chờ duyệt có giờ hẹn rơi vào ngày hôm nay. */
    public function countPendingToday(): int
    {
        return (int) $this->scalar(
            "SELECT COUNT(*) FROM appointments
             WHERE status = 'pending' AND appointment_date >= CURDATE() AND appointment_date < CURDATE() + INTERVAL 1 DAY"
        );
    }
}
