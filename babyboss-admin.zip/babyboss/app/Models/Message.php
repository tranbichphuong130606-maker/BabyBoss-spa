<?php
namespace App\Models;

use App\Core\Model;

/**
 * Tin nhắn dạng hội thoại: mỗi khách hàng có một luồng tin nhắn.
 * sender = customer (khách gửi) | system (tự động trả lời) | admin (nhân viên phản hồi)
 */
final class Message extends Model
{
    /** Số tin của khách chưa được admin phản hồi trong mỗi hội thoại. */
    private const PENDING_SUM = "CAST(SUM(m.sender = 'customer' AND m.is_handled = 0) AS UNSIGNED)";

    private function filters(array $f): array
    {
        $where  = ['1 = 1'];
        $params = [];
        if (($f['q'] ?? '') !== '') {
            $like    = $this->like($f['q']);
            $where[] = '(u.full_name LIKE :q1 OR u.email LIKE :q2 OR u.phone LIKE :q3)';
            $params += ['q1' => $like, 'q2' => $like, 'q3' => $like];
        }
        $having = match ($f['status'] ?? '') {
            'waiting'  => 'HAVING ' . self::PENDING_SUM . ' > 0',
            'answered' => 'HAVING ' . self::PENDING_SUM . ' = 0',
            default    => '',
        };
        return [implode(' AND ', $where), $having, $params];
    }

    public function countConversations(array $f = []): int
    {
        [$where, $having, $params] = $this->filters($f);
        return (int) $this->scalar(
            "SELECT COUNT(*) FROM (SELECT u.id FROM messages m JOIN users u ON u.id = m.user_id
                                   WHERE $where GROUP BY u.id $having) t",
            $params
        );
    }

    /** Danh sách hội thoại: ưu tiên hội thoại đang chờ phản hồi, sau đó theo tin nhắn mới nhất. */
    public function conversations(array $f, int $limit, int $offset): array
    {
        [$where, $having, $params] = $this->filters($f);
        $pending = self::PENDING_SUM;
        return $this->fetchAll(
            "SELECT u.id AS user_id, u.full_name, u.email, u.phone,
                    COUNT(m.id) AS total_messages, MAX(m.created_at) AS last_at,
                    $pending AS pending_count,
                    (SELECT m2.content FROM messages m2 WHERE m2.user_id = u.id ORDER BY m2.id DESC LIMIT 1) AS last_content,
                    (SELECT m3.sender FROM messages m3 WHERE m3.user_id = u.id ORDER BY m3.id DESC LIMIT 1) AS last_sender
             FROM messages m JOIN users u ON u.id = m.user_id
             WHERE $where
             GROUP BY u.id, u.full_name, u.email, u.phone
             $having
             ORDER BY ($pending > 0) DESC, MAX(m.created_at) DESC
             LIMIT :limit OFFSET :offset",
            $params + ['limit' => $limit, 'offset' => $offset]
        );
    }

    public function thread(int $userId): array
    {
        return $this->fetchAll(
            'SELECT m.*, a.full_name AS admin_name FROM messages m
             LEFT JOIN users a ON a.id = m.admin_id
             WHERE m.user_id = :u ORDER BY m.created_at ASC, m.id ASC',
            ['u' => $userId]
        );
    }

    public function add(int $userId, string $sender, string $content, ?int $adminId = null): void
    {
        $this->run(
            'INSERT INTO messages (user_id, sender, content, is_handled, admin_id) VALUES (:u, :s, :c, :h, :a)',
            ['u' => $userId, 's' => $sender, 'c' => $content, 'h' => $sender === 'customer' ? 0 : 1, 'a' => $adminId]
        );
    }

    /** Đánh dấu mọi tin của khách trong hội thoại là đã được phản hồi. */
    public function markHandled(int $userId): void
    {
        $this->run("UPDATE messages SET is_handled = 1 WHERE user_id = :u AND sender = 'customer' AND is_handled = 0", ['u' => $userId]);
    }

    /** Số khách hàng đang chờ admin phản hồi. */
    public function countAwaiting(): int
    {
        return (int) $this->scalar("SELECT COUNT(DISTINCT user_id) FROM messages WHERE sender = 'customer' AND is_handled = 0");
    }
}
