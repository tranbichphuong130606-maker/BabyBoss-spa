<?php
namespace App\Controllers\Admin;

use App\Core\{Auth, Controller, Paginator};
use App\Models\{Message, User};

/** Xem và phản hồi tin nhắn của khách hàng (mỗi khách một hội thoại). */
final class MessageController extends Controller
{
    public function index(): void
    {
        $filters = ['q' => $this->request->query('q'), 'status' => $this->request->query('status')];
        $model   = new Message();
        $pager   = new Paginator($model->countConversations($filters), (int) config('per_page.messages', 8), $this->request->page());

        $this->view('messages/index', [
            'title'         => 'Tin nhắn',
            'active'        => 'messages',
            'filters'       => $filters,
            'pager'         => $pager,
            'conversations' => $model->conversations($filters, $pager->perPage, $pager->offset()),
        ]);
    }

    public function show(int $userId): void
    {
        $customer = $this->customer($userId);
        $this->view('messages/show', [
            'title'    => 'Hội thoại với ' . $customer['full_name'],
            'active'   => 'messages',
            'customer' => $customer,
            'thread'   => (new Message())->thread($userId),
            'error'    => null,
            'draft'    => '',
        ]);
    }

    public function reply(int $userId): void
    {
        $customer = $this->customer($userId);
        $content  = $this->request->input('content');
        $model    = new Message();

        if ($content === '' || mb_strlen($content) > 2000) {
            $this->view('messages/show', [
                'title'    => 'Hội thoại với ' . $customer['full_name'],
                'active'   => 'messages',
                'customer' => $customer,
                'thread'   => $model->thread($userId),
                'error'    => 'Nội dung phản hồi cần từ 1 đến 2.000 ký tự.',
                'draft'    => $content,
            ]);
            return;
        }

        $model->add($userId, 'admin', $content, Auth::id());
        $model->markHandled($userId);
        $this->flash('success', 'Đã gửi phản hồi tới ' . $customer['full_name'] . '.');
        $this->redirect('messages/' . $userId);
    }

    private function customer(int $userId): array
    {
        $customer = (new User())->find($userId);
        if ($customer === null || $customer['role'] !== 'customer') {
            $this->notFound('Không tìm thấy khách hàng.');
        }
        return $customer;
    }
}
