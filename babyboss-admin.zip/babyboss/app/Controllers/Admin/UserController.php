<?php
namespace App\Controllers\Admin;

use App\Core\{Controller, ImageUploader, Paginator, Request};
use App\Models\{Pet, User};

/** Quản lý tài khoản khách hàng: xem, tìm kiếm, phân trang, khóa / mở khóa, xóa. */
final class UserController extends Controller
{
    private User $users;

    public function __construct(Request $request)
    {
        parent::__construct($request);
        $this->users = new User();
    }

    public function index(): void
    {
        $filters = ['q' => $this->request->query('q'), 'status' => $this->request->query('status')];
        $pager   = new Paginator($this->users->countCustomers($filters), (int) config('per_page.users', 8), $this->request->page());

        $this->view('users/index', [
            'title'     => 'Người dùng',
            'active'    => 'users',
            'filters'   => $filters,
            'pager'     => $pager,
            'customers' => $this->users->customers($filters, $pager->perPage, $pager->offset()),
        ]);
    }

    public function toggleLock(int $id): void
    {
        $user = $this->findCustomer($id);
        $lock = $user['status'] === 'active';
        $this->users->setStatus($id, $lock ? 'locked' : 'active');

        $this->flash('success', $lock
            ? 'Đã khóa tài khoản ' . $user['full_name'] . '. Khách sẽ không đăng nhập được cho đến khi được mở khóa.'
            : 'Đã mở khóa tài khoản ' . $user['full_name'] . '.');
        $this->back('users');
    }

    public function destroy(int $id): void
    {
        $user    = $this->findCustomer($id);
        $avatars = (new Pet())->avatarsOfUser($id);      // lấy trước khi xóa vì thú cưng bị xóa theo (CASCADE)

        $this->users->delete($id);

        $uploader = new ImageUploader(UPLOAD_PATH . '/pets');
        foreach ($avatars as $file) {
            $uploader->delete($file);
        }
        $this->flash('success', 'Đã xóa tài khoản ' . $user['full_name'] . ' cùng thú cưng, lịch hẹn và lịch sử điểm của khách.');
        $this->back('users');
    }

    private function findCustomer(int $id): array
    {
        $user = $this->users->find($id);
        if ($user === null || $user['role'] !== 'customer') {
            $this->notFound('Không tìm thấy tài khoản khách hàng.');
        }
        return $user;
    }
}
