<?php
namespace App\Controllers\Admin;

use App\Core\{Auth, Controller, Database, Paginator};
use App\Models\{LoyaltyTransaction, MembershipTier, Setting, User};
use App\Services\LoyaltyService;

/** Ví điểm khách hàng, điều chỉnh điểm thủ công, lịch sử giao dịch điểm, cấu hình hạng thành viên. */
final class LoyaltyController extends Controller
{
    /** Danh sách ví điểm của khách hàng. */
    public function index(): void
    {
        $filters = ['q' => $this->request->query('q')];
        $users   = new User();
        $tiers   = (new MembershipTier())->all();
        $pager   = new Paginator($users->countCustomers($filters), (int) config('per_page.loyalty', 10), $this->request->page());

        $rows = $users->customers($filters, $pager->perPage, $pager->offset());
        foreach ($rows as &$row) {
            $row['progress'] = LoyaltyService::progress((int) $row['total_spent'], $tiers);
        }
        unset($row);

        $this->view('loyalty/index', [
            'title'      => 'Ví điểm thưởng',
            'active'     => 'loyalty',
            'filters'    => $filters,
            'pager'      => $pager,
            'customers'  => $rows,
            'pointValue' => (new LoyaltyService())->pointValue(),
        ]);
    }

    /** Cộng / trừ / đặt lại điểm cho một khách hàng. */
    public function adjust(): void
    {
        $amount = $this->request->input('amount');
        if (!ctype_digit($amount)) {
            $this->flash('error', 'Số điểm phải là số nguyên không âm.');
            $this->back('loyalty');
        }
        $result = (new LoyaltyService())->adjust(
            (int) $this->request->input('user_id'),
            $this->request->input('mode'),
            (int) $amount,
            $this->request->input('note'),
            Auth::id()
        );
        $this->flash($result['ok'] ? 'success' : 'error', $result['message']);
        $this->back('loyalty');
    }

    /** Lịch sử giao dịch điểm (cộng / trừ, mã lịch, thời gian). */
    public function history(): void
    {
        $filters = [
            'q'       => $this->request->query('q'),
            'type'    => $this->request->query('type'),
            'user_id' => (int) $this->request->query('user_id', '0'),
        ];
        $model = new LoyaltyTransaction();
        $pager = new Paginator($model->count($filters), (int) config('per_page.history', 12), $this->request->page());

        $this->view('loyalty/history', [
            'title'        => 'Lịch sử điểm',
            'active'       => 'loyalty-history',
            'filters'      => $filters,
            'pager'        => $pager,
            'transactions' => $model->paginate($filters, $pager->perPage, $pager->offset()),
            'customer'     => $filters['user_id'] > 0 ? (new User())->find($filters['user_id']) : null,
        ]);
    }

    public function config(): void
    {
        $this->configForm([], null);
    }

    /** Lưu tỷ lệ tích điểm (1% - 5%), ngưỡng chi tiêu từng hạng và giá trị quy đổi 1 điểm. */
    public function saveConfig(): void
    {
        $tierModel = new MembershipTier();
        $tiers     = $tierModel->all();
        $input     = $this->request->inputArray('tiers');
        $pointRaw  = $this->request->input('point_value');

        $errors = [];
        $clean  = [];
        if (!ctype_digit($pointRaw) || (int) $pointRaw < 100 || (int) $pointRaw > 1000000) {
            $errors['point_value'] = 'Giá trị quy đổi của 1 điểm từ 100 đến 1.000.000 ₫.';
        }

        $prev = -1;
        foreach ($tiers as $i => $tier) {
            $id   = (int) $tier['id'];
            $row  = is_array($input[$id] ?? null) ? $input[$id] : [];
            $min  = $i === 0 ? '0' : (string) preg_replace('/[\s.,]/', '', (string) ($row['min_spent'] ?? ''));
            $rate = str_replace(',', '.', trim((string) ($row['earn_rate'] ?? '')));

            if (!ctype_digit($min) || (int) $min > 100000000000) {
                $errors['min_' . $id] = 'Ngưỡng chi tiêu phải là số nguyên không âm.';
            } elseif ($i > 0 && (int) $min <= $prev) {
                $errors['min_' . $id] = 'Ngưỡng của hạng ' . $tier['name'] . ' phải lớn hơn hạng liền trước.';
            }
            if (!is_numeric($rate) || (float) $rate < 1 || (float) $rate > 5) {
                $errors['rate_' . $id] = 'Tỷ lệ tích điểm phải từ 1% đến 5%.';
            }
            $clean[$id] = ['min' => (int) $min, 'rate' => (float) $rate];
            $prev       = (int) $min;
        }

        if ($errors) {
            $this->configForm($errors, ['point_value' => $pointRaw, 'tiers' => $input]);
            return;
        }

        $db = Database::connection();
        $db->beginTransaction();
        try {
            foreach ($clean as $id => $values) {
                $tierModel->save($id, $values['min'], $values['rate']);
            }
            (new Setting())->set('point_value', $pointRaw);
            $db->commit();
        } catch (\Throwable $e) {
            $db->rollBack();
            throw $e;
        }
        $this->flash('success', 'Đã lưu cấu hình điểm thưởng và hạng thành viên.');
        $this->redirect('loyalty/config');
    }

    private function configForm(array $errors, ?array $old): void
    {
        $this->view('loyalty/config', [
            'title'      => 'Hạng thành viên',
            'active'     => 'loyalty-config',
            'tiers'      => (new MembershipTier())->all(),
            'pointValue' => (new LoyaltyService())->pointValue(),
            'errors'     => $errors,
            'old'        => $old,
        ]);
    }
}
