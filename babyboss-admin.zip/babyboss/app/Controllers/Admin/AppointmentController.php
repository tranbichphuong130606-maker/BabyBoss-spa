<?php
namespace App\Controllers\Admin;

use App\Core\{Auth, Controller, Paginator};
use App\Models\Appointment;
use App\Services\AppointmentService;

/** Xem danh sách lịch đặt spa, tìm kiếm theo khách / ngày, duyệt - hoàn thành - hủy lịch. */
final class AppointmentController extends Controller
{
    public function index(): void
    {
        $date = $this->request->query('date');
        $dt   = \DateTime::createFromFormat('Y-m-d', $date);
        if (!$dt || $dt->format('Y-m-d') !== $date) {
            $date = '';
        }
        $status  = $this->request->query('status');
        $filters = [
            'q'         => $this->request->query('q'),
            'date'      => $date,
            'date_type' => $this->request->query('date_type') === 'created' ? 'created' : 'appointment',
            'status'    => isset(Appointment::STATUSES[$status]) ? $status : '',
        ];

        $model = new Appointment();
        $pager = new Paginator($model->count($filters), (int) config('per_page.appointments', 10), $this->request->page());

        $this->view('appointments/index', [
            'title'        => 'Lịch đặt spa',
            'active'       => 'appointments',
            'filters'      => $filters,
            'pager'        => $pager,
            'appointments' => $model->paginate($filters, $pager->perPage, $pager->offset()),
            'counts'       => $model->countByStatus(),
        ]);
    }

    public function updateStatus(int $id): void
    {
        $result = (new AppointmentService())->changeStatus($id, $this->request->input('status'), Auth::id());
        $this->flash($result['ok'] ? 'success' : 'error', $result['message']);
        $this->back('appointments');
    }
}
