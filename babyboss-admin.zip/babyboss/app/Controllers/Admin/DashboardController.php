<?php
namespace App\Controllers\Admin;

use App\Core\Controller;
use App\Models\{Appointment, Message, Pet, Review, Service, User};

/** Trang tổng quan: số liệu nhanh + lịch hẹn hôm nay. */
final class DashboardController extends Controller
{
    public function index(): void
    {
        $appointments = new Appointment();

        $this->view('dashboard/index', [
            'title'  => 'Tổng quan',
            'active' => 'dashboard',
            'stats'  => [
                'customers'    => (new User())->countCustomers(),
                'pets'         => (new Pet())->count(),
                'pendingToday' => $appointments->countPendingToday(),
                'pendingTotal' => $appointments->countPending(),
                'services'     => (new Service())->countActive(),
                'rating'       => (new Review())->stats()['avg_rating'],
            ],
            'statusCounts' => $appointments->countByStatus(),
            'todayList'    => $appointments->today(12),
            'waiting'      => (new Message())->conversations(['status' => 'waiting'], 5, 0),
        ]);
    }
}
