<?php
namespace App\Controllers\Admin;

use App\Core\{Controller, Paginator};
use App\Models\Review;

/** Kiểm duyệt đánh giá của khách: ẩn / hiện hoặc xóa đánh giá vi phạm. */
final class ReviewController extends Controller
{
    public function index(): void
    {
        $filters = [
            'q'      => $this->request->query('q'),
            'rating' => $this->request->query('rating'),
            'status' => $this->request->query('status'),
        ];
        $model = new Review();
        $pager = new Paginator($model->count($filters), (int) config('per_page.reviews', 8), $this->request->page());

        $this->view('reviews/index', [
            'title'   => 'Đánh giá',
            'active'  => 'reviews',
            'filters' => $filters,
            'pager'   => $pager,
            'reviews' => $model->paginate($filters, $pager->perPage, $pager->offset()),
            'stats'   => $model->stats(),
        ]);
    }

    public function toggle(int $id): void
    {
        $model  = new Review();
        $review = $model->find($id);
        if ($review === null) {
            $this->notFound('Không tìm thấy đánh giá.');
        }
        $hide = $review['status'] === 'visible';
        $model->setStatus($id, $hide ? 'hidden' : 'visible');
        $this->flash('success', $hide ? 'Đã ẩn đánh giá. Khách không còn thấy đánh giá này ở trang dịch vụ.' : 'Đã hiển thị lại đánh giá.');
        $this->back('reviews');
    }

    public function destroy(int $id): void
    {
        $model = new Review();
        if ($model->find($id) === null) {
            $this->notFound('Không tìm thấy đánh giá.');
        }
        $model->delete($id);
        $this->flash('success', 'Đã xóa đánh giá.');
        $this->back('reviews');
    }
}
