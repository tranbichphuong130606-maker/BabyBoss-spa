<?php
namespace App\Controllers\Admin;

use App\Core\{Controller, ImageUploader, Paginator, Request, UploadException};
use App\Models\Service;

/** CRUD dịch vụ spa, có upload ảnh minh họa vào thư mục uploads/services. */
final class ServiceController extends Controller
{
    private Service $services;

    public function __construct(Request $request)
    {
        parent::__construct($request);
        $this->services = new Service();
    }

    private function uploader(): ImageUploader
    {
        return new ImageUploader(UPLOAD_PATH . '/services', (int) config('upload.max_size', 2097152));
    }

    public function index(): void
    {
        $filters = ['q' => $this->request->query('q'), 'status' => $this->request->query('status')];
        $pager   = new Paginator($this->services->count($filters), (int) config('per_page.services', 6), $this->request->page());

        $this->view('services/index', [
            'title'    => 'Dịch vụ spa',
            'active'   => 'services',
            'filters'  => $filters,
            'pager'    => $pager,
            'services' => $this->services->paginate($filters, $pager->perPage, $pager->offset()),
        ]);
    }

    public function create(): void
    {
        $this->form(null, ['is_active' => 1], []);
    }

    public function store(): void
    {
        [$data, $errors] = $this->validated();
        $image = null;
        if (!$errors) {
            try {
                $image = $this->uploader()->save($this->request->file('image'), 'svc_');
            } catch (UploadException $e) {
                $errors['image'] = $e->getMessage();
            }
        }
        if ($errors) {
            $this->form(null, $data, $errors);
            return;
        }

        try {
            $this->services->create($data + ['image' => $image]);
        } catch (\Throwable $e) {
            $this->uploader()->delete($image);      // không để lại file mồ côi nếu lưu CSDL thất bại
            throw $e;
        }
        $this->flash('success', 'Đã thêm dịch vụ "' . $data['name'] . '".');
        $this->redirect('services');
    }

    public function edit(int $id): void
    {
        $service = $this->findService($id);
        $this->form($service, $service, []);
    }

    public function update(int $id): void
    {
        $service = $this->findService($id);

        [$data, $errors] = $this->validated();
        $newImage = null;
        if (!$errors) {
            try {
                $newImage = $this->uploader()->save($this->request->file('image'), 'svc_');
            } catch (UploadException $e) {
                $errors['image'] = $e->getMessage();
            }
        }
        if ($errors) {
            $this->form($service, $data, $errors);
            return;
        }

        try {
            $this->services->update($id, $data + ['image' => $newImage ?? $service['image']]);
        } catch (\Throwable $e) {
            $this->uploader()->delete($newImage);
            throw $e;
        }
        if ($newImage !== null) {
            $this->uploader()->delete($service['image']);   // xóa ảnh cũ sau khi đã thay ảnh mới
        }
        $this->flash('success', 'Đã cập nhật dịch vụ "' . $data['name'] . '".');
        $this->redirect('services');
    }

    public function destroy(int $id): void
    {
        $service = $this->findService($id);

        if ($this->services->bookingCount($id) > 0) {
            $this->flash('error', 'Không thể xóa "' . $service['name'] . '" vì đã có lịch đặt dùng dịch vụ này. Hãy chuyển sang "Tạm ẩn" để khách không còn thấy dịch vụ.');
            $this->back('services');
        }
        $this->services->delete($id);
        $this->uploader()->delete($service['image']);
        $this->flash('success', 'Đã xóa dịch vụ "' . $service['name'] . '".');
        $this->back('services');
    }

    private function findService(int $id): array
    {
        $service = $this->services->find($id);
        if ($service === null) {
            $this->notFound('Không tìm thấy dịch vụ.');
        }
        return $service;
    }

    private function form(?array $service, array $old, array $errors): void
    {
        $this->view('services/form', [
            'title'   => $service ? 'Sửa dịch vụ' : 'Thêm dịch vụ',
            'active'  => 'services',
            'service' => $service,
            'old'     => $old,
            'errors'  => $errors,
        ]);
    }

    /** @return array{0: array, 1: array} [dữ liệu đã làm sạch, lỗi theo từng trường] */
    private function validated(): array
    {
        $r    = $this->request;
        $data = [
            'name'        => $r->input('name'),
            'description' => $r->input('description'),
            'price'       => (string) preg_replace('/[\s.,đ₫]/u', '', $r->input('price')),   // cho phép gõ 150.000
            'duration'    => $r->input('duration'),
            'is_active'   => $r->input('is_active', '1') === '0' ? 0 : 1,
        ];

        $errors = [];
        $len    = mb_strlen($data['name']);
        if ($len < 2 || $len > 150) {
            $errors['name'] = 'Tên dịch vụ cần từ 2 đến 150 ký tự.';
        }
        if (!ctype_digit($data['price']) || (int) $data['price'] > 100000000) {
            $errors['price'] = 'Giá dịch vụ là số nguyên từ 0 đến 100.000.000 ₫.';
        }
        if (!ctype_digit($data['duration']) || (int) $data['duration'] < 5 || (int) $data['duration'] > 10080) {
            $errors['duration'] = 'Thời gian thực hiện từ 5 đến 10.080 phút.';
        }
        if (mb_strlen($data['description']) > 2000) {
            $errors['description'] = 'Mô tả tối đa 2.000 ký tự.';
        }
        return [$data, $errors];
    }
}
