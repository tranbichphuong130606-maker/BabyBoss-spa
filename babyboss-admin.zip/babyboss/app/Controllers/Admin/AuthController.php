<?php
namespace App\Controllers\Admin;

use App\Core\{Auth, Controller, Session};

/** Đăng nhập / đăng xuất khu vực quản trị. */
final class AuthController extends Controller
{
    private const MAX_ATTEMPTS = 5;      // sai quá 5 lần sẽ bị tạm khóa
    private const LOCK_SECONDS = 300;    // 5 phút

    public function showLogin(): void
    {
        $user = Auth::user();
        if ($user && $user['role'] === 'admin' && $user['status'] === 'active') {
            $this->redirect('dashboard');
        }
        $this->renderLogin('', null);
    }

    public function login(): void
    {
        $email    = mb_strtolower($this->request->input('email'));
        $password = $this->request->raw('password');

        $lockedUntil = (int) Session::get('login_locked_until', 0);
        if ($lockedUntil > time()) {
            $this->renderLogin($email, 'Bạn đã nhập sai quá nhiều lần. Vui lòng thử lại sau ' . (int) ceil(($lockedUntil - time()) / 60) . ' phút.');
            return;
        }
        if ($email === '' || $password === '') {
            $this->renderLogin($email, 'Vui lòng nhập email và mật khẩu.');
            return;
        }

        [$user, $error] = Auth::attempt($email, $password);
        if ($user === null) {
            $fails = (int) Session::get('login_fails', 0) + 1;
            Session::put('login_fails', $fails);
            if ($fails >= self::MAX_ATTEMPTS) {
                Session::put('login_locked_until', time() + self::LOCK_SECONDS);
                Session::put('login_fails', 0);
            }
            $this->renderLogin($email, $error);
            return;
        }

        Session::forget('login_fails');
        Session::forget('login_locked_until');
        Auth::login($user);
        Session::flash('success', 'Chào mừng ' . $user['full_name'] . ' quay trở lại!');
        $this->redirect('dashboard');
    }

    public function logout(): void
    {
        Auth::logout();
        Session::flash('success', 'Bạn đã đăng xuất khỏi khu vực quản trị.');
        $this->redirect('login');
    }

    private function renderLogin(string $email, ?string $error): void
    {
        $this->view('auth/login', ['title' => 'Đăng nhập quản trị', 'email' => $email, 'error' => $error], null);
    }
}
