<?php
/**
 * Cấu hình chung của BabyBoss Pet Spa.
 * Chỉnh mục 'db' cho khớp với MySQL trên XAMPP của bạn.
 */
return [
    'app' => [
        'name'     => 'BabyBoss Pet Spa',
        'debug'    => true,                 // đổi thành false khi triển khai thật
        'timezone' => 'Asia/Ho_Chi_Minh',
        'base_url' => '',                   // để trống = tự nhận diện (vd: /babyboss)
    ],
    'db' => [
        'host'    => '127.0.0.1',
        'port'    => 3306,
        'name'    => 'babyboss',
        'user'    => 'root',
        'pass'    => '',
        'charset' => 'utf8mb4',
    ],
    'upload' => [
        'max_size' => 2 * 1024 * 1024,      // tối đa 2 MB / ảnh
    ],
    // Số dòng mỗi trang cho từng danh sách trong khu vực admin
    'per_page' => [
        'users' => 8, 'services' => 6, 'appointments' => 10,
        'reviews' => 8, 'messages' => 8, 'loyalty' => 10, 'history' => 12,
    ],
];
