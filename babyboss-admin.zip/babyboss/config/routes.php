<?php
/**
 * Khai báo toàn bộ route của khu vực Admin.
 * Dạng URL:  /admin/index.php?route=users/5/toggle-lock
 * @var \App\Core\Router $router
 */
use App\Middleware\AdminMiddleware;

$admin = [AdminMiddleware::class];   // middleware phân quyền admin

// Đăng nhập (không qua middleware)
$router->get('login',   'AuthController@showLogin');
$router->post('login',  'AuthController@login');
$router->post('logout', 'AuthController@logout', $admin);

// Tổng quan
$router->get('dashboard', 'DashboardController@index', $admin);

// Người dùng
$router->get('users',                    'UserController@index',      $admin);
$router->post('users/{id}/toggle-lock',  'UserController@toggleLock', $admin);
$router->post('users/{id}/delete',       'UserController@destroy',    $admin);

// Dịch vụ spa
$router->get('services',                 'ServiceController@index',   $admin);
$router->get('services/create',          'ServiceController@create',  $admin);
$router->post('services/store',          'ServiceController@store',   $admin);
$router->get('services/{id}/edit',       'ServiceController@edit',    $admin);
$router->post('services/{id}/update',    'ServiceController@update',  $admin);
$router->post('services/{id}/delete',    'ServiceController@destroy', $admin);

// Lịch đặt spa
$router->get('appointments',                  'AppointmentController@index',        $admin);
$router->post('appointments/{id}/status',     'AppointmentController@updateStatus', $admin);

// Đánh giá
$router->get('reviews',                  'ReviewController@index',   $admin);
$router->post('reviews/{id}/toggle',     'ReviewController@toggle',  $admin);
$router->post('reviews/{id}/delete',     'ReviewController@destroy', $admin);

// Tin nhắn
$router->get('messages',                 'MessageController@index', $admin);
$router->get('messages/{id}',            'MessageController@show',  $admin);
$router->post('messages/{id}/reply',     'MessageController@reply', $admin);

// Điểm thưởng & hạng thành viên
$router->get('loyalty',                  'LoyaltyController@index',      $admin);
$router->post('loyalty/adjust',          'LoyaltyController@adjust',     $admin);
$router->get('loyalty/history',          'LoyaltyController@history',    $admin);
$router->get('loyalty/config',           'LoyaltyController@config',     $admin);
$router->post('loyalty/config',          'LoyaltyController@saveConfig', $admin);
