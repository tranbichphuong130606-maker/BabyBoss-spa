<?php
/**
 * Trang chủ Client — chỗ dành cho PHẦN 1 (khách hàng).
 * Hiện chỉ là trang tạm để middleware admin có nơi "đá" khách thường về.
 */
require __DIR__ . '/app/bootstrap.php';

use App\Core\Session;

$flashes = Session::pullFlash();
?>
<!doctype html>
<html lang="vi">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>BabyBoss Pet Spa</title>
    <style>
        body{margin:0;min-height:100vh;display:grid;place-items:center;background:#f1f6f9;color:#14283d;font-family:system-ui,"Segoe UI",sans-serif}
        main{max-width:520px;padding:36px;background:#fff;border:1px solid #d9e3ea;border-radius:16px}
        h1{margin:0 0 8px;font-size:26px} p{line-height:1.6;color:#5c7083}
        .msg{padding:12px 14px;border-radius:10px;margin-bottom:18px;background:#fbe4e3;color:#a6312f}
        .msg.success{background:#ddf3e8;color:#17704a}
        a.btn{display:inline-block;margin-top:8px;padding:10px 18px;border-radius:9px;background:#ffc83d;color:#0f2c4a;font-weight:600;text-decoration:none}
    </style>
</head>
<body>
<main>
    <?php foreach ($flashes as $f): ?>
        <div class="msg <?= e($f['type']) ?>"><?= e($f['message']) ?></div>
    <?php endforeach; ?>
    <h1>BabyBoss Pet Spa</h1>
    <p>Đây là trang chủ dành cho khách hàng (Phần 1 của đề tài). Phần Quản trị (Phần 2) đã sẵn sàng.</p>
    <a class="btn" href="<?= e(admin_url('login')) ?>">Vào trang quản trị</a>
</main>
</body>
</html>
