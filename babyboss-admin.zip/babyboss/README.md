# BabyBoss Pet Spa — Phần 2: Trang quản trị (Admin)

Ứng dụng web viết bằng **PHP hướng đối tượng (OOP) theo mô hình MVC**, không cần Composer hay framework, dùng **PDO + MySQL/MariaDB**. Yêu cầu: **PHP 8.0+** (XAMPP bản hiện tại là đủ).

## 1. Cài đặt nhanh (XAMPP)

1. Chép thư mục `babyboss/` vào `C:\xampp\htdocs\` rồi bật **Apache** và **MySQL** trong XAMPP Control Panel.
2. Mở phpMyAdmin → tab **Import** → chọn `database/babyboss.sql` → **Import** (file tự tạo CSDL `babyboss`, bảng và dữ liệu mẫu).
3. Nếu MySQL của bạn có mật khẩu root, sửa mục `db` trong `config/config.php`.
4. Mở **http://localhost/babyboss/admin/** và đăng nhập.

| Vai trò | Email | Mật khẩu |
|---|---|---|
| Quản trị viên | `admin@babyboss.vn` | `Admin@123` |
| Khách hàng (để thử chặn quyền) | `minhanh@example.com` | `Khach@123` |

Dự án tự nhận diện đường dẫn (`/babyboss`), nên đặt tên thư mục khác cũng chạy được. Khi triển khai thật hãy đặt `'debug' => false` trong `config/config.php`.

## 2. Chức năng (đối chiếu đề cương Phần 2)

| Mục đề cương | Cài đặt |
|---|---|
| Đăng nhập quản trị & phân quyền (Middleware) | `AuthController`, `AdminMiddleware`, `Auth` |
| Quản lý người dùng: xem, tìm kiếm, phân trang, khóa/mở khóa, xóa | `UserController`, `User` |
| Quản lý dịch vụ: thêm/sửa/xóa, upload ảnh vào `uploads/`, tìm kiếm, phân trang | `ServiceController`, `Service`, `ImageUploader` |
| Quản lý & duyệt lịch đặt: Chờ duyệt → Đã xác nhận → Đã hoàn thành / Đã hủy; tìm theo tên khách hoặc ngày | `AppointmentController`, `AppointmentService` |
| Dashboard: tổng khách hàng, tổng thú cưng, lịch chờ duyệt trong ngày | `DashboardController` |
| Quản lý đánh giá: Ẩn / Hiện / Xóa | `ReviewController`, `Review` |
| Trả lời tin nhắn của khách | `MessageController`, `Message` |
| Điểm thưởng: cộng / trừ / đặt lại điểm, lịch sử giao dịch, cấu hình tỷ lệ tích điểm 1–5% và ngưỡng chi tiêu từng hạng (Bạc, Vàng, Kim Cương) | `LoyaltyController`, `LoyaltyService`, `MembershipTier`, `LoyaltyTransaction` |

## 3. Cấu trúc thư mục

```
babyboss/
├── index.php                 Trang chủ tạm cho Phần 1 (nơi middleware đá khách thường về)
├── admin/
│   ├── index.php             Front controller: mọi request /admin/... đi qua đây
│   └── assets/css, js        Giao diện admin
├── app/
│   ├── bootstrap.php         Autoload (PSR-4), cấu hình, session, xử lý lỗi — dùng chung Phần 1 và 2
│   ├── Core/                 Router, Request, View, Controller, Model, Database, Auth, Csrf, Session,
│   │                         Paginator, ImageUploader, helpers.php
│   ├── Models/               User, Pet, Service, Appointment, Review, Message,
│   │                         MembershipTier, LoyaltyTransaction, Setting
│   ├── Services/             LoyaltyService, AppointmentService (nghiệp vụ nhiều bước, dùng transaction)
│   ├── Middleware/           AdminMiddleware
│   ├── Controllers/Admin/    8 controller
│   └── Views/admin/          layouts, partials và view từng module
├── config/                   config.php (DB, upload, số dòng/trang), routes.php (toàn bộ route)
├── database/babyboss.sql     Schema + dữ liệu mẫu
└── uploads/services|pets/    Ảnh tải lên (có .htaccess chặn chạy PHP)
```

Luồng một request: `admin/index.php` → `bootstrap` → `Router` (kiểm tra CSRF với POST) → `AdminMiddleware` → `Controller` → `Model` / `Service` → `View`.
URL dạng `admin/index.php?route=users/5/toggle-lock`, nên **không cần bật mod_rewrite**.

## 4. Quy tắc nghiệp vụ

- **Phân quyền**: mỗi request, middleware đọc lại `role` và `status` của tài khoản từ CSDL. Chưa đăng nhập → trang đăng nhập admin; khách thường (`role = customer`) → bị chặn và chuyển về trang chủ; tài khoản bị khóa → bị đăng xuất.
- **Luồng lịch hẹn**: `pending → confirmed → completed`, hoặc `pending/confirmed → cancelled`. `completed` và `cancelled` là trạng thái cuối nên không thể cộng điểm hai lần.
- **Hoàn thành lịch** (một transaction): điểm cộng = `total_amount × tỷ lệ hạng hiện tại ÷ 100 ÷ giá trị 1 điểm` (làm tròn xuống); `total_spent` được cộng dồn để xét lên hạng; ghi 1 dòng `earn` kèm mã lịch.
- **Hủy lịch** đã dùng điểm: hoàn lại điểm (`refund`).
- **Điều chỉnh thủ công**: bắt buộc nhập lý do, không cho số dư âm, mọi lần chỉnh đều ghi vào lịch sử điểm.
- **Hạng thành viên** không lưu cứng mà tính từ `users.total_spent` và bảng `membership_tiers`, nên đổi ngưỡng là áp dụng ngay.
- **Xóa dịch vụ** đã có lịch đặt bị từ chối; hãy đặt "Tạm ẩn" để khách không thấy nữa.

## 5. Bảo mật đã áp dụng

PDO prepared statement thật (`EMULATE_PREPARES = false`) · `password_hash` / `password_verify` · CSRF token cho mọi form POST · escape đầu ra bằng `e()` · `session_regenerate_id` khi đăng nhập · khóa đăng nhập 5 phút sau 5 lần sai · upload kiểm tra đuôi file + MIME thật + `getimagesize`, đổi tên bằng `uniqid()` · `SELECT … FOR UPDATE` khi đổi trạng thái lịch và cộng/trừ điểm · `.htaccess` chặn truy cập trực tiếp `app/`, `config/`, `database/`.

## 6. Ghép với Phần 1 (Client)

- Sau khi khách đăng nhập, lưu `$_SESSION['user_id'] = <id>` (dùng chung `app/bootstrap.php` hoặc tự `session_start()`); từ chối đăng nhập nếu `users.status = 'locked'`.
- Đặt lịch: thêm vào `appointments` với `status = 'pending'`, `price` = giá dịch vụ lúc đặt. Nếu dùng điểm: `discount = points_used × settings.point_value`, `total_amount = price − discount`, trừ `users.points` và ghi `loyalty_transactions` loại `redeem` (số điểm âm).
- Trang dịch vụ chỉ hiển thị `services.is_active = 1`; điểm trung bình chỉ tính các đánh giá `reviews.status = 'visible'`.
- Tin nhắn: khách gửi → `messages(sender = 'customer', is_handled = 0)`, rồi thêm một tin `system` làm câu tự động trả lời; admin phản hồi trong mục **Tin nhắn**.
- Ảnh dịch vụ nằm ở `uploads/services/`, ảnh thú cưng ở `uploads/pets/`.
