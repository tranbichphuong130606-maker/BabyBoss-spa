-- ============================================================================
-- BabyBoss Pet Spa — cơ sở dữ liệu (MySQL / MariaDB, utf8mb4)
-- Cách import: phpMyAdmin > Import, hoặc  mysql -u root < database/babyboss.sql
-- File tự tạo CSDL `babyboss`, xóa bảng cũ (nếu có) rồi tạo lại kèm dữ liệu mẫu.
--
-- Tài khoản demo
--   Quản trị : admin@babyboss.vn          / Admin@123
--   Khách    : minhanh@example.com ...    / Khach@123
-- ============================================================================
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

CREATE DATABASE IF NOT EXISTS babyboss CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE babyboss;

DROP TABLE IF EXISTS loyalty_transactions, messages, reviews, appointments, pets, services, membership_tiers, settings, users;

-- --------------------------------------------------------------------------
-- Bảng dùng chung với Phần 1 (Client)
-- --------------------------------------------------------------------------
CREATE TABLE users (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  full_name   VARCHAR(100) NOT NULL,
  email       VARCHAR(150) NOT NULL,
  phone       VARCHAR(20)  NOT NULL,
  password    VARCHAR(255) NOT NULL COMMENT 'Chuỗi băm từ password_hash()',
  role        ENUM('customer','admin') NOT NULL DEFAULT 'customer',
  status      ENUM('active','locked')  NOT NULL DEFAULT 'active' COMMENT 'locked = bị admin khóa, không được đăng nhập',
  points      INT UNSIGNED    NOT NULL DEFAULT 0 COMMENT 'Số điểm thưởng hiện có',
  total_spent BIGINT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'Tổng chi tiêu của các lịch đã hoàn thành (VNĐ) — dùng xét hạng',
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_users_email (email),
  KEY idx_users_role_status (role, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE pets (
  id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id    INT UNSIGNED NOT NULL,
  name       VARCHAR(80) NOT NULL,
  species    VARCHAR(80) NOT NULL COMMENT 'Giống loài',
  weight     DECIMAL(5,2) NULL COMMENT 'Cân nặng (kg)',
  age        TINYINT UNSIGNED NULL COMMENT 'Tuổi (năm)',
  avatar     VARCHAR(255) NULL COMMENT 'Tên file trong uploads/pets',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_pets_user (user_id),
  CONSTRAINT fk_pets_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE services (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name        VARCHAR(150) NOT NULL,
  description TEXT NULL,
  price       INT UNSIGNED NOT NULL COMMENT 'VNĐ',
  duration    INT UNSIGNED NOT NULL COMMENT 'Thời gian thực hiện (phút)',
  image       VARCHAR(255) NULL COMMENT 'Tên file trong uploads/services',
  is_active   TINYINT(1) NOT NULL DEFAULT 1 COMMENT '1 = hiển thị cho khách, 0 = tạm ẩn',
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_services_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE appointments (
  id               INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id          INT UNSIGNED NOT NULL,
  pet_id           INT UNSIGNED NULL,
  service_id       INT UNSIGNED NOT NULL,
  appointment_date DATETIME NOT NULL,
  note             VARCHAR(500) NULL,
  status           ENUM('pending','confirmed','completed','cancelled') NOT NULL DEFAULT 'pending',
  price            INT UNSIGNED NOT NULL COMMENT 'Giá dịch vụ tại thời điểm đặt',
  points_used      INT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'Số điểm khách dùng để giảm giá',
  discount         INT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'Số tiền được giảm nhờ điểm (VNĐ)',
  total_amount     INT UNSIGNED NOT NULL COMMENT 'Số tiền phải trả = price - discount',
  points_earned    INT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'Điểm đã cộng khi hoàn thành',
  created_at       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_appt_status_date (status, appointment_date),
  KEY idx_appt_user (user_id),
  KEY idx_appt_pet (pet_id),
  KEY idx_appt_service (service_id),
  CONSTRAINT fk_appt_user    FOREIGN KEY (user_id)    REFERENCES users (id)    ON DELETE CASCADE,
  CONSTRAINT fk_appt_pet     FOREIGN KEY (pet_id)     REFERENCES pets (id)     ON DELETE SET NULL,
  CONSTRAINT fk_appt_service FOREIGN KEY (service_id) REFERENCES services (id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE reviews (
  id             INT UNSIGNED NOT NULL AUTO_INCREMENT,
  appointment_id INT UNSIGNED NOT NULL COMMENT 'Mỗi lịch hoàn thành chỉ được đánh giá 1 lần',
  user_id        INT UNSIGNED NOT NULL,
  service_id     INT UNSIGNED NOT NULL,
  rating         TINYINT UNSIGNED NOT NULL COMMENT '1 đến 5 sao',
  comment        TEXT NULL,
  status         ENUM('visible','hidden') NOT NULL DEFAULT 'visible' COMMENT 'hidden = admin đã ẩn',
  created_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_review_appointment (appointment_id),
  KEY idx_review_service (service_id, status),
  CONSTRAINT chk_review_rating CHECK (rating BETWEEN 1 AND 5),
  CONSTRAINT fk_review_appt    FOREIGN KEY (appointment_id) REFERENCES appointments (id) ON DELETE CASCADE,
  CONSTRAINT fk_review_user    FOREIGN KEY (user_id)        REFERENCES users (id)        ON DELETE CASCADE,
  CONSTRAINT fk_review_service FOREIGN KEY (service_id)     REFERENCES services (id)     ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tin nhắn dạng hội thoại: mỗi khách một luồng. sender = customer | system (tự động trả lời) | admin
CREATE TABLE messages (
  id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id    INT UNSIGNED NOT NULL COMMENT 'Khách hàng sở hữu hội thoại',
  sender     ENUM('customer','system','admin') NOT NULL,
  content    TEXT NOT NULL,
  is_handled TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'Với tin của khách: 1 = admin đã phản hồi. Phần 1 luôn lưu tin khách với giá trị 0.',
  admin_id   INT UNSIGNED NULL COMMENT 'Admin đã phản hồi',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_msg_user (user_id, created_at),
  KEY idx_msg_pending (sender, is_handled),
  CONSTRAINT fk_msg_user  FOREIGN KEY (user_id)  REFERENCES users (id) ON DELETE CASCADE,
  CONSTRAINT fk_msg_admin FOREIGN KEY (admin_id) REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------------
-- Điểm thưởng & hạng thành viên
-- --------------------------------------------------------------------------
CREATE TABLE membership_tiers (
  id        TINYINT UNSIGNED NOT NULL AUTO_INCREMENT,
  name      VARCHAR(50) NOT NULL,
  min_spent BIGINT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'Tổng chi tiêu tối thiểu để đạt hạng (VNĐ)',
  earn_rate DECIMAL(4,2) NOT NULL DEFAULT 1.00 COMMENT 'Tỷ lệ tích điểm (%), từ 1 đến 5',
  PRIMARY KEY (id),
  UNIQUE KEY uq_tier_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE loyalty_transactions (
  id             INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id        INT UNSIGNED NOT NULL,
  type           ENUM('earn','redeem','refund','adjust') NOT NULL COMMENT 'earn: tích điểm | redeem: dùng điểm | refund: hoàn điểm | adjust: admin chỉnh tay',
  points         INT NOT NULL COMMENT 'Có dấu: dương = cộng, âm = trừ',
  balance_after  INT UNSIGNED NOT NULL COMMENT 'Số dư điểm sau giao dịch',
  appointment_id INT UNSIGNED NULL COMMENT 'Mã đơn (lịch hẹn) liên quan',
  note           VARCHAR(255) NULL,
  admin_id       INT UNSIGNED NULL COMMENT 'Admin thực hiện (NULL = hệ thống / khách)',
  created_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_tx_user (user_id, created_at),
  KEY idx_tx_appt (appointment_id),
  CONSTRAINT fk_tx_user  FOREIGN KEY (user_id)        REFERENCES users (id)        ON DELETE CASCADE,
  CONSTRAINT fk_tx_appt  FOREIGN KEY (appointment_id) REFERENCES appointments (id) ON DELETE SET NULL,
  CONSTRAINT fk_tx_admin FOREIGN KEY (admin_id)       REFERENCES users (id)        ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE settings (
  setting_key   VARCHAR(50)  NOT NULL,
  setting_value VARCHAR(255) NOT NULL,
  PRIMARY KEY (setting_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==========================================================================
-- DỮ LIỆU MẪU (ngày giờ tính theo CURDATE() nên luôn có lịch "hôm nay")
-- ==========================================================================

INSERT INTO settings (setting_key, setting_value) VALUES ('point_value', '1000');

INSERT INTO membership_tiers (id, name, min_spent, earn_rate) VALUES
  (1, 'Bạc', 0, 1.00),
  (2, 'Vàng', 1500000, 3.00),
  (3, 'Kim Cương', 3500000, 5.00);

INSERT INTO users (id, full_name, email, phone, password, role, status, points, total_spent, created_at) VALUES
  (1, 'Quản trị viên', 'admin@babyboss.vn', '0900000000', '$2y$10$FSui9RUq3QL.3Fa4qTGIiez7DqihRn.esYDFfUhRNgi5QHEFVu5a.', 'admin', 'active', 0, 0, TIMESTAMP(CURDATE() - INTERVAL 200 DAY, '09:00:00')),
  (2, 'Nguyễn Minh Anh', 'minhanh@example.com', '0901000001', '$2y$10$PsszQx.cAHsMBk6QcjF3nOtAnabDrotRql0ZatqWZJ3MPiwlzn.MC', 'customer', 'active', 81, 3830000, TIMESTAMP(CURDATE() - INTERVAL 120 DAY, '10:00:00')),
  (3, 'Trần Quốc Bảo', 'quocbao@example.com', '0901000002', '$2y$10$PsszQx.cAHsMBk6QcjF3nOtAnabDrotRql0ZatqWZJ3MPiwlzn.MC', 'customer', 'active', 35, 1700000, TIMESTAMP(CURDATE() - INTERVAL 105 DAY, '10:00:00')),
  (4, 'Lê Thu Hà', 'thuha@example.com', '0901000003', '$2y$10$PsszQx.cAHsMBk6QcjF3nOtAnabDrotRql0ZatqWZJ3MPiwlzn.MC', 'customer', 'active', 36, 1750000, TIMESTAMP(CURDATE() - INTERVAL 98 DAY, '10:00:00')),
  (5, 'Phạm Gia Huy', 'giahuy@example.com', '0901000004', '$2y$10$PsszQx.cAHsMBk6QcjF3nOtAnabDrotRql0ZatqWZJ3MPiwlzn.MC', 'customer', 'active', 23, 400000, TIMESTAMP(CURDATE() - INTERVAL 80 DAY, '10:00:00')),
  (6, 'Võ Ngọc Linh', 'ngoclinh@example.com', '0901000005', '$2y$10$PsszQx.cAHsMBk6QcjF3nOtAnabDrotRql0ZatqWZJ3MPiwlzn.MC', 'customer', 'active', 16, 740000, TIMESTAMP(CURDATE() - INTERVAL 66 DAY, '10:00:00')),
  (7, 'Đặng Hoàng Nam', 'hoangnam@example.com', '0901000006', '$2y$10$PsszQx.cAHsMBk6QcjF3nOtAnabDrotRql0ZatqWZJ3MPiwlzn.MC', 'customer', 'active', 23, 400000, TIMESTAMP(CURDATE() - INTERVAL 60 DAY, '10:00:00')),
  (8, 'Bùi Khánh Vy', 'khanhvy@example.com', '0901000007', '$2y$10$PsszQx.cAHsMBk6QcjF3nOtAnabDrotRql0ZatqWZJ3MPiwlzn.MC', 'customer', 'active', 21, 200000, TIMESTAMP(CURDATE() - INTERVAL 45 DAY, '10:00:00')),
  (9, 'Hoàng Đức Thịnh', 'ducthinh@example.com', '0901000008', '$2y$10$PsszQx.cAHsMBk6QcjF3nOtAnabDrotRql0ZatqWZJ3MPiwlzn.MC', 'customer', 'locked', 5, 550000, TIMESTAMP(CURDATE() - INTERVAL 40 DAY, '10:00:00')),
  (10, 'Ngô Phương Thảo', 'phuongthao@example.com', '0901000009', '$2y$10$PsszQx.cAHsMBk6QcjF3nOtAnabDrotRql0ZatqWZJ3MPiwlzn.MC', 'customer', 'active', 2, 250000, TIMESTAMP(CURDATE() - INTERVAL 31 DAY, '10:00:00')),
  (11, 'Đỗ Anh Tuấn', 'anhtuan@example.com', '0901000010', '$2y$10$PsszQx.cAHsMBk6QcjF3nOtAnabDrotRql0ZatqWZJ3MPiwlzn.MC', 'customer', 'active', 1, 150000, TIMESTAMP(CURDATE() - INTERVAL 22 DAY, '10:00:00')),
  (12, 'Vũ Mai Chi', 'maichi@example.com', '0901000011', '$2y$10$PsszQx.cAHsMBk6QcjF3nOtAnabDrotRql0ZatqWZJ3MPiwlzn.MC', 'customer', 'active', 2, 200000, TIMESTAMP(CURDATE() - INTERVAL 12 DAY, '10:00:00')),
  (13, 'Phan Thanh Sơn', 'thanhson@example.com', '0901000012', '$2y$10$PsszQx.cAHsMBk6QcjF3nOtAnabDrotRql0ZatqWZJ3MPiwlzn.MC', 'customer', 'active', 0, 0, TIMESTAMP(CURDATE() - INTERVAL 4 DAY, '10:00:00'));

INSERT INTO pets (id, user_id, name, species, weight, age, created_at) VALUES
  (1, 2, 'Mochi', 'Poodle', 4.2, 3, TIMESTAMP(CURDATE() - INTERVAL 119 DAY, '11:00:00')),
  (2, 2, 'Bơ', 'Corgi', 11.5, 2, TIMESTAMP(CURDATE() - INTERVAL 119 DAY, '11:00:00')),
  (3, 3, 'Susu', 'Mèo Anh lông ngắn', 4.8, 4, TIMESTAMP(CURDATE() - INTERVAL 104 DAY, '11:00:00')),
  (4, 4, 'Lucky', 'Golden Retriever', 27.0, 5, TIMESTAMP(CURDATE() - INTERVAL 97 DAY, '11:00:00')),
  (5, 4, 'Kem', 'Pomeranian', 2.9, 1, TIMESTAMP(CURDATE() - INTERVAL 97 DAY, '11:00:00')),
  (6, 5, 'Mướp', 'Mèo ta', 3.6, 2, TIMESTAMP(CURDATE() - INTERVAL 79 DAY, '11:00:00')),
  (7, 6, 'Bông', 'Samoyed', 22.4, 3, TIMESTAMP(CURDATE() - INTERVAL 65 DAY, '11:00:00')),
  (8, 7, 'Đậu', 'Shiba Inu', 9.8, 4, TIMESTAMP(CURDATE() - INTERVAL 59 DAY, '11:00:00')),
  (9, 8, 'Xíu', 'Chihuahua', 2.1, 2, TIMESTAMP(CURDATE() - INTERVAL 44 DAY, '11:00:00')),
  (10, 8, 'Tít', 'Phốc sóc', 2.4, 1, TIMESTAMP(CURDATE() - INTERVAL 44 DAY, '11:00:00')),
  (11, 9, 'Misa', 'Mèo Ba Tư', 4.5, 6, TIMESTAMP(CURDATE() - INTERVAL 39 DAY, '11:00:00')),
  (12, 10, 'Gấu', 'Alaska', 30.2, 3, TIMESTAMP(CURDATE() - INTERVAL 30 DAY, '11:00:00')),
  (13, 11, 'Cốm', 'Poodle', 5.1, 2, TIMESTAMP(CURDATE() - INTERVAL 21 DAY, '11:00:00')),
  (14, 12, 'Nhím', 'Husky', 24.0, 4, TIMESTAMP(CURDATE() - INTERVAL 11 DAY, '11:00:00')),
  (15, 13, 'Sushi', 'Mèo Munchkin', 3.2, 1, TIMESTAMP(CURDATE() - INTERVAL 3 DAY, '11:00:00')),
  (16, 6, 'Bin', 'Bulldog Pháp', 12.6, 3, TIMESTAMP(CURDATE() - INTERVAL 65 DAY, '11:00:00'));

INSERT INTO services (id, name, description, price, duration, is_active) VALUES
  (1, 'Tắm sấy cơ bản', 'Tắm bằng sữa tắm dịu nhẹ, sấy khô, chải lông và vệ sinh tai. Phù hợp bé khỏe mạnh cần giữ vệ sinh hằng tuần.', 150000, 45, 1),
  (2, 'Tắm sấy cao cấp', 'Tắm dưỡng lông với tinh dầu thảo mộc, ủ dưỡng 10 phút, sấy tạo phồng và xịt thơm nhẹ.', 250000, 60, 1),
  (3, 'Cắt tỉa lông tạo kiểu', 'Cắt tỉa theo dáng giống hoặc theo yêu cầu, đã bao gồm tắm sấy và cạo lông chân.', 300000, 90, 1),
  (4, 'Vệ sinh tai và cắt móng', 'Làm sạch tai, mài và cắt móng, vệ sinh tuyến hôi. Làm nhanh trong 20 phút.', 80000, 20, 1),
  (5, 'Spa dưỡng lông và massage', 'Gói thư giãn gồm tắm dưỡng, massage, ủ lông, sấy và chải tơi. Dành cho bé lông dài hoặc nhạy cảm.', 450000, 120, 1),
  (6, 'Khách sạn thú cưng (1 ngày)', 'Phòng riêng có điều hòa, ăn 2 bữa, được dắt đi dạo và gửi ảnh cập nhật cho chủ.', 200000, 1440, 1),
  (7, 'Nhuộm lông nghệ thuật', 'Nhuộm màu thực vật an toàn cho da, tạo điểm nhấn ở tai, đuôi hoặc chân.', 500000, 150, 0),
  (8, 'Đánh răng và khử mùi hôi miệng', 'Làm sạch cao răng nhẹ, đánh răng bằng kem dành riêng cho thú cưng.', 120000, 30, 1);

INSERT INTO appointments (id, user_id, pet_id, service_id, appointment_date, note, status, price, points_used, discount, total_amount, points_earned, created_at) VALUES
  (1, 2, 1, 2, TIMESTAMP(CURDATE() - INTERVAL 100 DAY, '09:00:00'), NULL, 'completed', 250000, 0, 0, 250000, 2, TIMESTAMP(CURDATE() - INTERVAL 101 DAY, '13:27:00')),
  (2, 2, 2, 5, TIMESTAMP(CURDATE() - INTERVAL 92 DAY, '10:30:00'), 'Bé hơi nhát, nhờ nhân viên nhẹ tay giúp mình.', 'completed', 450000, 0, 0, 450000, 4, TIMESTAMP(CURDATE() - INTERVAL 93 DAY, '11:48:00')),
  (3, 2, 1, 3, TIMESTAMP(CURDATE() - INTERVAL 80 DAY, '14:00:00'), NULL, 'completed', 300000, 0, 0, 300000, 3, TIMESTAMP(CURDATE() - INTERVAL 84 DAY, '17:46:00')),
  (4, 2, 1, 5, TIMESTAMP(CURDATE() - INTERVAL 70 DAY, '09:30:00'), NULL, 'completed', 450000, 0, 0, 450000, 4, TIMESTAMP(CURDATE() - INTERVAL 74 DAY, '20:49:00')),
  (5, 2, 2, 3, TIMESTAMP(CURDATE() - INTERVAL 60 DAY, '15:00:00'), 'Cắt kiểu teddy nhé.', 'completed', 300000, 0, 0, 300000, 3, TIMESTAMP(CURDATE() - INTERVAL 64 DAY, '12:05:00')),
  (6, 2, 1, 5, TIMESTAMP(CURDATE() - INTERVAL 50 DAY, '10:00:00'), NULL, 'completed', 450000, 0, 0, 450000, 13, TIMESTAMP(CURDATE() - INTERVAL 51 DAY, '18:28:00')),
  (7, 2, 2, 7, TIMESTAMP(CURDATE() - INTERVAL 41 DAY, '09:00:00'), 'Nhuộm tai màu hồng pastel.', 'completed', 500000, 0, 0, 500000, 15, TIMESTAMP(CURDATE() - INTERVAL 42 DAY, '09:53:00')),
  (8, 2, 1, 3, TIMESTAMP(CURDATE() - INTERVAL 30 DAY, '16:00:00'), NULL, 'completed', 300000, 0, 0, 300000, 9, TIMESTAMP(CURDATE() - INTERVAL 33 DAY, '09:40:00')),
  (9, 2, 2, 6, TIMESTAMP(CURDATE() - INTERVAL 21 DAY, '08:00:00'), 'Gửi bé 1 ngày vì mình đi công tác.', 'completed', 200000, 0, 0, 200000, 6, TIMESTAMP(CURDATE() - INTERVAL 25 DAY, '08:11:00')),
  (10, 2, 1, 5, TIMESTAMP(CURDATE() - INTERVAL 12 DAY, '10:00:00'), NULL, 'completed', 450000, 20, 20000, 430000, 12, TIMESTAMP(CURDATE() - INTERVAL 16 DAY, '19:35:00')),
  (11, 2, 2, 6, TIMESTAMP(CURDATE() - INTERVAL 5 DAY, '08:30:00'), NULL, 'completed', 200000, 0, 0, 200000, 10, TIMESTAMP(CURDATE() - INTERVAL 8 DAY, '11:35:00')),
  (12, 2, 1, 2, TIMESTAMP(CURDATE() + INTERVAL 1 DAY, '09:30:00'), NULL, 'confirmed', 250000, 0, 0, 250000, 0, TIMESTAMP(CURDATE() - INTERVAL 3 DAY, '12:17:00')),
  (13, 3, 3, 5, TIMESTAMP(CURDATE() - INTERVAL 88 DAY, '11:00:00'), NULL, 'completed', 450000, 0, 0, 450000, 4, TIMESTAMP(CURDATE() - INTERVAL 91 DAY, '14:05:00')),
  (14, 3, 3, 2, TIMESTAMP(CURDATE() - INTERVAL 75 DAY, '09:00:00'), NULL, 'completed', 250000, 0, 0, 250000, 2, TIMESTAMP(CURDATE() - INTERVAL 79 DAY, '20:43:00')),
  (15, 3, 3, 3, TIMESTAMP(CURDATE() - INTERVAL 60 DAY, '14:30:00'), NULL, 'completed', 300000, 0, 0, 300000, 3, TIMESTAMP(CURDATE() - INTERVAL 61 DAY, '20:20:00')),
  (16, 3, 3, 5, TIMESTAMP(CURDATE() - INTERVAL 45 DAY, '10:00:00'), NULL, 'completed', 450000, 0, 0, 450000, 4, TIMESTAMP(CURDATE() - INTERVAL 48 DAY, '09:31:00')),
  (17, 3, 3, 2, TIMESTAMP(CURDATE() - INTERVAL 30 DAY, '15:30:00'), NULL, 'completed', 250000, 0, 0, 250000, 2, TIMESTAMP(CURDATE() - INTERVAL 33 DAY, '12:54:00')),
  (18, 3, 3, 5, TIMESTAMP(CURDATE() + INTERVAL 2 DAY, '15:00:00'), NULL, 'pending', 450000, 0, 0, 450000, 0, TIMESTAMP(CURDATE() - INTERVAL 2 DAY, '10:24:00')),
  (19, 4, 4, 3, TIMESTAMP(CURDATE() - INTERVAL 70 DAY, '10:00:00'), 'Lucky hay sợ máy sấy.', 'completed', 300000, 0, 0, 300000, 3, TIMESTAMP(CURDATE() - INTERVAL 73 DAY, '08:25:00')),
  (20, 4, 4, 5, TIMESTAMP(CURDATE() - INTERVAL 55 DAY, '09:00:00'), NULL, 'completed', 450000, 0, 0, 450000, 4, TIMESTAMP(CURDATE() - INTERVAL 58 DAY, '14:12:00')),
  (21, 4, 4, 3, TIMESTAMP(CURDATE() - INTERVAL 40 DAY, '14:00:00'), NULL, 'completed', 300000, 0, 0, 300000, 3, TIMESTAMP(CURDATE() - INTERVAL 44 DAY, '15:12:00')),
  (22, 4, 5, 2, TIMESTAMP(CURDATE() - INTERVAL 25 DAY, '11:00:00'), NULL, 'completed', 250000, 0, 0, 250000, 2, TIMESTAMP(CURDATE() - INTERVAL 26 DAY, '14:48:00')),
  (23, 4, 4, 5, TIMESTAMP(CURDATE() - INTERVAL 15 DAY, '10:30:00'), NULL, 'completed', 450000, 0, 0, 450000, 4, TIMESTAMP(CURDATE() - INTERVAL 19 DAY, '09:59:00')),
  (24, 4, 5, 2, TIMESTAMP(CURDATE() + INTERVAL 0 DAY, '16:00:00'), 'Mình đến sớm 10 phút được không ạ?', 'pending', 250000, 0, 0, 250000, 0, TIMESTAMP(CURDATE() - INTERVAL 1 DAY, '16:38:00')),
  (25, 5, 6, 1, TIMESTAMP(CURDATE() - INTERVAL 50 DAY, '09:00:00'), NULL, 'completed', 150000, 0, 0, 150000, 1, TIMESTAMP(CURDATE() - INTERVAL 54 DAY, '14:47:00')),
  (26, 5, 6, 2, TIMESTAMP(CURDATE() - INTERVAL 20 DAY, '10:00:00'), NULL, 'completed', 250000, 0, 0, 250000, 2, TIMESTAMP(CURDATE() - INTERVAL 23 DAY, '15:10:00')),
  (27, 5, 6, 4, TIMESTAMP(CURDATE() - INTERVAL 8 DAY, '15:00:00'), 'Bé đang ốm, xin hủy lịch.', 'cancelled', 80000, 0, 0, 80000, 0, TIMESTAMP(CURDATE() - INTERVAL 12 DAY, '16:45:00')),
  (28, 5, 6, 1, TIMESTAMP(CURDATE() + INTERVAL 0 DAY, '10:30:00'), NULL, 'pending', 150000, 0, 0, 150000, 0, TIMESTAMP(CURDATE() + INTERVAL 0 DAY, '06:28:00')),
  (29, 6, 7, 5, TIMESTAMP(CURDATE() - INTERVAL 35 DAY, '09:30:00'), 'Bông lông dày, cần sấy kỹ.', 'completed', 450000, 0, 0, 450000, 4, TIMESTAMP(CURDATE() - INTERVAL 37 DAY, '08:50:00')),
  (30, 6, 7, 3, TIMESTAMP(CURDATE() - INTERVAL 18 DAY, '14:00:00'), NULL, 'completed', 300000, 10, 10000, 290000, 2, TIMESTAMP(CURDATE() - INTERVAL 19 DAY, '20:14:00')),
  (31, 6, 16, 6, TIMESTAMP(CURDATE() + INTERVAL 1 DAY, '08:00:00'), 'Gửi Bin 1 ngày.', 'confirmed', 200000, 0, 0, 200000, 0, TIMESTAMP(CURDATE() - INTERVAL 3 DAY, '16:01:00')),
  (32, 6, 7, 2, TIMESTAMP(CURDATE() + INTERVAL 0 DAY, '14:30:00'), NULL, 'pending', 250000, 0, 0, 250000, 0, TIMESTAMP(CURDATE() + INTERVAL 0 DAY, '06:29:00')),
  (33, 7, 8, 1, TIMESTAMP(CURDATE() - INTERVAL 28 DAY, '10:00:00'), NULL, 'completed', 150000, 0, 0, 150000, 1, TIMESTAMP(CURDATE() - INTERVAL 29 DAY, '18:41:00')),
  (34, 7, 8, 2, TIMESTAMP(CURDATE() - INTERVAL 9 DAY, '11:00:00'), NULL, 'completed', 250000, 0, 0, 250000, 2, TIMESTAMP(CURDATE() - INTERVAL 13 DAY, '19:30:00')),
  (35, 7, 8, 1, TIMESTAMP(CURDATE() + INTERVAL 0 DAY, '09:00:00'), NULL, 'confirmed', 150000, 0, 0, 150000, 0, TIMESTAMP(CURDATE() - INTERVAL 1 DAY, '20:11:00')),
  (36, 8, 9, 4, TIMESTAMP(CURDATE() - INTERVAL 22 DAY, '16:00:00'), NULL, 'completed', 80000, 0, 0, 80000, 0, TIMESTAMP(CURDATE() - INTERVAL 25 DAY, '17:33:00')),
  (37, 8, 10, 8, TIMESTAMP(CURDATE() - INTERVAL 10 DAY, '09:30:00'), NULL, 'completed', 120000, 0, 0, 120000, 1, TIMESTAMP(CURDATE() - INTERVAL 14 DAY, '19:25:00')),
  (38, 8, 9, 3, TIMESTAMP(CURDATE() - INTERVAL 3 DAY, '10:00:00'), 'Bận đột xuất, mình xin hủy.', 'cancelled', 300000, 10, 10000, 290000, 0, TIMESTAMP(CURDATE() - INTERVAL 6 DAY, '17:21:00')),
  (39, 8, 10, 1, TIMESTAMP(CURDATE() + INTERVAL 0 DAY, '11:30:00'), NULL, 'pending', 150000, 0, 0, 150000, 0, TIMESTAMP(CURDATE() - INTERVAL 1 DAY, '14:51:00')),
  (40, 8, 9, 5, TIMESTAMP(CURDATE() + INTERVAL 3 DAY, '13:00:00'), NULL, 'pending', 450000, 0, 0, 450000, 0, TIMESTAMP(CURDATE() - INTERVAL 1 DAY, '11:27:00')),
  (41, 9, 11, 3, TIMESTAMP(CURDATE() - INTERVAL 30 DAY, '10:00:00'), NULL, 'completed', 300000, 0, 0, 300000, 3, TIMESTAMP(CURDATE() - INTERVAL 33 DAY, '12:35:00')),
  (42, 9, 11, 2, TIMESTAMP(CURDATE() - INTERVAL 12 DAY, '15:00:00'), NULL, 'completed', 250000, 0, 0, 250000, 2, TIMESTAMP(CURDATE() - INTERVAL 13 DAY, '08:33:00')),
  (43, 10, 12, 2, TIMESTAMP(CURDATE() - INTERVAL 16 DAY, '09:30:00'), NULL, 'completed', 250000, 0, 0, 250000, 2, TIMESTAMP(CURDATE() - INTERVAL 18 DAY, '19:11:00')),
  (44, 10, 12, 2, TIMESTAMP(CURDATE() + INTERVAL 1 DAY, '10:00:00'), NULL, 'pending', 250000, 0, 0, 250000, 0, TIMESTAMP(CURDATE() - INTERVAL 3 DAY, '16:55:00')),
  (45, 11, 13, 1, TIMESTAMP(CURDATE() - INTERVAL 8 DAY, '14:00:00'), NULL, 'completed', 150000, 0, 0, 150000, 1, TIMESTAMP(CURDATE() - INTERVAL 12 DAY, '14:08:00')),
  (46, 11, 13, 3, TIMESTAMP(CURDATE() + INTERVAL 4 DAY, '09:00:00'), NULL, 'pending', 300000, 0, 0, 300000, 0, TIMESTAMP(CURDATE() + INTERVAL 2 DAY, '12:26:00')),
  (47, 12, 14, 6, TIMESTAMP(CURDATE() - INTERVAL 2 DAY, '08:00:00'), NULL, 'completed', 200000, 0, 0, 200000, 2, TIMESTAMP(CURDATE() - INTERVAL 6 DAY, '15:57:00')),
  (48, 12, 14, 1, TIMESTAMP(CURDATE() + INTERVAL 0 DAY, '15:30:00'), NULL, 'pending', 150000, 0, 0, 150000, 0, TIMESTAMP(CURDATE() - INTERVAL 1 DAY, '15:24:00')),
  (49, 13, 15, 4, TIMESTAMP(CURDATE() + INTERVAL 2 DAY, '11:00:00'), 'Cắt móng và vệ sinh tai cho bé.', 'pending', 80000, 0, 0, 80000, 0, TIMESTAMP(CURDATE() + INTERVAL 1 DAY, '12:57:00'));

INSERT INTO reviews (appointment_id, user_id, service_id, rating, comment, status, created_at) VALUES
  (1, 2, 2, 5, 'Bé nhà mình rất thích, ra về thơm và mượt hẳn. Nhân viên nhẹ nhàng, chắc chắn sẽ quay lại!', 'visible', TIMESTAMP(CURDATE() - INTERVAL 100 DAY, '21:00:00')),
  (2, 2, 5, 5, 'Gói spa thư giãn lắm, bé ngủ gật luôn trong lúc massage.', 'visible', TIMESTAMP(CURDATE() - INTERVAL 92 DAY, '21:00:00')),
  (5, 2, 3, 4, 'Cắt tỉa đẹp, hơi lâu hơn dự kiến một chút nhưng bù lại bé rất sạch sẽ.', 'visible', TIMESTAMP(CURDATE() - INTERVAL 60 DAY, '21:00:00')),
  (9, 2, 6, 5, 'Gửi bé ở khách sạn rất yên tâm, phòng sạch, có điều hòa và được gửi ảnh cập nhật.', 'visible', TIMESTAMP(CURDATE() - INTERVAL 21 DAY, '21:00:00')),
  (10, 2, 5, 5, 'Mình dùng điểm thưởng giảm trực tiếp, rất tiện.', 'visible', TIMESTAMP(CURDATE() - INTERVAL 12 DAY, '21:00:00')),
  (13, 3, 5, 4, 'Giá hợp lý, nhân viên thân thiện.', 'visible', TIMESTAMP(CURDATE() - INTERVAL 88 DAY, '21:00:00')),
  (19, 4, 3, 3, 'Tạm ổn, mình mong bên spa sấy kỹ hơn phần tai.', 'visible', TIMESTAMP(CURDATE() - INTERVAL 70 DAY, '21:00:00')),
  (22, 4, 2, 5, 'Kem đi spa về xinh hẳn, cảm ơn các bạn!', 'visible', TIMESTAMP(CURDATE() - INTERVAL 25 DAY, '21:00:00')),
  (25, 5, 1, 2, 'Đợi lâu hơn giờ hẹn gần 30 phút.', 'visible', TIMESTAMP(CURDATE() - INTERVAL 50 DAY, '21:00:00')),
  (29, 6, 5, 5, 'Samoyed lông dày mà vẫn được sấy rất kỹ, bông xù như mây.', 'visible', TIMESTAMP(CURDATE() - INTERVAL 35 DAY, '21:00:00')),
  (37, 8, 8, 1, 'Ghé shop bên mình rẻ hơn nhiều, nhắn tin ngay để nhận ưu đãi nhé các bạn!!!', 'hidden', TIMESTAMP(CURDATE() - INTERVAL 10 DAY, '21:00:00')),
  (43, 10, 2, 4, 'Bé Gấu lông dày nhưng được chăm rất kỹ.', 'visible', TIMESTAMP(CURDATE() - INTERVAL 16 DAY, '21:00:00'));

INSERT INTO messages (user_id, sender, content, is_handled, admin_id, created_at) VALUES
  (6, 'customer', 'Mình muốn hỏi bên mình có nhận tắm cho bé Samoyed lông dày không ạ? Giá thế nào?', 0, NULL, TIMESTAMP(CURDATE() - INTERVAL 2 DAY, '20:15:00')),
  (6, 'system', 'BabyBoss đã nhận được tin nhắn của bạn. Nhân viên sẽ phản hồi trong giờ làm việc (8:00 – 20:00). Cần gấp, vui lòng gọi hotline 0900 000 000.', 1, NULL, TIMESTAMP(CURDATE() - INTERVAL 2 DAY, '20:15:00')),
  (4, 'customer', 'Mình muốn đổi lịch hẹn hôm nay sang 16:30 được không?', 1, NULL, TIMESTAMP(CURDATE() - INTERVAL 3 DAY, '09:40:00')),
  (4, 'system', 'BabyBoss đã nhận được tin nhắn của bạn. Nhân viên sẽ phản hồi trong giờ làm việc (8:00 – 20:00). Cần gấp, vui lòng gọi hotline 0900 000 000.', 1, NULL, TIMESTAMP(CURDATE() - INTERVAL 3 DAY, '09:40:00')),
  (4, 'admin', 'Dạ chào chị Hà, bên em đã đổi lịch sang 16:30 hôm nay cho bé Kem rồi ạ. Hẹn gặp chị!', 1, 1, TIMESTAMP(CURDATE() - INTERVAL 3 DAY, '10:05:00')),
  (12, 'customer', 'Bé Husky nhà mình đang rụng lông nhiều, bên spa có gói xử lý rụng lông không?', 0, NULL, TIMESTAMP(CURDATE() - INTERVAL 1 DAY, '18:20:00')),
  (12, 'system', 'BabyBoss đã nhận được tin nhắn của bạn. Nhân viên sẽ phản hồi trong giờ làm việc (8:00 – 20:00). Cần gấp, vui lòng gọi hotline 0900 000 000.', 1, NULL, TIMESTAMP(CURDATE() - INTERVAL 1 DAY, '18:20:00')),
  (12, 'customer', 'Mình nhắn thêm: bé nặng khoảng 24 kg ạ.', 0, NULL, TIMESTAMP(CURDATE() - INTERVAL 1 DAY, '18:24:00')),
  (5, 'customer', 'Hóa đơn lần trước mình có được tích điểm chưa ạ?', 1, NULL, TIMESTAMP(CURDATE() - INTERVAL 5 DAY, '19:00:00')),
  (5, 'system', 'BabyBoss đã nhận được tin nhắn của bạn. Nhân viên sẽ phản hồi trong giờ làm việc (8:00 – 20:00). Cần gấp, vui lòng gọi hotline 0900 000 000.', 1, NULL, TIMESTAMP(CURDATE() - INTERVAL 5 DAY, '19:00:00')),
  (5, 'admin', 'Dạ lịch LH0026 đã hoàn thành và được cộng 2 điểm vào ví của anh rồi ạ.', 1, 1, TIMESTAMP(CURDATE() - INTERVAL 4 DAY, '08:50:00'));

INSERT INTO loyalty_transactions (user_id, type, points, balance_after, appointment_id, note, admin_id, created_at) VALUES
  (2, 'adjust', 20, 20, NULL, 'Tặng điểm chào mừng thành viên mới', 1, TIMESTAMP(CURDATE() - INTERVAL 120 DAY, '10:15:00')),
  (3, 'adjust', 20, 20, NULL, 'Tặng điểm chào mừng thành viên mới', 1, TIMESTAMP(CURDATE() - INTERVAL 105 DAY, '10:15:00')),
  (2, 'earn', 2, 22, 1, 'Tích 1% (hạng Bạc) cho lịch LH0001', 1, TIMESTAMP(CURDATE() - INTERVAL 100 DAY, '11:00:00')),
  (4, 'adjust', 20, 20, NULL, 'Tặng điểm chào mừng thành viên mới', 1, TIMESTAMP(CURDATE() - INTERVAL 98 DAY, '10:15:00')),
  (2, 'earn', 4, 26, 2, 'Tích 1% (hạng Bạc) cho lịch LH0002', 1, TIMESTAMP(CURDATE() - INTERVAL 92 DAY, '12:30:00')),
  (3, 'earn', 4, 24, 13, 'Tích 1% (hạng Bạc) cho lịch LH0013', 1, TIMESTAMP(CURDATE() - INTERVAL 88 DAY, '13:00:00')),
  (5, 'adjust', 20, 20, NULL, 'Tặng điểm chào mừng thành viên mới', 1, TIMESTAMP(CURDATE() - INTERVAL 80 DAY, '10:15:00')),
  (2, 'earn', 3, 29, 3, 'Tích 1% (hạng Bạc) cho lịch LH0003', 1, TIMESTAMP(CURDATE() - INTERVAL 80 DAY, '16:00:00')),
  (3, 'earn', 2, 26, 14, 'Tích 1% (hạng Bạc) cho lịch LH0014', 1, TIMESTAMP(CURDATE() - INTERVAL 75 DAY, '11:00:00')),
  (2, 'earn', 4, 33, 4, 'Tích 1% (hạng Bạc) cho lịch LH0004', 1, TIMESTAMP(CURDATE() - INTERVAL 70 DAY, '11:30:00')),
  (4, 'earn', 3, 23, 19, 'Tích 1% (hạng Bạc) cho lịch LH0019', 1, TIMESTAMP(CURDATE() - INTERVAL 70 DAY, '12:00:00')),
  (6, 'adjust', 20, 20, NULL, 'Tặng điểm chào mừng thành viên mới', 1, TIMESTAMP(CURDATE() - INTERVAL 66 DAY, '10:15:00')),
  (7, 'adjust', 20, 20, NULL, 'Tặng điểm chào mừng thành viên mới', 1, TIMESTAMP(CURDATE() - INTERVAL 60 DAY, '10:15:00')),
  (3, 'earn', 3, 29, 15, 'Tích 1% (hạng Bạc) cho lịch LH0015', 1, TIMESTAMP(CURDATE() - INTERVAL 60 DAY, '16:30:00')),
  (2, 'earn', 3, 36, 5, 'Tích 1% (hạng Bạc) cho lịch LH0005', 1, TIMESTAMP(CURDATE() - INTERVAL 60 DAY, '17:00:00')),
  (4, 'earn', 4, 27, 20, 'Tích 1% (hạng Bạc) cho lịch LH0020', 1, TIMESTAMP(CURDATE() - INTERVAL 55 DAY, '11:00:00')),
  (5, 'earn', 1, 21, 25, 'Tích 1% (hạng Bạc) cho lịch LH0025', 1, TIMESTAMP(CURDATE() - INTERVAL 50 DAY, '11:00:00')),
  (2, 'earn', 13, 49, 6, 'Tích 3% (hạng Vàng) cho lịch LH0006', 1, TIMESTAMP(CURDATE() - INTERVAL 50 DAY, '12:00:00')),
  (8, 'adjust', 20, 20, NULL, 'Tặng điểm chào mừng thành viên mới', 1, TIMESTAMP(CURDATE() - INTERVAL 45 DAY, '10:15:00')),
  (3, 'earn', 4, 33, 16, 'Tích 1% (hạng Bạc) cho lịch LH0016', 1, TIMESTAMP(CURDATE() - INTERVAL 45 DAY, '12:00:00')),
  (2, 'earn', 15, 64, 7, 'Tích 3% (hạng Vàng) cho lịch LH0007', 1, TIMESTAMP(CURDATE() - INTERVAL 41 DAY, '11:00:00')),
  (4, 'earn', 3, 30, 21, 'Tích 1% (hạng Bạc) cho lịch LH0021', 1, TIMESTAMP(CURDATE() - INTERVAL 40 DAY, '16:00:00')),
  (6, 'earn', 4, 24, 29, 'Tích 1% (hạng Bạc) cho lịch LH0029', 1, TIMESTAMP(CURDATE() - INTERVAL 35 DAY, '11:30:00')),
  (9, 'earn', 3, 3, 41, 'Tích 1% (hạng Bạc) cho lịch LH0041', 1, TIMESTAMP(CURDATE() - INTERVAL 30 DAY, '12:00:00')),
  (3, 'earn', 2, 35, 17, 'Tích 1% (hạng Bạc) cho lịch LH0017', 1, TIMESTAMP(CURDATE() - INTERVAL 30 DAY, '17:30:00')),
  (2, 'earn', 9, 73, 8, 'Tích 3% (hạng Vàng) cho lịch LH0008', 1, TIMESTAMP(CURDATE() - INTERVAL 30 DAY, '18:00:00')),
  (7, 'earn', 1, 21, 33, 'Tích 1% (hạng Bạc) cho lịch LH0033', 1, TIMESTAMP(CURDATE() - INTERVAL 28 DAY, '12:00:00')),
  (4, 'earn', 2, 32, 22, 'Tích 1% (hạng Bạc) cho lịch LH0022', 1, TIMESTAMP(CURDATE() - INTERVAL 25 DAY, '13:00:00')),
  (2, 'earn', 6, 79, 9, 'Tích 3% (hạng Vàng) cho lịch LH0009', 1, TIMESTAMP(CURDATE() - INTERVAL 21 DAY, '10:00:00')),
  (5, 'earn', 2, 23, 26, 'Tích 1% (hạng Bạc) cho lịch LH0026', 1, TIMESTAMP(CURDATE() - INTERVAL 20 DAY, '12:00:00')),
  (6, 'redeem', -10, 14, 30, 'Dùng 10 điểm giảm 10.000 ₫ khi đặt lịch LH0030', NULL, TIMESTAMP(CURDATE() - INTERVAL 19 DAY, '20:14:00')),
  (6, 'earn', 2, 16, 30, 'Tích 1% (hạng Bạc) cho lịch LH0030', 1, TIMESTAMP(CURDATE() - INTERVAL 18 DAY, '16:00:00')),
  (10, 'earn', 2, 2, 43, 'Tích 1% (hạng Bạc) cho lịch LH0043', 1, TIMESTAMP(CURDATE() - INTERVAL 16 DAY, '11:30:00')),
  (2, 'redeem', -20, 59, 10, 'Dùng 20 điểm giảm 20.000 ₫ khi đặt lịch LH0010', NULL, TIMESTAMP(CURDATE() - INTERVAL 16 DAY, '19:35:00')),
  (4, 'earn', 4, 36, 23, 'Tích 1% (hạng Bạc) cho lịch LH0023', 1, TIMESTAMP(CURDATE() - INTERVAL 15 DAY, '12:30:00')),
  (2, 'earn', 12, 71, 10, 'Tích 3% (hạng Vàng) cho lịch LH0010', 1, TIMESTAMP(CURDATE() - INTERVAL 12 DAY, '12:00:00')),
  (9, 'earn', 2, 5, 42, 'Tích 1% (hạng Bạc) cho lịch LH0042', 1, TIMESTAMP(CURDATE() - INTERVAL 12 DAY, '17:00:00')),
  (8, 'earn', 1, 21, 37, 'Tích 1% (hạng Bạc) cho lịch LH0037', 1, TIMESTAMP(CURDATE() - INTERVAL 10 DAY, '11:30:00')),
  (7, 'earn', 2, 23, 34, 'Tích 1% (hạng Bạc) cho lịch LH0034', 1, TIMESTAMP(CURDATE() - INTERVAL 9 DAY, '13:00:00')),
  (11, 'earn', 1, 1, 45, 'Tích 1% (hạng Bạc) cho lịch LH0045', 1, TIMESTAMP(CURDATE() - INTERVAL 8 DAY, '16:00:00')),
  (8, 'redeem', -10, 11, 38, 'Dùng 10 điểm giảm 10.000 ₫ khi đặt lịch LH0038', NULL, TIMESTAMP(CURDATE() - INTERVAL 6 DAY, '17:21:00')),
  (2, 'earn', 10, 81, 11, 'Tích 5% (hạng Kim Cương) cho lịch LH0011', 1, TIMESTAMP(CURDATE() - INTERVAL 5 DAY, '10:30:00')),
  (8, 'refund', 10, 21, 38, 'Hoàn điểm do lịch LH0038 bị hủy', 1, TIMESTAMP(CURDATE() - INTERVAL 3 DAY, '07:00:00')),
  (12, 'earn', 2, 2, 47, 'Tích 1% (hạng Bạc) cho lịch LH0047', 1, TIMESTAMP(CURDATE() - INTERVAL 2 DAY, '10:00:00'));

SET FOREIGN_KEY_CHECKS = 1;
