<?php
/**
 * Cấu hình chung của BabyBoss Pet Spa.
 * Chỉnh mục 'db' cho khớp với MySQL trên XAMPP của bạn.
 */
return [
    'app' => [
        'name'     => 'BabyBoss Pet Spa',
        'debug'    => true,                 // đổi thành false khi triển khai thật
        'timezone' => 'Asia/Ho_Chi_Minh',
        'base_url' => '',                   // để trống = tự nhận diện (vd: /babyboss)
    ],
    'db' => [
        'host'    => '127.0.0.1',
        'port'    => 3306,
        'name'    => 'babyboss',
        'user'    => 'root',
        'pass'    => '',
        'charset' => 'utf8mb4',
    ],
    // Thông tin hiển thị ở header/footer, trang Giới thiệu, Liên hệ — hãy thay bằng thông tin thật của tiệm
    'shop' => [
        'name'    => 'BabyBoss Pet Spa',
        'hotline' => '0900 000 000',
        'email'   => 'hello@babyboss.vn',
        'address' => '123 Đường Mẫu, Quận 1, TP. Hồ Chí Minh',
        'hours'   => '8:00 – 20:00 hằng ngày',
    ],
    // Quy tắc đặt lịch
    'booking' => [
        'open'             => '08:00',    // khung giờ đầu tiên
        'close'            => '19:30',    // khung giờ cuối cùng
        'step'             => 30,         // mỗi khung cách nhau (phút)
        'min_lead_minutes' => 60,         // phải đặt trước giờ hẹn ít nhất 60 phút
        'max_days_ahead'   => 60,         // chỉ nhận đặt trước tối đa 60 ngày
    ],
    'upload' => [
        'max_size' => 2 * 1024 * 1024,      // tối đa 2 MB / ảnh
    ],
    // Số dòng mỗi trang cho từng danh sách trong khu vực admin
    'per_page' => [
        'users' => 8, 'services' => 6, 'appointments' => 10,
        'reviews' => 8, 'messages' => 8, 'loyalty' => 10, 'history' => 12,
        // khu vực khách hàng
        'client_services' => 6, 'client_appointments' => 5, 'client_points' => 8,
    ],
];
