<?php
/**
 * Khai báo toàn bộ route của khu vực khách hàng.
 * Dạng URL:  /index.php?route=services/3
 * @var \App\Core\Router $router
 */
use App\Middleware\CustomerMiddleware;

$customer = [CustomerMiddleware::class];   // yêu cầu khách hàng đã đăng nhập

// Trang công khai
$router->get('home',          'HomeController@index');
$router->get('about',         'PageController@about');
$router->get('services',      'ServiceController@index');
$router->get('services/{id}', 'ServiceController@show');
$router->get('contact',       'ContactController@index');

// Tài khoản
$router->get('login',     'AuthController@showLogin');
$router->post('login',    'AuthController@login');
$router->get('register',  'AuthController@showRegister');
$router->post('register', 'AuthController@register');
$router->post('logout',   'AuthController@logout');

// Thú cưng của tôi
$router->get('pets',                 'PetController@index',   $customer);
$router->get('pets/create',          'PetController@create',  $customer);
$router->post('pets/store',          'PetController@store',   $customer);
$router->get('pets/{id}/edit',       'PetController@edit',    $customer);
$router->post('pets/{id}/update',    'PetController@update',  $customer);
$router->post('pets/{id}/delete',    'PetController@destroy', $customer);

// Đặt lịch, lịch sử, đánh giá
$router->get('book',                      'BookingController@create', $customer);
$router->post('book',                     'BookingController@store',  $customer);
$router->get('appointments',              'BookingController@index',  $customer);
$router->post('appointments/{id}/cancel', 'BookingController@cancel', $customer);
$router->post('reviews',                  'ReviewController@store',   $customer);

// Điểm thưởng & tin nhắn
$router->get('loyalty',  'LoyaltyController@index', $customer);
$router->post('contact', 'ContactController@send',  $customer);
