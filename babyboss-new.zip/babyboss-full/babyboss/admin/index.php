<?php
/** Front controller của khu vực Admin — mọi request /admin/... đều đi qua file này. */
require dirname(__DIR__) . '/app/bootstrap.php';

use App\Core\{Request, Router};

$router = new Router('App\\Controllers\\Admin\\', 'dashboard');
require BASE_PATH . '/config/routes.admin.php';
$router->dispatch(Request::capture());
