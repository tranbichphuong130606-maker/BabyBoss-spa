/* BabyBoss — JavaScript khu vực khách hàng (thuần, không cần thư viện) */
(function () {
  'use strict';
  var body = document.body;
  var money = function (n) { return Number(n).toLocaleString('vi-VN') + ' ₫'; };
  var duration = function (m) {
    m = Number(m);
    if (m < 60) return m + ' phút';
    var h = Math.floor(m / 60), r = m % 60;
    return h + ' giờ' + (r ? ' ' + r + ' phút' : '');
  };

  // Menu trên điện thoại
  var menuBtn = document.getElementById('menuBtn');
  if (menuBtn) menuBtn.addEventListener('click', function () {
    var open = body.classList.toggle('nav-open');
    menuBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
  });

  // Menu tài khoản: đóng khi bấm ra ngoài hoặc nhấn Esc
  var userMenu = document.querySelector('.usermenu');
  if (userMenu) {
    document.addEventListener('click', function (e) { if (!userMenu.contains(e.target)) userMenu.removeAttribute('open'); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') userMenu.removeAttribute('open'); });
  }

  // Đóng thông báo; thông báo thành công tự ẩn sau 6 giây
  document.querySelectorAll('.alert').forEach(function (box) {
    var close = box.querySelector('.alert-x');
    if (close) close.addEventListener('click', function () { box.classList.add('hide'); });
    if (box.classList.contains('alert-success')) setTimeout(function () { box.classList.add('hide'); }, 6000);
  });

  // Hộp thoại xác nhận cho form có data-confirm
  var confirmDialog = document.getElementById('confirmDialog');
  var pendingForm = null;
  if (confirmDialog && typeof confirmDialog.showModal === 'function') {
    document.addEventListener('submit', function (e) {
      var form = e.target;
      if (!form.dataset || !form.dataset.confirm || form.dataset.confirmed) return;
      e.preventDefault();
      pendingForm = form;
      document.getElementById('confirmText').textContent = form.dataset.confirm;
      var ok = document.getElementById('confirmOk');
      ok.textContent = form.dataset.confirmLabel || 'Đồng ý';
      confirmDialog.showModal();
    });
    confirmDialog.addEventListener('close', function () {
      if (confirmDialog.returnValue === 'ok' && pendingForm) { pendingForm.dataset.confirmed = '1'; pendingForm.submit(); }
      pendingForm = null;
      confirmDialog.returnValue = '';
    });
    confirmDialog.addEventListener('click', function (e) { if (e.target === confirmDialog) confirmDialog.close(); });
  } else {
    document.addEventListener('submit', function (e) {
      var f = e.target;
      if (f.dataset && f.dataset.confirm && !window.confirm(f.dataset.confirm)) e.preventDefault();
    });
  }

  // Hiện / ẩn mật khẩu
  document.querySelectorAll('[data-toggle-pw]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var input = btn.parentElement.querySelector('input');
      var show = input.type === 'password';
      input.type = show ? 'text' : 'password';
      btn.setAttribute('aria-label', show ? 'Ẩn mật khẩu' : 'Hiện mật khẩu');
    });
  });

  // Xem trước ảnh đại diện của bé
  document.querySelectorAll('input[type=file][data-preview]').forEach(function (input) {
    input.addEventListener('change', function () {
      var img = document.getElementById(input.dataset.preview);
      var placeholder = document.getElementById('previewPh');
      var file = input.files && input.files[0];
      if (!file || !img) return;
      img.src = URL.createObjectURL(file);
      img.hidden = false;
      if (placeholder) placeholder.hidden = true;
    });
  });

  // Trang chủ: khung đặt lịch nhanh hiện giá và thời gian của dịch vụ đã chọn
  var quick = document.getElementById('quickService');
  if (quick) {
    var note = document.getElementById('quickNote');
    quick.addEventListener('change', function () {
      var o = quick.options[quick.selectedIndex];
      note.textContent = o && o.dataset.price
        ? 'Giá ' + money(o.dataset.price) + ', thực hiện trong ' + duration(o.dataset.duration) + '.'
        : 'Chọn dịch vụ để xem giá và thời gian thực hiện.';
    });
  }

  // Form đặt lịch: tóm tắt giá, giảm giá bằng điểm, khóa các giờ đã qua của hôm nay
  var form = document.getElementById('bookingForm');
  if (form) {
    var pointValue = Number(form.dataset.pointValue) || 1000;
    var balance = Number(form.dataset.balance) || 0;
    var lead = Number(form.dataset.lead) || 60;
    var service = form.querySelector('[name=service_id]');
    var points = form.querySelector('[name=points]');
    var dateInput = form.querySelector('[name=date]');
    var time = form.querySelector('[name=time]');
    var help = document.getElementById('pointsHelp');
    var $ = function (id) { return document.getElementById(id); };

    var update = function () {
      var opt = service.options[service.selectedIndex];
      var price = opt && opt.dataset.price ? Number(opt.dataset.price) : 0;
      var maxPoints = Math.min(balance, Math.floor(price / pointValue));
      var typed = points && points.type !== 'hidden' ? (parseInt(points.value, 10) || 0) : 0;
      var applied = Math.max(0, Math.min(typed, maxPoints));
      $('sumService').textContent = price ? opt.textContent.replace(/\s*\(.*\)\s*$/, '').trim() : 'Chưa chọn';
      $('sumDuration').textContent = price ? duration(opt.dataset.duration) : '–';
      $('sumPrice').textContent = price ? money(price) : '–';
      $('sumDiscount').textContent = applied > 0 ? '−' + money(applied * pointValue) + ' (' + applied + ' điểm)' : '0 ₫';
      $('sumTotal').textContent = price ? money(price - applied * pointValue) : '–';
      if (help && price) {
        help.textContent = 'Bạn có ' + balance.toLocaleString('vi-VN') + ' điểm. Dịch vụ này dùng được tối đa ' + maxPoints + ' điểm (giảm ' + money(maxPoints * pointValue) + ').';
      }
    };

    var limitTimes = function () {
      if (!dateInput || !time) return;
      var now = new Date();
      var pad = function (n) { return String(n).padStart(2, '0'); };
      var today = now.getFullYear() + '-' + pad(now.getMonth() + 1) + '-' + pad(now.getDate());
      var earliest = now.getHours() * 60 + now.getMinutes() + lead;
      Array.prototype.forEach.call(time.options, function (o) {
        if (!o.value) return;
        var p = o.value.split(':');
        o.disabled = dateInput.value === today && Number(p[0]) * 60 + Number(p[1]) < earliest;
      });
      if (time.selectedOptions[0] && time.selectedOptions[0].disabled) time.value = '';
    };

    service.addEventListener('change', update);
    if (points) points.addEventListener('input', update);
    if (dateInput) dateInput.addEventListener('change', limitTimes);
    update();
    limitTimes();
  }

  // Hộp thoại đánh giá dịch vụ
  var review = document.getElementById('reviewDialog');
  if (review) {
    var apptField = document.getElementById('rvAppt');
    var svcLabel = document.getElementById('rvService');
    document.querySelectorAll('.js-review').forEach(function (btn) {
      btn.addEventListener('click', function () {
        apptField.value = btn.dataset.appt;
        svcLabel.textContent = btn.dataset.service;
        review.querySelectorAll('input[name=rating]').forEach(function (r) { r.checked = false; });
        review.querySelector('textarea').value = '';
        review.showModal();
      });
    });
    review.querySelectorAll('[data-close]').forEach(function (b) { b.addEventListener('click', function () { review.close(); }); });
    review.addEventListener('click', function (e) { if (e.target === review) review.close(); });
  }

  // Cuộn hội thoại xuống tin mới nhất
  var chat = document.getElementById('chatThread');
  if (chat) chat.scrollTop = chat.scrollHeight;
})();
