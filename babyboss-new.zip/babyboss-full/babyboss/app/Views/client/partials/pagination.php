<?php
/**
 * Thanh phân trang khu vực khách hàng.
 * @var \App\Core\Paginator $pager
 * @var string $route   route của danh sách (vd: 'services')
 * @var array  $query   bộ lọc hiện tại, được giữ nguyên khi chuyển trang
 */
$query = $query ?? [];
$link  = fn(int $p): string => url($route, $query + ['page' => $p > 1 ? $p : null]);
?>
<?php if ($pager->pages > 1): ?>
<nav class="pager-nav" aria-label="Phân trang">
    <span class="muted small">Trang <?= $pager->page ?> trên <?= $pager->pages ?></span>
    <div class="pages">
        <?php if ($pager->page > 1): ?><a href="<?= e($link($pager->page - 1)) ?>" aria-label="Trang trước">‹</a><?php else: ?><span class="disabled">‹</span><?php endif; ?>
        <?php foreach ($pager->window() as $p): ?>
            <?php if ($p === null): ?>
                <span class="gap">…</span>
            <?php else: ?>
                <a class="<?= $p === $pager->page ? 'current' : '' ?>" href="<?= e($link($p)) ?>" <?= $p === $pager->page ? 'aria-current="page"' : '' ?>><?= $p ?></a>
            <?php endif; ?>
        <?php endforeach; ?>
        <?php if ($pager->page < $pager->pages): ?><a href="<?= e($link($pager->page + 1)) ?>" aria-label="Trang sau">›</a><?php else: ?><span class="disabled">›</span><?php endif; ?>
    </div>
</nav>
<?php endif; ?>
