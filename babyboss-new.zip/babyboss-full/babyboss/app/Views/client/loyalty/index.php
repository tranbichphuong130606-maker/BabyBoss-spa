<?php
/** @var array $progress @var array $tiers @var int $pointValue @var array $transactions @var \App\Core\Paginator $pager @var array $me */
use App\Models\LoyaltyTransaction;

$points  = (int) $me['points'];
$current = $progress['current'];
$next    = $progress['next'];
?>
<div class="wrap page">
    <div class="page-head">
        <div>
            <h1>Điểm thưởng</h1>
            <p class="muted">Điểm hiện có, hạng thành viên và lịch sử tích điểm, dùng điểm của bạn.</p>
        </div>
        <a class="btn btn-primary" href="<?= e(url('book')) ?>">Đặt lịch và dùng điểm</a>
    </div>

    <div class="wallet">
        <section class="panel wallet-main">
            <p class="muted">Điểm hiện có</p>
            <p class="wallet-points"><?= number_format($points, 0, ',', '.') ?></p>
            <p class="muted">Tương đương <b><?= e(money($points * $pointValue)) ?></b> giảm vào hóa đơn khi đặt lịch.</p>
            <hr>
            <div class="wallet-tier">
                <span class="tier tier-<?= e(tier_class($current['name'])) ?>">Hạng <?= e($current['name']) ?></span>
                <?php if ($next): ?>
                    <div class="progress" role="progressbar" aria-valuenow="<?= (int) $progress['percent'] ?>" aria-valuemin="0" aria-valuemax="100"><span style="width:<?= max(2, min(100, (int) $progress['percent'])) ?>%"></span></div>
                    <p class="muted small">Còn <b><?= e(money($progress['remaining'])) ?></b> chi tiêu để lên hạng <?= e($next['name']) ?>.</p>
                <?php else: ?>
                    <p class="muted small">Bạn đang ở hạng cao nhất.</p>
                <?php endif; ?>
                <p class="muted small">Tổng chi tiêu của các lịch đã hoàn thành: <b><?= e(money($me['total_spent'])) ?></b></p>
            </div>
        </section>

        <section class="panel">
            <h2>Cách tích và dùng điểm</h2>
            <ul class="rules">
                <li>Mỗi lịch hoàn thành được cộng điểm theo tỷ lệ của hạng hiện tại.</li>
                <li>1 điểm giảm <?= e(money($pointValue)) ?> trực tiếp vào hóa đơn khi đặt lịch.</li>
                <li>Hủy lịch đã dùng điểm sẽ được hoàn lại điểm.</li>
            </ul>
            <div class="table-wrap">
                <table class="table tier-table">
                    <thead><tr><th>Hạng</th><th class="num">Tổng chi tiêu từ</th><th class="num">Tích điểm</th></tr></thead>
                    <tbody>
                    <?php foreach ($tiers as $t): ?>
                        <tr class="<?= (int) $t['id'] === (int) $current['id'] ? 'is-current' : '' ?>">
                            <td><span class="tier tier-<?= e(tier_class($t['name'])) ?>"><?= e($t['name']) ?></span></td>
                            <td class="num"><?= e(money($t['min_spent'])) ?></td>
                            <td class="num"><?= e((string) (float) $t['earn_rate']) ?>%</td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </section>
    </div>

    <section class="history">
        <h2>Lịch sử điểm</h2>
        <?php if (!$transactions): ?>
            <div class="panel empty-state">
                <h2>Chưa có giao dịch điểm nào</h2>
                <p class="muted">Điểm sẽ được cộng khi lịch spa của bạn hoàn thành.</p>
            </div>
        <?php else: ?>
            <div class="panel flush">
                <div class="table-wrap">
                    <table class="table">
                        <thead><tr><th>Thời gian</th><th class="wide">Nội dung</th><th>Loại</th><th class="num">Điểm</th><th class="num">Số dư sau</th></tr></thead>
                        <tbody>
                        <?php foreach ($transactions as $t): ?>
                            <?php $pts = (int) $t['points']; ?>
                            <tr>
                                <td class="muted nowrap"><?= e(fmt_date($t['created_at'])) ?></td>
                                <td class="wide"><?= e($t['note']) ?></td>
                                <td><?= badge('ty-' . $t['type'], LoyaltyTransaction::TYPES[$t['type']]) ?></td>
                                <td class="num"><b class="<?= $pts >= 0 ? 'pos' : 'neg' ?>"><?= $pts > 0 ? '+' : '−' ?><?= number_format(abs($pts), 0, ',', '.') ?></b></td>
                                <td class="num"><?= number_format((int) $t['balance_after'], 0, ',', '.') ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php partial('pagination', ['pager' => $pager, 'route' => 'loyalty', 'query' => []]); ?>
        <?php endif; ?>
    </section>
</div>
