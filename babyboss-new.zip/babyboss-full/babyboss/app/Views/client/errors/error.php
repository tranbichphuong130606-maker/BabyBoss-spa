<?php /** @var int $code @var string $message */ ?>
<!doctype html>
<html lang="vi">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($title) ?> – <?= e(shop('name')) ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Baloo+2:wght@700&amp;family=Be+Vietnam+Pro:wght@400;600&amp;display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= e(asset('css/base.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('css/site.css')) ?>">
</head>
<body class="site plain">
<main class="error-box">
    <div class="error-code"><?= (int) $code ?></div>
    <h1><?= e($message) ?></h1>
    <p class="muted">Bạn có thể quay về trang chủ hoặc xem danh sách dịch vụ.</p>
    <p><a class="btn btn-primary" href="<?= e(url()) ?>">Về trang chủ</a> <a class="btn btn-outline" href="<?= e(url('services')) ?>">Xem dịch vụ</a></p>
</main>
</body>
</html>
