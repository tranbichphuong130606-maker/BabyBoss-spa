<?php /** @var ?array $me @var array $thread @var string $draft @var ?string $error */ ?>
<div class="wrap page">
    <div class="page-head">
        <div>
            <h1>Liên hệ</h1>
            <p class="muted">Gọi hotline hoặc nhắn tin cho BabyBoss. Nhân viên phản hồi trong giờ làm việc.</p>
        </div>
    </div>

    <div class="contact-grid">
        <section class="panel info-box">
            <h2>Hotline</h2>
            <a class="hotline-big" href="<?= e(tel_href(shop('hotline'))) ?>"><?= icon('phone', 26) ?> <?= e(shop('hotline')) ?></a>
            <dl class="kv stack">
                <div><dt>Giờ làm việc</dt><dd><?= e(shop('hours')) ?></dd></div>
                <div><dt>Địa chỉ</dt><dd><?= e(shop('address')) ?></dd></div>
                <div><dt>Email</dt><dd><?= e(shop('email')) ?></dd></div>
            </dl>
        </section>

        <section class="panel" id="chat">
            <h2>Nhắn tin cho BabyBoss</h2>
            <?php if (!$me): ?>
                <p class="muted">Đăng nhập để nhắn tin và xem phản hồi của nhân viên ngay tại đây.</p>
                <a class="btn btn-primary" href="<?= e(url('login')) ?>">Đăng nhập để nhắn tin</a>
                <a class="btn btn-ghost" href="<?= e(url('register')) ?>">Tạo tài khoản</a>
            <?php elseif ($me['role'] === 'admin'): ?>
                <p class="muted">Bạn đang đăng nhập bằng tài khoản quản trị. Tin nhắn của khách được xử lý trong khu vực quản trị.</p>
                <a class="btn btn-primary" href="<?= e(admin_url('messages')) ?>">Mở tin nhắn khách hàng</a>
            <?php else: ?>
                <div class="chat" id="chatThread" tabindex="0" aria-label="Nội dung hội thoại">
                    <?php foreach ($thread as $m): ?>
                        <div class="msg msg-<?= e($m['sender'] === 'customer' ? 'admin' : ($m['sender'] === 'admin' ? 'customer' : 'system')) ?>">
                            <?php if ($m['sender'] === 'system'): ?><small class="msg-who">Tự động trả lời</small>
                            <?php elseif ($m['sender'] === 'admin'): ?><small class="msg-who">Nhân viên BabyBoss</small>
                            <?php else: ?><small class="msg-who">Bạn</small><?php endif; ?>
                            <div class="bubble"><?= nl2br(e($m['content'])) ?></div>
                            <time><?= e(fmt_date($m['created_at'], 'd/m/Y H:i')) ?></time>
                        </div>
                    <?php endforeach; ?>
                    <?php if (!$thread): ?><div class="empty compact"><p class="muted">Bạn chưa nhắn tin nào. Hãy hỏi BabyBoss bất cứ điều gì về dịch vụ.</p></div><?php endif; ?>
                </div>

                <form class="reply" method="post" action="<?= e(url('contact')) ?>">
                    <?= csrf_field() ?>
                    <label class="field <?= $error ? 'has-error' : '' ?>">
                        <span>Tin nhắn của bạn</span>
                        <textarea class="input" name="content" rows="3" maxlength="1000" placeholder="Ví dụ: Bên mình có nhận tắm cho bé Samoyed lông dày không ạ?" required><?= e($draft) ?></textarea>
                        <?php if ($error): ?><small class="field-error"><?= e($error) ?></small><?php endif; ?>
                    </label>
                    <div class="form-actions"><button class="btn btn-primary" type="submit"><?= icon('send', 16) ?> Gửi tin nhắn</button></div>
                </form>
            <?php endif; ?>
        </section>
    </div>
</div>
