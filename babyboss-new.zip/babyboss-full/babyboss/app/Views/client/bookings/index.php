<?php
/** @var string $status @var array $counts @var array $appointments @var \App\Core\Paginator $pager */
use App\Models\Appointment;
?>
<div class="wrap page">
    <div class="page-head">
        <div>
            <h1>Lịch hẹn của tôi</h1>
            <p class="muted">Theo dõi trạng thái duyệt của từng lịch. Lịch hoàn thành có thể đánh giá để giúp khách khác chọn dịch vụ.</p>
        </div>
        <a class="btn btn-primary" href="<?= e(url('book')) ?>"><?= icon('plus', 16) ?> Đặt lịch mới</a>
    </div>

    <nav class="tabs" aria-label="Lọc theo trạng thái">
        <a class="<?= $status === '' ? 'active' : '' ?>" href="<?= e(url('appointments')) ?>">Tất cả <span><?= array_sum($counts) ?></span></a>
        <?php foreach (Appointment::STATUSES as $key => $label): ?>
            <a class="<?= $status === $key ? 'active' : '' ?>" href="<?= e(url('appointments', ['status' => $key])) ?>"><?= e($label) ?> <span><?= (int) $counts[$key] ?></span></a>
        <?php endforeach; ?>
    </nav>

    <?php if (!$appointments): ?>
        <div class="panel empty-state">
            <h2><?= $status === '' ? 'Bạn chưa đặt lịch nào' : 'Không có lịch nào ở trạng thái này' ?></h2>
            <p class="muted"><?= $status === '' ? 'Chọn dịch vụ và giờ hẹn để đặt lịch đầu tiên cho bé.' : 'Chọn tab "Tất cả" để xem mọi lịch hẹn.' ?></p>
            <a class="btn btn-primary" href="<?= e(url($status === '' ? 'book' : 'appointments')) ?>"><?= $status === '' ? 'Đặt lịch' : 'Xem tất cả lịch' ?></a>
        </div>
    <?php else: ?>
        <div class="appt-list">
            <?php foreach ($appointments as $a): ?>
                <?php $code = appt_code((int) $a['id']); ?>
                <article class="appt appt-<?= e($a['status']) ?>">
                    <div class="appt-head">
                        <b class="code"><?= e($code) ?></b>
                        <?= badge('st-' . $a['status'], Appointment::STATUSES[$a['status']]) ?>
                    </div>
                    <h2><a href="<?= e(url('services/' . $a['service_id'])) ?>"><?= e($a['service_name']) ?></a></h2>
                    <dl class="kv row">
                        <div><dt>Bé cưng</dt><dd><?= $a['pet_name'] !== null ? e($a['pet_name']) : '<span class="muted">Hồ sơ đã xóa</span>' ?></dd></div>
                        <div><dt>Giờ hẹn</dt><dd><?= e(fmt_date($a['appointment_date'])) ?></dd></div>
                        <div>
                            <dt>Thanh toán</dt>
                            <dd>
                                <?= e(money($a['total_amount'])) ?>
                                <?php if ((int) $a['points_used'] > 0): ?><small class="muted">đã giảm <?= e(money($a['discount'])) ?> bằng <?= (int) $a['points_used'] ?> điểm</small><?php endif; ?>
                            </dd>
                        </div>
                    </dl>
                    <?php if ($a['note']): ?><p class="muted small">Ghi chú của bạn: <?= e($a['note']) ?></p><?php endif; ?>
                    <?php if ($a['status'] === 'completed' && (int) $a['points_earned'] > 0): ?>
                        <p class="earned">Đã cộng <?= (int) $a['points_earned'] ?> điểm thưởng cho lịch này.</p>
                    <?php endif; ?>

                    <div class="appt-actions">
                        <?php if ($a['status'] === 'pending'): ?>
                            <form method="post" action="<?= e(url('appointments/' . $a['id'] . '/cancel')) ?>"
                                  data-confirm="<?= e('Hủy lịch ' . $code . '? Nếu bạn đã dùng điểm thưởng, điểm sẽ được hoàn lại.') ?>" data-confirm-label="Hủy lịch">
                                <?= csrf_field() ?>
                                <button class="btn btn-outline btn-sm" type="submit">Hủy lịch</button>
                            </form>
                        <?php elseif ($a['status'] === 'completed' && $a['review_rating'] === null): ?>
                            <button class="btn btn-primary btn-sm js-review" type="button" data-appt="<?= (int) $a['id'] ?>" data-service="<?= e($a['service_name']) ?>">Đánh giá dịch vụ</button>
                        <?php elseif ($a['status'] === 'completed'): ?>
                            <span class="stars" aria-label="Bạn đã chấm <?= (int) $a['review_rating'] ?> trên 5 sao"><?= e(stars((int) $a['review_rating'])) ?></span>
                            <span class="muted small">Bạn đã đánh giá lịch này</span>
                        <?php endif; ?>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
        <?php partial('pagination', ['pager' => $pager, 'route' => 'appointments', 'query' => ['status' => $status]]); ?>
    <?php endif; ?>
</div>

<dialog id="reviewDialog" class="modal" aria-labelledby="rvTitle">
    <form class="modal-box" method="post" action="<?= e(url('reviews')) ?>">
        <?= csrf_field() ?>
        <input type="hidden" name="appointment_id" id="rvAppt">
        <h3 id="rvTitle">Đánh giá dịch vụ</h3>
        <p class="muted" id="rvService"></p>
        <fieldset class="rate-field">
            <legend>Bạn chấm mấy sao?</legend>
            <div class="rate">
                <?php for ($i = 5; $i >= 1; $i--): ?>
                    <input type="radio" id="rate<?= $i ?>" name="rating" value="<?= $i ?>" required>
                    <label for="rate<?= $i ?>" title="<?= $i ?> sao"><span class="sr"><?= $i ?> sao</span>★</label>
                <?php endfor; ?>
            </div>
        </fieldset>
        <label class="field">
            <span>Nhận xét (không bắt buộc)</span>
            <textarea class="input" name="comment" rows="4" maxlength="1000" placeholder="Bé nhà bạn thấy thế nào sau buổi spa?"></textarea>
        </label>
        <div class="modal-actions">
            <button class="btn btn-ghost" type="button" data-close>Hủy bỏ</button>
            <button class="btn btn-primary" type="submit">Gửi đánh giá</button>
        </div>
    </form>
</dialog>
