<?php
/**
 * @var array $pets @var array $services @var array $slots @var int $pointValue
 * @var array $old @var array $errors @var ?string $formError @var string $minDate @var string $maxDate @var array $me
 */
$err     = fn(string $k): string => isset($errors[$k]) ? '<small class="field-error">' . e($errors[$k]) . '</small>' : '';
$balance = (int) $me['points'];
?>
<div class="wrap page">
    <div class="page-head">
        <div>
            <h1>Đặt lịch spa</h1>
            <p class="muted">Lịch gửi đi ở trạng thái "Chờ duyệt"; nhân viên sẽ xác nhận trong giờ làm việc (<?= e(shop('hours')) ?>).</p>
        </div>
    </div>

    <?php if (!$pets): ?>
        <div class="panel empty-state">
            <h2>Bạn cần thêm hồ sơ bé cưng trước</h2>
            <p class="muted">Hồ sơ giúp nhân viên biết bé là giống nào, nặng bao nhiêu để chuẩn bị cho đúng.</p>
            <a class="btn btn-primary" href="<?= e(url('pets/create', ['next' => 'book'])) ?>">Thêm bé cưng</a>
        </div>
    <?php else: ?>
        <form class="booking" id="bookingForm" method="post" action="<?= e(url('book')) ?>"
              data-point-value="<?= (int) $pointValue ?>" data-balance="<?= $balance ?>" data-lead="<?= (int) config('booking.min_lead_minutes', 60) ?>" novalidate>
            <?= csrf_field() ?>

            <div class="panel booking-form">
                <?php if ($formError): ?>
                    <div class="alert alert-error" role="alert"><span><?= e($formError) ?></span></div>
                <?php endif; ?>

                <fieldset class="field <?= isset($errors['pet_id']) ? 'has-error' : '' ?>">
                    <legend>Bé cưng</legend>
                    <div class="picks">
                        <?php foreach ($pets as $p): ?>
                            <label class="pick">
                                <input type="radio" name="pet_id" value="<?= (int) $p['id'] ?>" <?= (string) $old['pet_id'] === (string) $p['id'] ? 'checked' : '' ?>>
                                <span class="pick-box">
                                    <?= pet_avatar($p, 'pet-avatar sm') ?>
                                    <span><b><?= e($p['name']) ?></b><small class="muted"><?= e($p['species']) ?></small></span>
                                </span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                    <?= $err('pet_id') ?>
                    <a class="link small" href="<?= e(url('pets/create', ['next' => 'book'])) ?>">Thêm bé khác</a>
                </fieldset>

                <label class="field <?= isset($errors['service_id']) ? 'has-error' : '' ?>">
                    <span>Dịch vụ</span>
                    <select class="select" name="service_id" required>
                        <option value="" data-price="" data-duration="">Chọn dịch vụ</option>
                        <?php foreach ($services as $s): ?>
                            <option value="<?= (int) $s['id'] ?>" data-price="<?= (int) $s['price'] ?>" data-duration="<?= (int) $s['duration'] ?>"
                                <?= (string) $old['service_id'] === (string) $s['id'] ? 'selected' : '' ?>>
                                <?= e($s['name']) ?> (<?= e(money($s['price'])) ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <?= $err('service_id') ?>
                </label>

                <div class="row-2">
                    <label class="field <?= isset($errors['date']) ? 'has-error' : '' ?>">
                        <span>Ngày hẹn</span>
                        <input class="input" type="date" name="date" min="<?= e($minDate) ?>" max="<?= e($maxDate) ?>" value="<?= e($old['date']) ?>" required>
                        <?= $err('date') ?>
                    </label>
                    <label class="field <?= isset($errors['time']) ? 'has-error' : '' ?>">
                        <span>Giờ hẹn</span>
                        <select class="select" name="time" required>
                            <option value="">Chọn giờ</option>
                            <?php foreach ($slots as $t): ?>
                                <option value="<?= e($t) ?>" <?= $old['time'] === $t ? 'selected' : '' ?>><?= e($t) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <?= $err('time') ?>
                    </label>
                </div>

                <label class="field <?= isset($errors['note']) ? 'has-error' : '' ?>">
                    <span>Ghi chú cho nhân viên (không bắt buộc)</span>
                    <textarea class="input" name="note" rows="3" maxlength="500" placeholder="Ví dụ: bé hơi nhát, cần nhẹ tay khi sấy"><?= e($old['note']) ?></textarea>
                    <?= $err('note') ?>
                </label>

                <?php if ($balance > 0): ?>
                    <label class="field <?= isset($errors['points']) ? 'has-error' : '' ?>">
                        <span>Dùng điểm thưởng</span>
                        <input class="input" name="points" inputmode="numeric" autocomplete="off" value="<?= e($old['points']) ?>">
                        <small class="muted" id="pointsHelp">Bạn có <?= number_format($balance, 0, ',', '.') ?> điểm. 1 điểm giảm <?= e(money($pointValue)) ?>.</small>
                        <?= $err('points') ?>
                    </label>
                <?php else: ?>
                    <input type="hidden" name="points" value="0">
                    <p class="muted small">Bạn chưa có điểm thưởng. Hoàn thành lịch đầu tiên để bắt đầu tích điểm.</p>
                <?php endif; ?>

                <div class="form-actions">
                    <a class="btn btn-ghost" href="<?= e(url('services')) ?>">Xem thêm dịch vụ</a>
                    <button class="btn btn-primary btn-lg" type="submit">Đặt lịch</button>
                </div>
            </div>

            <aside class="panel summary-box" aria-live="polite">
                <h2>Tóm tắt</h2>
                <dl class="kv stack">
                    <div><dt>Dịch vụ</dt><dd id="sumService">Chưa chọn</dd></div>
                    <div><dt>Thời gian thực hiện</dt><dd id="sumDuration">–</dd></div>
                    <div><dt>Giá dịch vụ</dt><dd id="sumPrice">–</dd></div>
                    <div><dt>Giảm từ điểm thưởng</dt><dd id="sumDiscount">0 ₫</dd></div>
                    <div class="total"><dt>Cần thanh toán</dt><dd id="sumTotal">–</dd></div>
                </dl>
                <p class="muted small">Thanh toán trực tiếp tại tiệm. Lịch hoàn thành sẽ được cộng điểm thưởng.</p>
            </aside>
        </form>
    <?php endif; ?>
</div>
