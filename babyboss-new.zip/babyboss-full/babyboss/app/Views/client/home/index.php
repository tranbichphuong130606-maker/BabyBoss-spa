<?php
/**
 * @var array $featured @var array $options @var int $serviceCount
 * @var array $testimonials @var array $summary @var int $pointValue @var ?array $me
 */
$heroBgImg = 'https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?auto=format&fit=crop&w=1600&q=85';
$heroPetThumb = 'https://images.unsplash.com/photo-1548199973-03cce0bbc87b?auto=format&fit=crop&w=600&q=80';
?>
<section class="hero-banner" style="--hero-bg: url('<?= e($heroBgImg) ?>');">
    <div class="hero-overlay"></div>
    <div class="wrap hero-banner-inner">
        <div class="hero-banner-copy">
            <span class="hero-pill">🐾 BABYBOSS PET SPA</span>
            <h1>Chăm sóc cho những <span class="hl">bé cưng</span> đúng giờ hẹn</h1>
            <p class="hero-desc">Chọn dịch vụ, chọn ngày giờ và theo dõi lịch ngay trên website. Sau mỗi lần spa, bé tích điểm để giảm giá cho lần sau.</p>

            <div class="hero-banner-actions">
                <a class="btn btn-primary btn-lg" href="<?= e(url('services')) ?>">Đặt lịch / Xem <?= (int) $serviceCount ?> dịch vụ</a>
                <a class="btn btn-hero-ghost btn-lg" href="<?= e(tel_href(shop('hotline'))) ?>"><?= icon('phone', 18) ?> <?= e(shop('hotline')) ?></a>
            </div>

            <?php if ($summary['count'] > 0): ?>
                <p class="hero-rating">
                    <span class="stars" aria-hidden="true"><?= e(stars((int) round((float) $summary['avg']))) ?></span>
                    Trung bình <b><?= e(rating_text($summary['avg'])) ?>/5</b> từ <?= (int) $summary['count'] ?> đánh giá
                </p>
            <?php endif; ?>
        </div>

        <div class="hero-pet-card">
            <img src="<?= e($heroPetThumb) ?>" alt="Bé cưng đáng yêu tại BabyBoss Pet Spa">
            <div class="hero-pet-meta">
                <b>Spa dịu nhẹ · Đúng giờ</b>
                <span>Chó & mèo đều được chăm sóc tận tâm</span>
            </div>
        </div>
    </div>
</section>

<section class="quick-strip-wrap">
    <div class="wrap">
        <form class="quick quick-bar" method="get" action="<?= e(BASE_URL . '/index.php') ?>">
            <i class="bubble q1" aria-hidden="true"></i><i class="bubble q2" aria-hidden="true"></i><i class="bubble q3" aria-hidden="true"></i>
            <input type="hidden" name="route" value="book">

            <div class="quick-bar-head">
                <h2>Đặt lịch nhanh</h2>
                <p class="quick-note" id="quickNote">Chọn dịch vụ để xem giá và thời gian thực hiện.</p>
            </div>

            <div class="quick-bar-fields">
                <label class="field">
                    <span>Dịch vụ</span>
                    <select class="select" name="service" id="quickService">
                        <option value="" data-price="" data-duration="">Chọn dịch vụ</option>
                        <?php foreach ($options as $o): ?>
                            <option value="<?= (int) $o['id'] ?>" data-price="<?= (int) $o['price'] ?>" data-duration="<?= (int) $o['duration'] ?>"><?= e($o['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>

                <label class="field">
                    <span>Ngày hẹn</span>
                    <input class="input" type="date" name="date" min="<?= e(date('Y-m-d')) ?>">
                </label>

                <div class="quick-bar-submit">
                    <button class="btn btn-primary btn-lg" type="submit">Tiếp tục đặt lịch →</button>
                </div>
            </div>
        </form>
    </div>
</section>

<?php if ($featured): ?>
<section class="section">
    <div class="wrap">
        <div class="section-head">
            <div>
                <span class="eyebrow">Dịch vụ nổi bật</span>
                <h2>Dịch vụ được đặt nhiều nhất</h2>
                <p class="muted">Giá và thời gian thực hiện được ghi rõ ở từng dịch vụ.</p>
            </div>
            <a class="btn btn-light" href="<?= e(url('services')) ?>">Xem tất cả dịch vụ →</a>
        </div>
        <div class="cards">
            <?php foreach ($featured as $s): partial('service_card', ['s' => $s]); endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<section class="section how">
    <div class="wrap how-grid">
        <div>
            <span class="eyebrow">Quy trình 3 bước</span>
            <h2>Đặt lịch ở BabyBoss diễn ra thế nào</h2>
            <p class="muted">Bạn cần một tài khoản để lưu hồ sơ bé cưng và theo dõi lịch hẹn của mình.</p>
            <?php if (!$me): ?><a class="btn btn-primary btn-lg" style="margin-top:14px" href="<?= e(url('register')) ?>">Tạo tài khoản</a><?php endif; ?>
        </div>
        <ol class="steps">
            <li><b>Thêm hồ sơ cho bé.</b> Tên, giống loài, cân nặng và ảnh đại diện giúp nhân viên chuẩn bị đúng cho từng bé.</li>
            <li><b>Chọn dịch vụ và giờ hẹn.</b> Lịch được gửi đi ở trạng thái "Chờ duyệt", nhân viên sẽ xác nhận trong giờ làm việc.</li>
            <li><b>Tích điểm sau mỗi lần spa.</b> Lịch hoàn thành được cộng điểm theo hạng thành viên. <?= e('1 điểm giảm ' . money($pointValue)) ?> cho lần đặt sau.</li>
        </ol>
    </div>
</section>

<?php if ($testimonials): ?>
<section class="section">
    <div class="wrap">
        <div class="section-head">
            <div>
                <span class="eyebrow">Đánh giá từ khách hàng</span>
                <h2>Khách nói gì về BabyBoss</h2>
            </div>
        </div>
        <div class="quotes">
            <?php foreach ($testimonials as $t): ?>
                <figure class="quote">
                    <span class="stars" aria-label="<?= (int) $t['rating'] ?> trên 5 sao"><?= e(stars((int) $t['rating'])) ?></span>
                    <blockquote><?= e($t['comment']) ?></blockquote>
                    <figcaption><b><?= e(short_name($t['customer_name'])) ?></b> đã dùng dịch vụ <?= e($t['service_name']) ?></figcaption>
                </figure>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<section class="wrap">
    <div class="cta-band">
        <div>
            <h2>Cần tư vấn trước khi đặt lịch?</h2>
            <p>Gọi hotline hoặc nhắn tin, nhân viên sẽ trả lời trong giờ làm việc (<?= e(shop('hours')) ?>).</p>
        </div>
        <div class="cta-actions">
            <a class="btn btn-primary btn-lg" href="<?= e(tel_href(shop('hotline'))) ?>"><?= icon('phone', 18) ?> <?= e(shop('hotline')) ?></a>
            <a class="btn btn-light btn-lg" href="<?= e(url('contact')) ?>">Nhắn tin cho BabyBoss</a>
        </div>
    </div>
</section>