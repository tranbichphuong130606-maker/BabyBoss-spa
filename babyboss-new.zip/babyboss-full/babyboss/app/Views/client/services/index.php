<?php /** @var string $q @var array $services @var \App\Core\Paginator $pager */ ?>
<div class="wrap page">
    <div class="page-head">
        <div>
            <h1>Dịch vụ spa</h1>
            <p class="muted">Tìm dịch vụ phù hợp với bé. Giá và thời gian thực hiện được ghi rõ ở từng dịch vụ.</p>
        </div>
    </div>

    <form class="finder" method="get" action="<?= e(BASE_URL . '/index.php') ?>">
        <input type="hidden" name="route" value="services">
        <label class="search"><?= icon('search') ?>
            <input type="search" name="q" value="<?= e($q) ?>" placeholder="Tìm dịch vụ, ví dụ: tắm, cắt tỉa, khách sạn">
        </label>
        <button class="btn btn-primary" type="submit">Tìm dịch vụ</button>
        <?php if ($q !== ''): ?><a class="btn btn-ghost" href="<?= e(url('services')) ?>">Bỏ tìm kiếm</a><?php endif; ?>
    </form>

    <?php if ($q !== ''): ?>
        <p class="muted result-line">Có <?= (int) $pager->total ?> dịch vụ khớp với "<?= e($q) ?>".</p>
    <?php endif; ?>

    <?php if ($services): ?>
        <div class="cards">
            <?php foreach ($services as $s): partial('service_card', ['s' => $s]); endforeach; ?>
        </div>
        <?php partial('pagination', ['pager' => $pager, 'route' => 'services', 'query' => ['q' => $q]]); ?>
    <?php else: ?>
        <div class="panel empty-state">
            <h2><?= $q !== '' ? 'Không có dịch vụ nào khớp với từ khóa' : 'Chưa có dịch vụ nào' ?></h2>
            <p class="muted"><?= $q !== '' ? 'Thử từ khóa ngắn hơn như "tắm" hoặc "cắt", hoặc xem toàn bộ danh sách.' : 'Vui lòng quay lại sau.' ?></p>
            <?php if ($q !== ''): ?><a class="btn btn-primary" href="<?= e(url('services')) ?>">Xem tất cả dịch vụ</a><?php endif; ?>
        </div>
    <?php endif; ?>
</div>
