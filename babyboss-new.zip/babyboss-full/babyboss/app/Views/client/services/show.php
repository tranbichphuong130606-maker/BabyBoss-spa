<?php
/** @var array $service @var array $summary @var array $reviews @var array $others */

$svcId = (int) ($service['id'] ?? 0);
$nameLower = mb_strtolower((string) ($service['name'] ?? ''), 'UTF-8');

$cuteGallery = [
    'https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?auto=format&fit=crop&w=900&q=85', // 0: Cún áo vàng xinh xắn
    'https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?auto=format&fit=crop&w=900&q=85', // 1: Mèo mắt tròn đáng yêu
    'https://images.unsplash.com/photo-1548199973-03cce0bbc87b?auto=format&fit=crop&w=900&q=85', // 2: Hai bé cún chạy vui
    'https://images.unsplash.com/photo-1573865526739-10659fec78a5?auto=format&fit=crop&w=900&q=85', // 3: Mèo nằm nghỉ thư giãn
    'https://images.unsplash.com/photo-1537151625747-768eb6cf92b2?auto=format&fit=crop&w=900&q=85', // 4: Cún mặt ngây thơ
    'https://images.unsplash.com/photo-1516734212186-a967f81ad0d7?auto=format&fit=crop&w=900&q=85', // 5: Spa chải lông cho bé
    'https://images.unsplash.com/photo-1592194996308-7b43878e84a6?auto=format&fit=crop&w=900&q=85', // 6: Mèo trắng xinh
    'https://images.unsplash.com/photo-1601758228041-f3b2795255f1?auto=format&fit=crop&w=900&q=85', // 7: Cún cưng thân thiện
];

$imgUrl = '';
$rawImg = trim((string) ($service['image'] ?? $service['thumbnail'] ?? ''));

if ($rawImg !== '') {
    if (preg_match('#^https?://#i', $rawImg)) {
        $imgUrl = $rawImg;
    } else {
        $cleanPath = ltrim($rawImg, '/');
        if (strpos($cleanPath, 'uploads/') !== 0) {
            $cleanPath = 'uploads/services/' . $cleanPath;
        }
        $imgUrl = BASE_URL . '/' . $cleanPath;
    }
}

if ($imgUrl === '') {
    if (strpos($nameLower, 'tai') !== false || strpos($nameLower, 'móng') !== false || strpos($nameLower, 'vệ sinh') !== false) {
        $imgUrl = $cuteGallery[4];
    } elseif (strpos($nameLower, 'tỉa') !== false || strpos($nameLower, 'tạo kiểu') !== false) {
        $imgUrl = $cuteGallery[0];
    } elseif (strpos($nameLower, 'tắm sấy') !== false || strpos($nameLower, 'tắm') !== false) {
        $imgUrl = $cuteGallery[5];
    } elseif (strpos($nameLower, 'răng') !== false || strpos($nameLower, 'miệng') !== false) {
        $imgUrl = $cuteGallery[6];
    } elseif (strpos($nameLower, 'khách sạn') !== false || strpos($nameLower, 'nghỉ dưỡng') !== false) {
        $imgUrl = $cuteGallery[3];
    } elseif (strpos($nameLower, 'massage') !== false || strpos($nameLower, 'dưỡng lông') !== false) {
        $imgUrl = $cuteGallery[1];
    } else {
        $imgUrl = $cuteGallery[$svcId > 0 ? ($svcId - 1) % count($cuteGallery) : 2];
    }
}
?>
<div class="wrap page">
    <nav class="crumbs" aria-label="Đường dẫn">
        <a href="<?= e(url('services')) ?>">Dịch vụ</a> <span aria-hidden="true">/</span> <span><?= e($service['name']) ?></span>
    </nav>

    <div class="detail">
        <div class="detail-art">
            <img
                src="<?= e($imgUrl) ?>"
                alt="<?= e($service['name'] ?? 'Dịch vụ BabyBoss Pet Spa') ?>"
                style="width:100%;height:100%;object-fit:cover;border-radius:16px;"
                onerror="this.onerror=null;this.src='<?= e($cuteGallery[$svcId % count($cuteGallery)]) ?>';"
            >
        </div>
        <div class="detail-info">
            <h1><?= e($service['name']) ?></h1>
            <p class="rating-line">
                <?php if ($summary['count'] > 0): ?>
                    <span class="stars" aria-hidden="true"><?= e(stars((int) round((float) $summary['avg']))) ?></span>
                    <b><?= e(rating_text($summary['avg'])) ?> trên 5</b> từ <?= (int) $summary['count'] ?> đánh giá
                <?php else: ?>
                    <span class="muted">Chưa có đánh giá. Khách sẽ đánh giá sau khi dùng dịch vụ.</span>
                <?php endif; ?>
            </p>
            <dl class="facts-row">
                <div><dt>Giá</dt><dd class="price"><?= e(money($service['price'])) ?></dd></div>
                <div><dt>Thời gian thực hiện</dt><dd><?= e(duration_text((int) $service['duration'])) ?></dd></div>
            </dl>
            <div class="prose"><p><?= nl2br(e($service['description'] ?? '')) ?></p></div>
            <a class="btn btn-primary btn-lg" href="<?= e(url('book', ['service' => $service['id']])) ?>">Đặt lịch dịch vụ này</a>
        </div>
    </div>

    <section class="reviews">
        <h2>Đánh giá của khách</h2>
        <?php if ($reviews): ?>
            <ul class="review-list">
                <?php foreach ($reviews as $r): ?>
                    <li>
                        <div class="review-top">
                            <span class="stars" aria-label="<?= (int) $r['rating'] ?> trên 5 sao"><?= e(stars((int) $r['rating'])) ?></span>
                            <b><?= e(short_name($r['customer_name'])) ?></b>
                            <span class="muted small"><?= e(fmt_date($r['created_at'], 'd/m/Y')) ?></span>
                        </div>
                        <?php if (trim((string) $r['comment']) !== ''): ?><p><?= e($r['comment']) ?></p><?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php else: ?>
            <p class="muted">Dịch vụ này chưa có đánh giá nào.</p>
        <?php endif; ?>
    </section>

    <?php if ($others): ?>
    <section class="section tight">
        <div class="section-head"><h2>Dịch vụ khác</h2><a class="link" href="<?= e(url('services')) ?>">Xem tất cả</a></div>
        <div class="cards">
            <?php foreach ($others as $s): partial('service_card', ['s' => $s]); endforeach; ?>
        </div>
    </section>
    <?php endif; ?>
</div>
