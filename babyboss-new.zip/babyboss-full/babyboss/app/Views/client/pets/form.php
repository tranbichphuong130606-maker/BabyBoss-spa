<?php
/** @var ?array $pet @var array $old @var array $errors @var string $next */
$editing = $pet !== null;
$action  = $editing ? url('pets/' . $pet['id'] . '/update') : url('pets/store');
$err     = fn(string $k): string => isset($errors[$k]) ? '<small class="field-error">' . e($errors[$k]) . '</small>' : '';
$maxMb   = round((int) config('upload.max_size', 2097152) / 1048576, 1);
$avatar  = $editing ? ($pet['avatar'] ?? null) : null;
?>
<div class="wrap page narrow">
    <a class="back-link" href="<?= e(url('pets')) ?>"><?= icon('back', 16) ?> Thú cưng của tôi</a>
    <h1><?= $editing ? 'Sửa hồ sơ của bé' : 'Thêm bé cưng' ?></h1>

    <form class="panel pet-form" method="post" action="<?= e($action) ?>" enctype="multipart/form-data" novalidate>
        <?= csrf_field() ?>
        <?php if ($next !== ''): ?><input type="hidden" name="next" value="<?= e($next) ?>"><?php endif; ?>

        <div class="avatar-field">
            <div class="avatar-preview">
                <img id="previewImg" alt="Ảnh đại diện" src="<?= $avatar ? e(upload_url($avatar, 'pets')) : 'data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==' ?>" <?= $avatar ? '' : 'hidden' ?>>
                <span class="ph" id="previewPh" <?= $avatar ? 'hidden' : '' ?>><?= paw_icon(40) ?></span>
            </div>
            <div>
                <label class="btn btn-outline file-btn">
                    <?= icon('upload', 16) ?> <?= $avatar ? 'Đổi ảnh' : 'Chọn ảnh đại diện' ?>
                    <input type="file" name="avatar" accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp" data-preview="previewImg">
                </label>
                <small class="muted">JPG, PNG hoặc WebP, tối đa <?= e($maxMb) ?> MB.</small>
                <?= $err('avatar') ?>
            </div>
        </div>

        <label class="field <?= isset($errors['name']) ? 'has-error' : '' ?>">
            <span>Tên bé</span>
            <input class="input" name="name" value="<?= e($old['name']) ?>" maxlength="80" placeholder="Ví dụ: Mochi" required>
            <?= $err('name') ?>
        </label>
        <label class="field <?= isset($errors['species']) ? 'has-error' : '' ?>">
            <span>Giống loài</span>
            <input class="input" name="species" value="<?= e($old['species']) ?>" maxlength="80" list="speciesList" placeholder="Ví dụ: Chó Poodle" required>
            <datalist id="speciesList">
                <?php foreach (['Chó Poodle', 'Chó Corgi', 'Chó Golden Retriever', 'Chó Pomeranian', 'Chó Chihuahua', 'Chó Husky', 'Chó Shiba Inu', 'Chó Alaska', 'Mèo Anh lông ngắn', 'Mèo Ba Tư', 'Mèo ta', 'Mèo Munchkin'] as $s): ?>
                    <option value="<?= e($s) ?>"></option>
                <?php endforeach; ?>
            </datalist>
            <?= $err('species') ?>
        </label>
        <div class="row-2">
            <label class="field <?= isset($errors['weight']) ? 'has-error' : '' ?>">
                <span>Cân nặng (kg)</span>
                <input class="input" name="weight" value="<?= e($old['weight']) ?>" inputmode="decimal" placeholder="4,2">
                <?= $err('weight') ?>
            </label>
            <label class="field <?= isset($errors['age']) ? 'has-error' : '' ?>">
                <span>Tuổi (năm)</span>
                <input class="input" name="age" value="<?= e($old['age']) ?>" inputmode="numeric" placeholder="3">
                <?= $err('age') ?>
            </label>
        </div>

        <div class="form-actions">
            <a class="btn btn-ghost" href="<?= e(url('pets')) ?>">Hủy bỏ</a>
            <button class="btn btn-primary" type="submit"><?= $editing ? 'Lưu thay đổi' : 'Thêm bé cưng' ?></button>
        </div>
    </form>
</div>
