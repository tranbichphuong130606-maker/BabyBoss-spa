<?php /** @var array $pets */ ?>
<div class="wrap page">
    <div class="page-head">
        <div>
            <h1>Thú cưng của tôi</h1>
            <p class="muted">Hồ sơ của từng bé giúp nhân viên chuẩn bị đúng cho mỗi lần đặt lịch.</p>
        </div>
        <?php if ($pets): ?><a class="btn btn-primary" href="<?= e(url('pets/create')) ?>"><?= icon('plus', 16) ?> Thêm bé cưng</a><?php endif; ?>
    </div>

    <?php if (!$pets): ?>
        <div class="panel empty-state">
            <h2>Bạn chưa có hồ sơ bé cưng nào</h2>
            <p class="muted">Thêm bé đầu tiên để bắt đầu đặt lịch spa.</p>
            <a class="btn btn-primary" href="<?= e(url('pets/create')) ?>">Thêm bé cưng</a>
        </div>
    <?php else: ?>
        <div class="pet-grid">
            <?php foreach ($pets as $p): ?>
                <article class="pet-card">
                    <div class="pet-top">
                        <?= pet_avatar($p) ?>
                        <div>
                            <h2><?= e($p['name']) ?></h2>
                            <p class="muted"><?= e($p['species']) ?></p>
                        </div>
                    </div>
                    <dl class="kv row">
                        <div><dt>Cân nặng</dt><dd><?= $p['weight'] !== null ? e(fmt_weight($p['weight'])) . ' kg' : '<span class="muted">Chưa nhập</span>' ?></dd></div>
                        <div><dt>Tuổi</dt><dd><?= $p['age'] !== null ? (int) $p['age'] . ' tuổi' : '<span class="muted">Chưa nhập</span>' ?></dd></div>
                        <div><dt>Lịch đã đặt</dt><dd><?= (int) $p['appointment_count'] ?></dd></div>
                    </dl>
                    <div class="pet-actions">
                        <a class="btn btn-primary btn-sm" href="<?= e(url('book', ['pet' => $p['id']])) ?>">Đặt lịch cho bé</a>
                        <a class="btn btn-outline btn-sm" href="<?= e(url('pets/' . $p['id'] . '/edit')) ?>"><?= icon('edit', 15) ?> Sửa</a>
                        <form method="post" action="<?= e(url('pets/' . $p['id'] . '/delete')) ?>"
                              data-confirm="<?= e('Xóa hồ sơ của bé ' . $p['name'] . '? Lịch sử lịch hẹn cũ vẫn được giữ lại.') ?>" data-confirm-label="Xóa hồ sơ">
                            <?= csrf_field() ?>
                            <button class="btn btn-danger-ghost btn-sm" type="submit" aria-label="Xóa hồ sơ <?= e($p['name']) ?>" title="Xóa hồ sơ"><?= icon('trash', 15) ?></button>
                        </form>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>
