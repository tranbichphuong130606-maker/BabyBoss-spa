<?php /** @var string $email @var ?string $error */ ?>
<div class="wrap auth-wrap">
    <div class="auth-side">
        <h1>Đăng nhập</h1>
        <p class="lead">Xem lịch hẹn, hồ sơ bé cưng và điểm thưởng của bạn ở một nơi.</p>
    </div>

    <form class="panel auth-card" method="post" action="<?= e(url('login')) ?>">
        <?php if ($error): ?>
            <div class="alert alert-error" role="alert"><span><?= e($error) ?></span></div>
        <?php endif; ?>
        <?= csrf_field() ?>
        <label class="field">
            <span>Email</span>
            <input class="input" type="email" name="email" value="<?= e($email) ?>" autocomplete="username" required autofocus>
        </label>
        <label class="field">
            <span>Mật khẩu</span>
            <span class="pw">
                <input class="input" type="password" name="password" autocomplete="current-password" required>
                <button type="button" class="pw-toggle" data-toggle-pw aria-label="Hiện mật khẩu"><?= icon('eye') ?></button>
            </span>
        </label>
        <button class="btn btn-primary btn-block btn-lg" type="submit">Đăng nhập</button>
        <p class="switch">Chưa có tài khoản? <a class="link" href="<?= e(url('register')) ?>">Đăng ký</a></p>
        <?php if (config('app.debug')): ?>
            <p class="hint">Tài khoản demo: <b>minhanh@example.com</b> / <b>Khach@123</b></p>
        <?php endif; ?>
    </form>
</div>
