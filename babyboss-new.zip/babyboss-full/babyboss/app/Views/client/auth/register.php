<?php /** @var array $old @var array $errors */
$err = fn(string $k): string => isset($errors[$k]) ? '<small class="field-error">' . e($errors[$k]) . '</small>' : '';
?>
<div class="wrap auth-wrap">
    <div class="auth-side">
        <h1>Tạo tài khoản</h1>
        <p class="lead">Lưu hồ sơ bé cưng, đặt lịch chỉ với vài lần bấm và tích điểm sau mỗi lần spa.</p>
    </div>

    <form class="panel auth-card" method="post" action="<?= e(url('register')) ?>" novalidate>
        <?= csrf_field() ?>
        <label class="field <?= isset($errors['full_name']) ? 'has-error' : '' ?>">
            <span>Họ và tên</span>
            <input class="input" name="full_name" value="<?= e($old['full_name']) ?>" autocomplete="name" maxlength="100" required autofocus>
            <?= $err('full_name') ?>
        </label>
        <label class="field <?= isset($errors['email']) ? 'has-error' : '' ?>">
            <span>Email</span>
            <input class="input" type="email" name="email" value="<?= e($old['email']) ?>" autocomplete="email" maxlength="150" required>
            <?= $err('email') ?>
        </label>
        <label class="field <?= isset($errors['phone']) ? 'has-error' : '' ?>">
            <span>Số điện thoại</span>
            <input class="input" type="tel" name="phone" value="<?= e($old['phone']) ?>" autocomplete="tel" inputmode="tel" placeholder="0901234567" required>
            <?= $err('phone') ?>
        </label>
        <label class="field <?= isset($errors['password']) ? 'has-error' : '' ?>">
            <span>Mật khẩu</span>
            <span class="pw">
                <input class="input" type="password" name="password" autocomplete="new-password" required>
                <button type="button" class="pw-toggle" data-toggle-pw aria-label="Hiện mật khẩu"><?= icon('eye') ?></button>
            </span>
            <small class="muted">Từ 8 ký tự, gồm cả chữ và số.</small>
            <?= $err('password') ?>
        </label>
        <label class="field <?= isset($errors['password_confirm']) ? 'has-error' : '' ?>">
            <span>Nhập lại mật khẩu</span>
            <input class="input" type="password" name="password_confirm" autocomplete="new-password" required>
            <?= $err('password_confirm') ?>
        </label>
        <button class="btn btn-primary btn-block btn-lg" type="submit">Tạo tài khoản</button>
        <p class="switch">Đã có tài khoản? <a class="link" href="<?= e(url('login')) ?>">Đăng nhập</a></p>
    </form>
</div>
