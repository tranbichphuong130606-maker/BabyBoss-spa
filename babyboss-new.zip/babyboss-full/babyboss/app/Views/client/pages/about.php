<?php
/**
 * @var int $pointValue
 */
$aboutHeroImg = 'https://images.unsplash.com/photo-1548199973-03cce0bbc87b?auto=format&fit=crop&w=1000&q=85';
?>
<section class="page about-page">
    <div class="wrap">
        <div class="about-hero panel">
            <div class="about-hero-text">
                <span class="eyebrow">Về BabyBoss Pet Spa</span>
                <h1>Không gian spa & nghỉ dưỡng chuẩn 5 sao cho bé cưng</h1>
                <p class="lead">BabyBoss ra đời với mong muốn mang đến cho chó mèo một nơi chăm sóc nhẹ nhàng, sạch sẽ và không áp lực. Tại đây, mỗi bé đều có khung giờ hẹn riêng biệt để được kỹ thuật viên theo dõi sát sao, nâng niu từng bước mà không phải chờ đợi lâu trong lồng chật chội.</p>
                <div class="about-actions">
                    <a class="btn btn-primary btn-lg" href="<?= e(url('services')) ?>">Khám phá dịch vụ</a>
                    <a class="btn btn-light btn-lg" href="<?= e(url('book')) ?>">Đặt lịch ngay</a>
                </div>
            </div>
            <div class="about-hero-media">
                <img src="<?= e($aboutHeroImg) ?>" alt="Thú cưng vui vẻ tại BabyBoss Pet Spa">
            </div>
        </div>

        <div class="about-grid">
            <div class="prose about-sections">
                <article class="about-block panel">
                    <span class="about-step-tag">01 · DỊCH VỤ TOÀN DIỆN</span>
                    <h2>Chúng tôi làm gì cho bé cưng của bạn</h2>
                    <p>BabyBoss cung cấp hệ thống dịch vụ chăm sóc chuyên sâu được thiết kế phù hợp với từng giống loài, độ tuổi và tình trạng da lông của thú cưng:</p>
                    <p>• <b>Tắm sấy & Spa dưỡng lông:</b> Sử dụng sữa tắm thảo mộc dịu nhẹ, kết hợp massage thư giãn, ủ dưỡng mềm mượt và sấy tạo phồng chuẩn salon.<br>
                    • <b>Cắt tỉa tạo kiểu & Vệ sinh cơ bản:</b> Cắt tỉa theo dáng chuẩn của từng giống hoặc theo yêu cầu riêng của chủ nuôi, kèm vệ sinh tai, mài – cắt móng và đánh răng khử mùi.<br>
                    • <b>Khách sạn thú cưng:</b> Phòng nghỉ riêng thoáng mát có điều hòa, chế độ ăn uống đúng giờ, khu vui chơi vận động mỗi ngày và gửi ảnh/video cập nhật thường xuyên cho chủ.</p>
                    <p>Toàn bộ bảng giá và thời gian thực hiện dự kiến đều được niêm yết công khai trên website để bạn dễ dàng cân nhắc trước khi đặt hẹn.</p>
                </article>

                <article class="about-block panel">
                    <span class="about-step-tag">02 · QUY TRÌNH TẬN TÂM</span>
                    <h2>Trải nghiệm một lần đến spa tại BabyBoss</h2>
                    <p>Ngay sau khi bạn gửi yêu cầu đặt lịch trên website, nhân viên lễ tân sẽ kiểm tra khung giờ và xác nhận nhanh chóng trong giờ làm việc. Khi đưa bé đến tiệm đúng hẹn, kỹ thuật viên sẽ kiểm tra sơ bộ tình trạng da, lông, tai và tâm lý của bé trước khi bắt đầu.</p>
                    <p>Trong suốt quá trình chăm sóc, dụng cụ luôn được khử khuẩn riêng cho từng bé, nhiệt độ nước và máy sấy được điều chỉnh êm ái để các bé nhát nước hoặc lần đầu đi spa cũng cảm thấy an tâm.</p>
                    <p>Bạn có thể theo dõi trạng thái lịch hẹn (Chờ duyệt, Đã xác nhận, Đang thực hiện, Hoàn thành) trực tiếp trong tài khoản cá nhân mà không cần gọi điện hỏi nhiều lần.</p>
                </article>

                <article class="about-block panel">
                    <span class="about-step-tag">03 · CAM KẾT AN TOÀN</span>
                    <h2>Tiêu chuẩn vệ sinh & đội ngũ yêu thú cưng</h2>
                    <p>Tại BabyBoss, sự an toàn và thoải mái của thú cưng luôn được đặt lên hàng đầu. Khu vực tắm, bàn tỉa lông và phòng lưu trú được vệ sinh, khử trùng định kỳ mỗi ngày bằng dung dịch an toàn cho vật nuôi.</p>
                    <p>Đội ngũ nhân viên đều được đào tạo bài bản về kỹ năng xử lý tình huống nhẹ nhàng, tuyệt đối không quát mắng hay ép buộc khiến bé hoảng sợ, giúp mỗi buổi spa trở thành một trải nghiệm vui vẻ.</p>
                </article>

                <article class="about-block panel">
                    <span class="about-step-tag">04 · KHÁCH HÀNG THÂN THIẾT</span>
                    <h2>Điểm thưởng và hạng thành viên</h2>
                    <p>Mỗi lịch hẹn hoàn thành thành công đều được hệ thống tự động tích lũy điểm thưởng tương ứng với hạng thành viên của bạn (<b>Bạc</b>, <b>Vàng</b>, <b>Kim Cương</b>).</p>
                    <p>Số điểm tích lũy có thể quy đổi để giảm trực tiếp vào hóa đơn ở những lần đặt lịch tiếp theo<?= isset($pointValue) ? ' (hiện tại <b>1 điểm giảm ' . e(money((int) $pointValue)) . '</b>)' : '' ?>, giúp bạn tiết kiệm chi phí chăm sóc bé định kỳ hàng tháng.</p>
                </article>
            </div>

            <aside class="panel about-info-card">
                <span class="eyebrow">Liên hệ trực tiếp</span>
                <h2>Thông tin tiệm</h2>
                <dl class="kv stack">
                    <div>
                        <dt>Địa chỉ</dt>
                        <dd><?= e(shop('address')) ?></dd>
                    </div>
                    <div>
                        <dt>Giờ làm việc</dt>
                        <dd><?= e(shop('hours')) ?></dd>
                    </div>
                    <div>
                        <dt>Hotline</dt>
                        <dd><a href="<?= e(tel_href(shop('hotline'))) ?>"><?= e(shop('hotline')) ?></a></dd>
                    </div>
                    <div>
                        <dt>Email</dt>
                        <dd><?= e(shop('email')) ?></dd>
                    </div>
                </dl>
                <div class="about-side-cta">
                    <a class="btn btn-primary btn-block" href="<?= e(url('contact')) ?>">Nhắn tin tư vấn</a>
                </div>
            </aside>
        </div>
    </div>
</section>