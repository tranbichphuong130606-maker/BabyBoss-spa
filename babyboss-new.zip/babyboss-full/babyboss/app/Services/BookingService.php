<?php
namespace App\Services;

use App\Core\Database;
use App\Models\{Appointment, Pet, Service, User};
use PDO;

/**
 * Đặt lịch spa: kiểm tra dữ liệu, giữ chỗ trong MỘT transaction, trừ điểm thưởng khách dùng để giảm giá.
 * Lịch mới luôn ở trạng thái "Chờ duyệt" (pending) để admin xác nhận.
 */
final class BookingService
{
    private Appointment $appointments;
    private Pet $pets;
    private Service $services;
    private User $users;
    private LoyaltyService $loyalty;
    private PDO $db;

    public function __construct()
    {
        $this->appointments = new Appointment();
        $this->pets         = new Pet();
        $this->services     = new Service();
        $this->users        = new User();
        $this->loyalty      = new LoyaltyService();
        $this->db           = Database::connection();
    }

    /** Các khung giờ trong ngày theo config('booking'), ví dụ ['08:00', '08:30', ...]. */
    public static function slots(): array
    {
        $open  = self::minutes((string) config('booking.open', '08:00'));
        $close = self::minutes((string) config('booking.close', '19:30'));
        $step  = max(5, (int) config('booking.step', 30));
        $slots = [];
        for ($m = $open; $m <= $close; $m += $step) {
            $slots[] = sprintf('%02d:%02d', intdiv($m, 60), $m % 60);
        }
        return $slots;
    }

    private static function minutes(string $hhmm): int
    {
        [$h, $m] = array_map('intval', explode(':', $hhmm) + [0, 0]);
        return $h * 60 + $m;
    }

    /**
     * @param array $in pet_id, service_id, date (Y-m-d), time (H:i), note, points (đều là chuỗi từ form)
     * @return array{ok: bool, message: string, errors: array, id?: int}
     */
    public function book(int $userId, array $in): array
    {
        $errors = [];

        $pet = $this->pets->findForUser((int) $in['pet_id'], $userId);   // chỉ được chọn bé của chính mình
        if ($pet === null) {
            $errors['pet_id'] = 'Hãy chọn một bé cưng trong hồ sơ của bạn.';
        }

        $service = $this->services->find((int) $in['service_id']);
        if ($service === null || !(int) $service['is_active']) {
            $errors['service_id'] = 'Hãy chọn một dịch vụ đang nhận đặt lịch.';
            $service = null;
        }

        $when     = null;
        $stamp    = $in['date'] . ' ' . $in['time'];
        $dt       = \DateTime::createFromFormat('Y-m-d H:i', $stamp);
        if (!$dt || $dt->format('Y-m-d H:i') !== $stamp) {
            $errors['date'] = 'Hãy chọn ngày và giờ hẹn hợp lệ.';
        } elseif (!in_array($in['time'], self::slots(), true)) {
            $errors['time'] = 'Hãy chọn một khung giờ trong danh sách.';
        } else {
            $lead = (int) config('booking.min_lead_minutes', 60);
            $max  = (int) config('booking.max_days_ahead', 60);
            if ($dt->getTimestamp() < time() + $lead * 60) {
                $errors['date'] = 'Giờ hẹn cần cách thời điểm hiện tại ít nhất ' . $lead . ' phút.';
            } elseif ($dt->getTimestamp() > strtotime('+' . $max . ' days')) {
                $errors['date'] = 'Chỉ nhận đặt lịch trước tối đa ' . $max . ' ngày.';
            } else {
                $when = $dt->format('Y-m-d H:i:00');
            }
        }

        $pointsRaw = $in['points'] === '' ? '0' : $in['points'];
        if (!ctype_digit($pointsRaw) || strlen($pointsRaw) > 7) {
            $errors['points'] = 'Số điểm sử dụng phải là số nguyên không âm.';
        }
        if (mb_strlen($in['note']) > 500) {
            $errors['note'] = 'Ghi chú tối đa 500 ký tự.';
        }
        if ($errors) {
            return ['ok' => false, 'message' => 'Vui lòng kiểm tra lại các mục được đánh dấu.', 'errors' => $errors];
        }

        $points     = (int) $pointsRaw;
        $price      = (int) $service['price'];
        $pointValue = $this->loyalty->pointValue();

        $this->db->beginTransaction();
        try {
            $user = $this->users->lockForUpdate($userId);          // khóa dòng để kiểm tra số dư điểm chính xác
            if ($user === null) {
                $this->db->rollBack();
                return $this->fail(['points' => 'Không tìm thấy tài khoản.']);
            }
            if ($points > (int) $user['points']) {
                $this->db->rollBack();
                return $this->fail(['points' => 'Bạn chỉ có ' . number_format((int) $user['points'], 0, ',', '.') . ' điểm.']);
            }
            if ($points * $pointValue > $price) {
                $this->db->rollBack();
                return $this->fail(['points' => 'Số điểm vượt quá giá trị dịch vụ, tối đa ' . intdiv($price, $pointValue) . ' điểm cho dịch vụ này.']);
            }
            if ($this->appointments->petBusyAt((int) $pet['id'], $when)) {
                $this->db->rollBack();
                return $this->fail(['date' => 'Bé ' . $pet['name'] . ' đã có lịch vào đúng giờ này. Hãy chọn giờ khác.']);
            }

            $discount = $points * $pointValue;
            $id = $this->appointments->create([
                'user_id' => $userId, 'pet_id' => (int) $pet['id'], 'service_id' => (int) $service['id'],
                'appointment_date' => $when, 'note' => $in['note'],
                'price' => $price, 'points_used' => $points, 'discount' => $discount, 'total_amount' => $price - $discount,
            ]);
            if ($points > 0) {
                $this->loyalty->redeemForAppointment($user, $points, $id, $discount);
            }
            $this->db->commit();
        } catch (\Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            throw $e;
        }

        return [
            'ok'      => true,
            'id'      => $id,
            'errors'  => [],
            'message' => sprintf('Đã gửi lịch %s. BabyBoss sẽ xác nhận với bạn trong giờ làm việc.', appt_code($id)),
        ];
    }

    private function fail(array $errors): array
    {
        return ['ok' => false, 'message' => 'Vui lòng kiểm tra lại các mục được đánh dấu.', 'errors' => $errors];
    }
}
