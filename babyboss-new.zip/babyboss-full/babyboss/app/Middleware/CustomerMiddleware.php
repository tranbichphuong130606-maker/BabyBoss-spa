<?php
namespace App\Middleware;

use App\Core\{Auth, Request, Session};

/**
 * Bảo vệ các trang chỉ dành cho khách hàng đã đăng nhập (thú cưng, đặt lịch, điểm thưởng...).
 *  - Khách vãng lai  -> nhớ trang đang muốn vào rồi chuyển tới đăng nhập (đăng nhập xong quay lại đúng trang)
 *  - Tài khoản bị khóa -> đăng xuất
 *  - Tài khoản admin   -> chuyển sang khu vực quản trị
 */
final class CustomerMiddleware
{
    public function handle(Request $request): void
    {
        $user = Auth::user();

        if ($user === null) {
            if ($request->method() === 'GET') {
                Session::put('intended', ['route' => $request->path('home'), 'query' => $request->queryParams()]);
            }
            Session::flash('warning', 'Vui lòng đăng nhập để tiếp tục.');
            $this->go(url('login'));
        }
        if ($user['status'] !== 'active') {
            Auth::logout();
            Session::flash('error', 'Tài khoản của bạn đã bị khóa. Vui lòng gọi hotline ' . shop('hotline') . ' để được hỗ trợ.');
            $this->go(url('login'));
        }
        if ($user['role'] === 'admin') {
            Session::flash('info', 'Bạn đang đăng nhập bằng tài khoản quản trị. Chức năng này dành cho khách hàng.');
            $this->go(admin_url('dashboard'));
        }
    }

    private function go(string $url): void
    {
        header('Location: ' . $url);
        exit;
    }
}
