<?php
namespace App\Controllers\Client;

use App\Core\{ClientController, Paginator, Request};
use App\Models\{Review, Service};

/** Danh sách dịch vụ (tìm kiếm + phân trang) và trang chi tiết dịch vụ. */
final class ServiceController extends ClientController
{
    private Service $services;

    public function __construct(Request $request)
    {
        parent::__construct($request);
        $this->services = new Service();
    }

    public function index(): void
    {
        $q       = $this->request->query('q');
        $filters = ['q' => $q, 'status' => '1'];                      // khách chỉ thấy dịch vụ đang hiển thị
        $pager   = new Paginator($this->services->count($filters), (int) config('per_page.client_services', 6), $this->request->page());

        $this->view('services/index', [
            'title'    => 'Dịch vụ spa',
            'active'   => 'services',
            'q'        => $q,
            'pager'    => $pager,
            'services' => $this->services->paginate($filters, $pager->perPage, $pager->offset()),
        ]);
    }

    public function show(int $id): void
    {
        $service = $this->services->find($id);
        if ($service === null || !(int) $service['is_active']) {
            $this->notFound('Dịch vụ này không tồn tại hoặc đã tạm ngừng.');
        }
        $reviews = new Review();

        $this->view('services/show', [
            'title'   => $service['name'],
            'active'  => 'services',
            'service' => $service,
            'summary' => $reviews->summaryForService($id),
            'reviews' => $reviews->forService($id, 8),
            'others'  => $this->services->others($id, 3),
        ]);
    }
}
