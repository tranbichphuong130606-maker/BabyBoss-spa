<?php
namespace App\Controllers\Client;

use App\Core\{ClientController, ImageUploader, Request, UploadException};
use App\Models\Pet;

/** Hồ sơ thú cưng của khách: thêm, sửa, xóa, tải ảnh đại diện. Chỉ thao tác được trên bé của chính mình. */
final class PetController extends ClientController
{
    private Pet $pets;

    public function __construct(Request $request)
    {
        parent::__construct($request);
        $this->pets = new Pet();
    }

    private function uploader(): ImageUploader
    {
        return new ImageUploader(UPLOAD_PATH . '/pets', (int) config('upload.max_size', 2097152));
    }

    public function index(): void
    {
        $this->view('pets/index', [
            'title'  => 'Thú cưng của tôi',
            'active' => 'pets',
            'pets'   => $this->pets->forUser((int) $this->me()['id']),
        ]);
    }

    public function create(): void
    {
        $this->form(null, ['name' => '', 'species' => '', 'weight' => '', 'age' => ''], [], $this->request->query('next'));
    }

    public function store(): void
    {
        $userId = (int) $this->me()['id'];
        [$data, $errors] = $this->validated();

        $avatar = null;
        if (!$errors) {
            try {
                $avatar = $this->uploader()->save($this->request->file('avatar'), 'pet_');   // validate .jpg/.png/.webp + đổi tên uniqid()
            } catch (UploadException $e) {
                $errors['avatar'] = $e->getMessage();
            }
        }
        if ($errors) {
            $this->form(null, $data, $errors, $this->request->input('next'));
            return;
        }

        try {
            $id = $this->pets->create($userId, $data + ['avatar' => $avatar]);
        } catch (\Throwable $e) {
            $this->uploader()->delete($avatar);
            throw $e;
        }
        $this->flash('success', 'Đã thêm hồ sơ cho bé ' . $data['name'] . '.');
        $this->request->input('next') === 'book' ? $this->redirect('book', ['pet' => $id]) : $this->redirect('pets');
    }

    public function edit(int $id): void
    {
        $pet = $this->findPet($id);
        $this->form($pet, ['name' => $pet['name'], 'species' => $pet['species'], 'weight' => fmt_weight($pet['weight']), 'age' => (string) ($pet['age'] ?? '')], [], '');
    }

    public function update(int $id): void
    {
        $pet = $this->findPet($id);
        [$data, $errors] = $this->validated();

        $newAvatar = null;
        if (!$errors) {
            try {
                $newAvatar = $this->uploader()->save($this->request->file('avatar'), 'pet_');
            } catch (UploadException $e) {
                $errors['avatar'] = $e->getMessage();
            }
        }
        if ($errors) {
            $this->form($pet, $data, $errors, '');
            return;
        }

        try {
            $this->pets->update($id, $data + ['avatar' => $newAvatar ?? $pet['avatar']]);
        } catch (\Throwable $e) {
            $this->uploader()->delete($newAvatar);
            throw $e;
        }
        if ($newAvatar !== null) {
            $this->uploader()->delete($pet['avatar']);         // thay ảnh mới thì xóa ảnh cũ
        }
        $this->flash('success', 'Đã cập nhật hồ sơ của bé ' . $data['name'] . '.');
        $this->redirect('pets');
    }

    public function destroy(int $id): void
    {
        $pet = $this->findPet($id);
        if ($this->pets->hasActiveAppointments($id)) {
            $this->flash('error', 'Bé ' . $pet['name'] . ' đang có lịch chờ duyệt hoặc đã xác nhận. Hãy hủy lịch hoặc đợi lịch hoàn thành trước khi xóa hồ sơ.');
            $this->redirect('pets');
        }
        $this->pets->delete($id);
        $this->uploader()->delete($pet['avatar']);
        $this->flash('success', 'Đã xóa hồ sơ của bé ' . $pet['name'] . '.');
        $this->redirect('pets');
    }

    private function findPet(int $id): array
    {
        $pet = $this->pets->findForUser($id, (int) $this->me()['id']);
        if ($pet === null) {
            $this->notFound('Không tìm thấy hồ sơ bé cưng này.');
        }
        return $pet;
    }

    private function form(?array $pet, array $old, array $errors, string $next): void
    {
        $this->view('pets/form', [
            'title'  => $pet ? 'Sửa hồ sơ bé' : 'Thêm bé cưng',
            'active' => 'pets',
            'pet'    => $pet,
            'old'    => $old,
            'errors' => $errors,
            'next'   => $next,
        ]);
    }

    /** @return array{0: array, 1: array} [dữ liệu đã làm sạch, lỗi theo từng trường] */
    private function validated(): array
    {
        $r    = $this->request;
        $data = [
            'name'    => (string) preg_replace('/\s+/u', ' ', $r->input('name')),
            'species' => (string) preg_replace('/\s+/u', ' ', $r->input('species')),
            'weight'  => str_replace(',', '.', $r->input('weight')),
            'age'     => $r->input('age'),
        ];

        $errors = [];
        if ($data['name'] === '' || mb_strlen($data['name']) > 80) {
            $errors['name'] = 'Hãy nhập tên bé (tối đa 80 ký tự).';
        }
        $speciesLen = mb_strlen($data['species']);
        if ($speciesLen < 2 || $speciesLen > 80) {
            $errors['species'] = 'Hãy nhập giống loài, ví dụ Chó Poodle hoặc Mèo Anh lông ngắn.';
        }
        if ($data['weight'] !== '' && (!is_numeric($data['weight']) || (float) $data['weight'] < 0.1 || (float) $data['weight'] > 150)) {
            $errors['weight'] = 'Cân nặng từ 0,1 đến 150 kg. Bạn có thể để trống nếu chưa biết.';
        }
        if ($data['age'] !== '' && (!ctype_digit($data['age']) || (int) $data['age'] > 40)) {
            $errors['age'] = 'Tuổi là số nguyên từ 0 đến 40. Bạn có thể để trống.';
        }
        return [$data, $errors];
    }
}
