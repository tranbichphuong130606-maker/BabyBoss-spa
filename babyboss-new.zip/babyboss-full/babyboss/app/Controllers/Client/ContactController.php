<?php
namespace App\Controllers\Client;

use App\Core\ClientController;
use App\Models\Message;

/** Liên hệ: hotline và tin nhắn. Hệ thống tự động trả lời, sau đó chờ nhân viên (admin) phản hồi. */
final class ContactController extends ClientController
{
    private const MAX_PENDING = 5;     // tối đa 5 tin đang chờ phản hồi để tránh gửi hàng loạt

    public function index(): void
    {
        $this->render('', null);
    }

    public function send(): void
    {
        $me       = $this->me();
        $content  = $this->request->input('content');
        $messages = new Message();

        if ($content === '' || mb_strlen($content) > 1000) {
            $this->render($content, 'Nội dung tin nhắn cần từ 1 đến 1.000 ký tự.');
            return;
        }
        $pending = $messages->pendingCount((int) $me['id']);
        if ($pending >= self::MAX_PENDING) {
            $this->render($content, 'Bạn đang có ' . $pending . ' tin nhắn chờ phản hồi. Vui lòng đợi nhân viên trả lời hoặc gọi hotline ' . shop('hotline') . '.');
            return;
        }

        $messages->add((int) $me['id'], 'customer', $content);
        if ($pending === 0) {                                  // chỉ tự động trả lời ở tin đầu tiên của mỗi lượt chờ
            $messages->add((int) $me['id'], 'system', $this->autoReply());
        }
        $this->flash('success', 'Đã gửi tin nhắn. Nhân viên BabyBoss sẽ phản hồi trong giờ làm việc.');
        $this->redirect('contact', [], 'chat');
    }

    private function autoReply(): string
    {
        return sprintf(
            'BabyBoss đã nhận được tin nhắn của bạn. Nhân viên sẽ phản hồi trong giờ làm việc (%s). Cần gấp, vui lòng gọi hotline %s.',
            shop('hours'), shop('hotline')
        );
    }

    private function render(string $draft, ?string $error): void
    {
        $me = \App\Core\Auth::user();
        $this->view('contact/index', [
            'title'  => 'Liên hệ',
            'active' => 'contact',
            'thread' => ($me && $me['role'] === 'customer') ? (new Message())->thread((int) $me['id']) : [],
            'draft'  => $draft,
            'error'  => $error,
        ]);
    }
}
