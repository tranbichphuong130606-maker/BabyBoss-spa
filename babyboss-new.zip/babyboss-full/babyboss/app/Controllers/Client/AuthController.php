<?php
namespace App\Controllers\Client;

use App\Core\{Auth, ClientController, LoginThrottle, Request, Session};
use App\Models\User;

/** Đăng ký, đăng nhập, đăng xuất của khách hàng. */
final class AuthController extends ClientController
{
    private User $users;

    public function __construct(Request $request)
    {
        parent::__construct($request);
        $this->users = new User();
    }

    public function showLogin(): void
    {
        $this->redirectIfLoggedIn();
        $this->renderLogin('', null);
    }

    public function login(): void
    {
        $throttle = new LoginThrottle('client_login');           // sai 5 lần -> khóa 5 phút
        $email    = mb_strtolower($this->request->input('email'));
        $password = $this->request->raw('password');

        if ($throttle->remaining() > 0) {
            $this->renderLogin($email, $throttle->message());
            return;
        }
        if ($email === '' || $password === '') {
            $this->renderLogin($email, 'Vui lòng nhập email và mật khẩu.');
            return;
        }

        [$user, $error] = Auth::attempt($email, $password, false);
        if ($user === null) {
            $throttle->fail();
            $this->renderLogin($email, $error);
            return;
        }

        $throttle->clear();
        Auth::login($user);
        $this->flash('success', 'Chào mừng ' . first_name($user['full_name']) . ' quay lại BabyBoss!');
        $this->afterAuth($user);
    }

    public function showRegister(): void
    {
        $this->redirectIfLoggedIn();
        $this->renderRegister(['full_name' => '', 'email' => '', 'phone' => ''], []);
    }

    public function register(): void
    {
        $r   = $this->request;
        $old = [
            'full_name' => (string) preg_replace('/\s+/u', ' ', $r->input('full_name')),
            'email'     => mb_strtolower($r->input('email')),
            'phone'     => $r->input('phone'),
        ];
        $password = $r->raw('password');
        $confirm  = $r->raw('password_confirm');
        $errors   = [];

        $len = mb_strlen($old['full_name']);
        if ($len < 2 || $len > 100) {
            $errors['full_name'] = 'Họ tên cần từ 2 đến 100 ký tự.';
        }

        if (mb_strlen($old['email']) > 150 || !filter_var($old['email'], FILTER_VALIDATE_EMAIL)) {
            $errors['email'] = 'Email chưa đúng định dạng, ví dụ tenban@gmail.com.';
        } elseif ($this->users->emailExists($old['email'])) {
            $errors['email'] = 'Email này đã được đăng ký. Hãy đăng nhập hoặc dùng email khác.';
        }

        // Chấp nhận 0901234567, 090 123 4567 hoặc +84901234567
        $phone = (string) preg_replace('/[\s.\-()]/', '', $old['phone']);
        if (preg_match('/^(?:\+?84|0)([35789][0-9]{8})$/', $phone, $m)) {
            $old['phone'] = '0' . $m[1];
        } else {
            $errors['phone'] = 'Số điện thoại cần đủ 10 chữ số và bắt đầu bằng 0, ví dụ 0901234567.';
        }

        if (strlen($password) < 8 || strlen($password) > 72 || !preg_match('/\p{L}/u', $password) || !preg_match('/\d/', $password)) {
            $errors['password'] = 'Mật khẩu cần từ 8 ký tự và gồm cả chữ lẫn số.';
        } elseif ($password !== $confirm) {
            $errors['password_confirm'] = 'Mật khẩu nhập lại chưa khớp.';
        }

        if ($errors) {
            $this->renderRegister($old, $errors);
            return;
        }

        try {
            // Mật khẩu luôn được băm bằng password_hash() trước khi lưu
            $id = $this->users->create($old['full_name'], $old['email'], $old['phone'], password_hash($password, PASSWORD_DEFAULT));
        } catch (\PDOException $e) {
            if ($e->getCode() === '23000') {                       // trùng email do hai yêu cầu gửi cùng lúc
                $this->renderRegister($old, ['email' => 'Email này đã được đăng ký. Hãy đăng nhập hoặc dùng email khác.']);
                return;
            }
            throw $e;
        }

        $user = $this->users->find($id);
        Auth::login($user);
        $this->flash('success', 'Chào mừng ' . first_name($user['full_name']) . ' đến với BabyBoss! Hãy thêm hồ sơ bé cưng đầu tiên để đặt lịch.');
        $this->afterAuth($user, 'pets/create');
    }

    public function logout(): void
    {
        Auth::logout();
        Session::flash('success', 'Bạn đã đăng xuất.');
        $this->redirect('');
    }

    /** Sau khi đăng nhập / đăng ký: admin vào khu quản trị; khách quay lại trang đang định vào (nếu có). */
    private function afterAuth(array $user, string $default = ''): void
    {
        if ($user['role'] === 'admin') {
            $this->redirectTo(admin_url('dashboard'));
        }
        $intended = Session::get('intended');
        Session::forget('intended');
        if (is_array($intended) && preg_match('#^[a-z0-9/_-]+$#', (string) ($intended['route'] ?? ''))) {
            $this->redirect($intended['route'], is_array($intended['query'] ?? null) ? $intended['query'] : []);
        }
        $this->redirect($default);
    }

    private function redirectIfLoggedIn(): void
    {
        $user = Auth::user();
        if ($user !== null && $user['status'] === 'active') {
            $user['role'] === 'admin' ? $this->redirectTo(admin_url('dashboard')) : $this->redirect('');
        }
    }

    private function renderLogin(string $email, ?string $error): void
    {
        $this->view('auth/login', ['title' => 'Đăng nhập', 'active' => '', 'email' => $email, 'error' => $error]);
    }

    private function renderRegister(array $old, array $errors): void
    {
        $this->view('auth/register', ['title' => 'Đăng ký', 'active' => '', 'old' => $old, 'errors' => $errors]);
    }
}
