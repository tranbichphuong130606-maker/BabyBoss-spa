<?php
namespace App\Controllers\Client;

use App\Core\{ClientController, Paginator};
use App\Models\{LoyaltyTransaction, MembershipTier};
use App\Services\LoyaltyService;

/** Ví điểm thưởng: số điểm hiện có, hạng thành viên, tiến độ lên hạng và lịch sử tích / tiêu điểm. */
final class LoyaltyController extends ClientController
{
    public function index(): void
    {
        $me    = $this->me();
        $tiers = (new MembershipTier())->all();
        $log   = new LoyaltyTransaction();
        $query = ['user_id' => (int) $me['id']];
        $pager = new Paginator($log->count($query), (int) config('per_page.client_points', 8), $this->request->page());

        $this->view('loyalty/index', [
            'title'        => 'Điểm thưởng',
            'active'       => 'loyalty',
            'progress'     => LoyaltyService::progress((int) $me['total_spent'], $tiers),
            'tiers'        => $tiers,
            'pointValue'   => (new LoyaltyService())->pointValue(),
            'pager'        => $pager,
            'transactions' => $log->paginate($query, $pager->perPage, $pager->offset()),
        ]);
    }
}
