<?php
namespace App\Controllers\Client;

use App\Core\ClientController;

/** Các trang nội dung tĩnh. */
final class PageController extends ClientController
{
    public function about(): void
    {
        $this->view('pages/about', ['title' => 'Giới thiệu', 'active' => 'about']);
    }
}
