<?php
namespace App\Controllers\Client;

use App\Core\{ClientController, Paginator};
use App\Models\{Appointment, Pet, Service};
use App\Services\{AppointmentService, BookingService, LoyaltyService};

/** Đặt lịch spa, xem lịch sử lịch hẹn và hủy lịch đang chờ duyệt. */
final class BookingController extends ClientController
{
    /** Form đặt lịch; nhận sẵn ?service=, ?pet=, ?date= từ các nút "Đặt lịch" trên website. */
    public function create(): void
    {
        $pets = (new Pet())->forUser((int) $this->me()['id']);
        $old  = [
            'pet_id'     => $this->request->query('pet'),
            'service_id' => $this->request->query('service'),
            'date'       => $this->futureDate($this->request->query('date')),
            'time'       => '',
            'note'       => '',
            'points'     => '0',
        ];
        if ($old['pet_id'] === '' && count($pets) === 1) {
            $old['pet_id'] = (string) $pets[0]['id'];
        }
        $this->form($old, [], null);
    }

    public function store(): void
    {
        $r  = $this->request;
        $in = [
            'pet_id'     => $r->input('pet_id'),
            'service_id' => $r->input('service_id'),
            'date'       => $r->input('date'),
            'time'       => $r->input('time'),
            'note'       => $r->input('note'),
            'points'     => $r->input('points', '0'),
        ];

        $result = (new BookingService())->book((int) $this->me()['id'], $in);
        if (!$result['ok']) {
            $this->form($in, $result['errors'], $result['message']);
            return;
        }
        $this->flash('success', $result['message']);
        $this->redirect('appointments');
    }

    /** Lịch sử lịch hẹn và trạng thái duyệt của từng lịch. */
    public function index(): void
    {
        $userId = (int) $this->me()['id'];
        $status = $this->request->query('status');
        if (!isset(Appointment::STATUSES[$status])) {
            $status = '';
        }

        $model = new Appointment();
        $pager = new Paginator($model->countForUser($userId, $status), (int) config('per_page.client_appointments', 5), $this->request->page());

        $this->view('bookings/index', [
            'title'        => 'Lịch hẹn của tôi',
            'active'       => 'appointments',
            'status'       => $status,
            'pager'        => $pager,
            'counts'       => $model->countByStatusForUser($userId),
            'appointments' => $model->paginateForUser($userId, $status, $pager->perPage, $pager->offset()),
        ]);
    }

    public function cancel(int $id): void
    {
        $result = (new AppointmentService())->changeStatus($id, 'cancelled', null, (int) $this->me()['id']);
        $this->flash($result['ok'] ? 'success' : 'error', $result['message']);
        $this->back('appointments');
    }

    private function form(array $old, array $errors, ?string $formError): void
    {
        $maxDays = (int) config('booking.max_days_ahead', 60);
        $this->view('bookings/create', [
            'title'      => 'Đặt lịch spa',
            'active'     => 'book',
            'pets'       => (new Pet())->forUser((int) $this->me()['id']),
            'services'   => (new Service())->options(),
            'slots'      => BookingService::slots(),
            'pointValue' => (new LoyaltyService())->pointValue(),
            'old'        => $old,
            'errors'     => $errors,
            'formError'  => $formError,
            'minDate'    => date('Y-m-d'),
            'maxDate'    => date('Y-m-d', strtotime('+' . $maxDays . ' days')),
        ]);
    }

    private function futureDate(string $value): string
    {
        $dt = \DateTime::createFromFormat('Y-m-d', $value);
        return ($dt && $dt->format('Y-m-d') === $value && $value >= date('Y-m-d')) ? $value : '';
    }
}
