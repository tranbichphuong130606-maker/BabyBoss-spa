<?php
namespace App\Controllers\Client;

use App\Core\ClientController;
use App\Models\{Review, Service};
use App\Services\LoyaltyService;

/** Trang chủ: đặt lịch nhanh, dịch vụ nổi bật, nhận xét mới của khách. */
final class HomeController extends ClientController
{
    public function index(): void
    {
        $services = new Service();
        $reviews  = new Review();

        $this->view('home/index', [
            'title'        => '',
            'active'       => 'home',
            'featured'     => $services->featured(3),
            'options'      => $services->options(),
            'serviceCount' => $services->countActive(),
            'testimonials' => $reviews->latestVisible(3),
            'summary'      => $reviews->summaryForService(null),
            'pointValue'   => (new LoyaltyService())->pointValue(),
        ]);
    }
}
