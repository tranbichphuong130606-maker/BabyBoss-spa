<?php
namespace App\Controllers\Client;

use App\Core\ClientController;
use App\Models\{Appointment, Review};

/** Khách đánh giá (1-5 sao + nhận xét) sau khi lịch spa đã hoàn thành. */
final class ReviewController extends ClientController
{
    public function store(): void
    {
        $userId  = (int) $this->me()['id'];
        $rating  = $this->request->input('rating');
        $comment = (string) preg_replace('/[ \t]+/u', ' ', $this->request->input('comment'));

        $appt = (new Appointment())->findForUser((int) $this->request->input('appointment_id'), $userId);
        $reviews = new Review();

        $error = match (true) {
            $appt === null                                          => 'Không tìm thấy lịch hẹn cần đánh giá.',
            $appt['status'] !== 'completed'                         => 'Bạn chỉ đánh giá được sau khi lịch spa đã hoàn thành.',
            !ctype_digit($rating) || $rating < 1 || $rating > 5     => 'Hãy chọn số sao từ 1 đến 5.',
            mb_strlen($comment) > 1000                              => 'Nhận xét tối đa 1.000 ký tự.',
            $reviews->existsForAppointment((int) $appt['id'])       => 'Bạn đã đánh giá lịch này rồi.',
            default                                                 => null,
        };
        if ($error !== null) {
            $this->flash('error', $error);
            $this->back('appointments');
        }

        try {
            $reviews->create((int) $appt['id'], $userId, (int) $appt['service_id'], (int) $rating, $comment);
        } catch (\PDOException $e) {
            if ($e->getCode() === '23000') {                         // bấm gửi hai lần: UNIQUE(appointment_id) chặn lại
                $this->flash('error', 'Bạn đã đánh giá lịch này rồi.');
                $this->back('appointments');
            }
            throw $e;
        }
        $this->flash('success', 'Cảm ơn bạn! Đánh giá của bạn đã được đăng ở trang dịch vụ.');
        $this->back('appointments');
    }
}
