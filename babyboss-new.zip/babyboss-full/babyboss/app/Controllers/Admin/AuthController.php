<?php
namespace App\Controllers\Admin;

use App\Core\{Auth, Controller, LoginThrottle, Session};

/** Đăng nhập / đăng xuất khu vực quản trị. */
final class AuthController extends Controller
{
    public function showLogin(): void
    {
        $user = Auth::user();
        if ($user && $user['role'] === 'admin' && $user['status'] === 'active') {
            $this->redirect('dashboard');
        }
        $this->renderLogin('', null);
    }

    public function login(): void
    {
        $email    = mb_strtolower($this->request->input('email'));
        $password = $this->request->raw('password');

        $throttle = new LoginThrottle('login');      // sai 5 lần -> khóa 5 phút
        if ($throttle->remaining() > 0) {
            $this->renderLogin($email, $throttle->message());
            return;
        }
        if ($email === '' || $password === '') {
            $this->renderLogin($email, 'Vui lòng nhập email và mật khẩu.');
            return;
        }

        [$user, $error] = Auth::attempt($email, $password);
        if ($user === null) {
            $throttle->fail();
            $this->renderLogin($email, $error);
            return;
        }

        $throttle->clear();
        Auth::login($user);
        Session::flash('success', 'Chào mừng ' . $user['full_name'] . ' quay trở lại!');
        $this->redirect('dashboard');
    }

    public function logout(): void
    {
        Auth::logout();
        Session::flash('success', 'Bạn đã đăng xuất khỏi khu vực quản trị.');
        $this->redirect('login');
    }

    private function renderLogin(string $email, ?string $error): void
    {
        $this->view('auth/login', ['title' => 'Đăng nhập quản trị', 'email' => $email, 'error' => $error], null);
    }
}
