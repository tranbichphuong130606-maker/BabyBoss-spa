<?php
namespace App\Models;

use App\Core\Model;

final class Review extends Model
{
    public const STATUSES = ['visible' => 'Đang hiển thị', 'hidden' => 'Đã ẩn'];

    private function where(array $f): array
    {
        $where  = ['1 = 1'];
        $params = [];
        if (($f['q'] ?? '') !== '') {
            $like    = $this->like($f['q']);
            $where[] = '(u.full_name LIKE :q1 OR s.name LIKE :q2 OR r.comment LIKE :q3)';
            $params += ['q1' => $like, 'q2' => $like, 'q3' => $like];
        }
        if ((int) ($f['rating'] ?? 0) >= 1 && (int) $f['rating'] <= 5) {
            $where[]          = 'r.rating = :rating';
            $params['rating'] = (int) $f['rating'];
        }
        if (isset(self::STATUSES[$f['status'] ?? ''])) {
            $where[]          = 'r.status = :status';
            $params['status'] = $f['status'];
        }
        return [implode(' AND ', $where), $params];
    }

    public function count(array $f = []): int
    {
        [$where, $params] = $this->where($f);
        return (int) $this->scalar(
            "SELECT COUNT(*) FROM reviews r JOIN users u ON u.id = r.user_id JOIN services s ON s.id = r.service_id WHERE $where",
            $params
        );
    }

    public function paginate(array $f, int $limit, int $offset): array
    {
        [$where, $params] = $this->where($f);
        return $this->fetchAll(
            "SELECT r.*, u.full_name AS customer_name, s.name AS service_name
             FROM reviews r JOIN users u ON u.id = r.user_id JOIN services s ON s.id = r.service_id
             WHERE $where ORDER BY r.created_at DESC, r.id DESC LIMIT :limit OFFSET :offset",
            $params + ['limit' => $limit, 'offset' => $offset]
        );
    }

    public function find(int $id): ?array
    {
        return $this->fetchOne('SELECT * FROM reviews WHERE id = :id', ['id' => $id]);
    }

    public function setStatus(int $id, string $status): void
    {
        $this->run('UPDATE reviews SET status = :s WHERE id = :id', ['s' => $status, 'id' => $id]);
    }

    public function delete(int $id): void
    {
        $this->run('DELETE FROM reviews WHERE id = :id', ['id' => $id]);
    }

    /** Tổng số đánh giá, số đã ẩn và điểm trung bình (chỉ tính đánh giá đang hiển thị). */
    public function stats(): array
    {
        $row = $this->fetchOne(
            "SELECT COUNT(*) AS total,
                    COALESCE(SUM(status = 'hidden'), 0) AS hidden,
                    ROUND(AVG(CASE WHEN status = 'visible' THEN rating END), 1) AS avg_rating
             FROM reviews"
        );
        return ['total' => (int) $row['total'], 'hidden' => (int) $row['hidden'], 'avg_rating' => $row['avg_rating']];
    }

    /** Đánh giá đang hiển thị của một dịch vụ (đã ẩn thì khách không thấy). */
    public function forService(int $serviceId, int $limit): array
    {
        return $this->fetchAll(
            "SELECT r.rating, r.comment, r.created_at, u.full_name AS customer_name
             FROM reviews r JOIN users u ON u.id = r.user_id
             WHERE r.service_id = :s AND r.status = 'visible'
             ORDER BY r.created_at DESC, r.id DESC LIMIT :limit",
            ['s' => $serviceId, 'limit' => $limit]
        );
    }

    /** Số đánh giá và điểm trung bình (chỉ tính đánh giá đang hiển thị). @return array{count: int, avg: ?string} */
    public function summaryForService(?int $serviceId = null): array
    {
        $row = $serviceId === null
            ? $this->fetchOne("SELECT COUNT(*) AS c, ROUND(AVG(rating), 1) AS a FROM reviews WHERE status = 'visible'")
            : $this->fetchOne("SELECT COUNT(*) AS c, ROUND(AVG(rating), 1) AS a FROM reviews WHERE service_id = :s AND status = 'visible'", ['s' => $serviceId]);
        return ['count' => (int) $row['c'], 'avg' => $row['a']];
    }

    /** Nhận xét mới nhất có điểm cao, hiển thị ở trang chủ. */
    public function latestVisible(int $limit, int $minRating = 4): array
    {
        return $this->fetchAll(
            "SELECT r.rating, r.comment, r.created_at, u.full_name AS customer_name, s.name AS service_name
             FROM reviews r JOIN users u ON u.id = r.user_id JOIN services s ON s.id = r.service_id
             WHERE r.status = 'visible' AND r.rating >= :min AND r.comment IS NOT NULL AND r.comment <> ''
             ORDER BY r.created_at DESC, r.id DESC LIMIT :limit",
            ['min' => $minRating, 'limit' => $limit]
        );
    }

    public function existsForAppointment(int $appointmentId): bool
    {
        return (int) $this->scalar('SELECT COUNT(*) FROM reviews WHERE appointment_id = :a', ['a' => $appointmentId]) > 0;
    }

    public function create(int $appointmentId, int $userId, int $serviceId, int $rating, string $comment): void
    {
        $this->run(
            'INSERT INTO reviews (appointment_id, user_id, service_id, rating, comment) VALUES (:a, :u, :s, :r, :c)',
            ['a' => $appointmentId, 'u' => $userId, 's' => $serviceId, 'r' => $rating, 'c' => $comment === '' ? null : $comment]
        );
    }
}
