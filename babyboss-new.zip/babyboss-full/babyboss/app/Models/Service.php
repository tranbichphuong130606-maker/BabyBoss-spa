<?php
namespace App\Models;

use App\Core\Model;

final class Service extends Model
{
    private function where(array $f): array
    {
        $where  = ['1 = 1'];
        $params = [];
        if (($f['q'] ?? '') !== '') {
            $like    = $this->like($f['q']);
            $where[] = '(s.name LIKE :q1 OR s.description LIKE :q2)';
            $params += ['q1' => $like, 'q2' => $like];
        }
        if (in_array($f['status'] ?? '', ['1', '0'], true)) {
            $where[]             = 's.is_active = :active';
            $params['active']    = (int) $f['status'];
        }
        return [implode(' AND ', $where), $params];
    }

    public function count(array $f = []): int
    {
        [$where, $params] = $this->where($f);
        return (int) $this->scalar("SELECT COUNT(*) FROM services s WHERE $where", $params);
    }

    public function countActive(): int
    {
        return (int) $this->scalar('SELECT COUNT(*) FROM services WHERE is_active = 1');
    }

    public function paginate(array $f, int $limit, int $offset): array
    {
        [$where, $params] = $this->where($f);
        return $this->fetchAll(
            "SELECT s.*,
                    (SELECT COUNT(*) FROM appointments a WHERE a.service_id = s.id) AS booking_count,
                    (SELECT ROUND(AVG(r.rating), 1) FROM reviews r WHERE r.service_id = s.id AND r.status = 'visible') AS avg_rating
             FROM services s WHERE $where
             ORDER BY s.id DESC LIMIT :limit OFFSET :offset",
            $params + ['limit' => $limit, 'offset' => $offset]
        );
    }

    public function find(int $id): ?array
    {
        return $this->fetchOne('SELECT * FROM services WHERE id = :id', ['id' => $id]);
    }

    public function create(array $d): int
    {
        $this->run(
            'INSERT INTO services (name, description, price, duration, image, is_active)
             VALUES (:name, :description, :price, :duration, :image, :is_active)',
            [
                'name' => $d['name'], 'description' => $d['description'], 'price' => (int) $d['price'],
                'duration' => (int) $d['duration'], 'image' => $d['image'], 'is_active' => (int) $d['is_active'],
            ]
        );
        return $this->insertId();
    }

    public function update(int $id, array $d): void
    {
        $this->run(
            'UPDATE services SET name = :name, description = :description, price = :price, duration = :duration,
                    image = :image, is_active = :is_active WHERE id = :id',
            [
                'name' => $d['name'], 'description' => $d['description'], 'price' => (int) $d['price'],
                'duration' => (int) $d['duration'], 'image' => $d['image'], 'is_active' => (int) $d['is_active'], 'id' => $id,
            ]
        );
    }

    public function delete(int $id): void
    {
        $this->run('DELETE FROM services WHERE id = :id', ['id' => $id]);
    }

    public function bookingCount(int $id): int
    {
        return (int) $this->scalar('SELECT COUNT(*) FROM appointments WHERE service_id = :id', ['id' => $id]);
    }

    private const WITH_STATS = "SELECT s.*,
            (SELECT COUNT(*) FROM appointments a WHERE a.service_id = s.id) AS booking_count,
            (SELECT ROUND(AVG(r.rating), 1) FROM reviews r WHERE r.service_id = s.id AND r.status = 'visible') AS avg_rating
        FROM services s";

    /** Dịch vụ nổi bật: đang hiển thị và được đặt nhiều nhất. */
    public function featured(int $limit): array
    {
        return $this->fetchAll(
            self::WITH_STATS . ' WHERE s.is_active = 1 ORDER BY booking_count DESC, s.id ASC LIMIT :limit',
            ['limit' => $limit]
        );
    }

    /** Các dịch vụ khác đang hiển thị (gợi ý ở trang chi tiết). */
    public function others(int $exceptId, int $limit): array
    {
        return $this->fetchAll(
            self::WITH_STATS . ' WHERE s.is_active = 1 AND s.id <> :id ORDER BY booking_count DESC, s.id ASC LIMIT :limit',
            ['id' => $exceptId, 'limit' => $limit]
        );
    }

    /** Danh sách dịch vụ để chọn trong form đặt lịch. */
    public function options(): array
    {
        return $this->fetchAll('SELECT id, name, price, duration FROM services WHERE is_active = 1 ORDER BY name ASC');
    }
}
