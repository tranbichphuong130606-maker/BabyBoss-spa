<?php
namespace App\Models;

use App\Core\Model;
use PDO;

final class Pet extends Model
{
    public function count(): int
    {
        return (int) $this->scalar('SELECT COUNT(*) FROM pets');
    }

    /** Tên file avatar của các thú cưng thuộc một khách hàng (để dọn file khi xóa tài khoản). */
    public function avatarsOfUser(int $userId): array
    {
        return $this->run('SELECT avatar FROM pets WHERE user_id = :u AND avatar IS NOT NULL', ['u' => $userId])->fetchAll(PDO::FETCH_COLUMN);
    }

    /** Danh sách thú cưng của một khách, kèm số lịch hẹn của từng bé. */
    public function forUser(int $userId): array
    {
        return $this->fetchAll(
            'SELECT p.*, (SELECT COUNT(*) FROM appointments a WHERE a.pet_id = p.id) AS appointment_count
             FROM pets p WHERE p.user_id = :u ORDER BY p.id DESC',
            ['u' => $userId]
        );
    }

    /** Chỉ trả về bé thuộc về khách này (chống xem / sửa hồ sơ của người khác). */
    public function findForUser(int $id, int $userId): ?array
    {
        return $this->fetchOne('SELECT * FROM pets WHERE id = :id AND user_id = :u', ['id' => $id, 'u' => $userId]);
    }

    public function create(int $userId, array $d): int
    {
        $this->run(
            'INSERT INTO pets (user_id, name, species, weight, age, avatar) VALUES (:u, :n, :s, :w, :a, :av)',
            [
                'u' => $userId, 'n' => $d['name'], 's' => $d['species'],
                'w' => $d['weight'] === '' ? null : number_format((float) $d['weight'], 2, '.', ''),
                'a' => $d['age'] === '' ? null : (int) $d['age'],
                'av' => $d['avatar'] ?? null,
            ]
        );
        return $this->insertId();
    }

    public function update(int $id, array $d): void
    {
        $this->run(
            'UPDATE pets SET name = :n, species = :s, weight = :w, age = :a, avatar = :av WHERE id = :id',
            [
                'n' => $d['name'], 's' => $d['species'],
                'w' => $d['weight'] === '' ? null : number_format((float) $d['weight'], 2, '.', ''),
                'a' => $d['age'] === '' ? null : (int) $d['age'],
                'av' => $d['avatar'] ?? null, 'id' => $id,
            ]
        );
    }

    public function delete(int $id): void
    {
        $this->run('DELETE FROM pets WHERE id = :id', ['id' => $id]);
    }

    /** Bé còn lịch "Chờ duyệt" hoặc "Đã xác nhận" thì chưa được xóa hồ sơ. */
    public function hasActiveAppointments(int $id): bool
    {
        return (int) $this->scalar("SELECT COUNT(*) FROM appointments WHERE pet_id = :id AND status IN ('pending', 'confirmed')", ['id' => $id]) > 0;
    }
}
