<?php
namespace App\Core;

/** Hạn chế dò mật khẩu: sai quá số lần cho phép thì tạm khóa form đăng nhập (lưu theo session). */
final class LoginThrottle
{
    public function __construct(
        private string $key = 'login',
        private int $maxAttempts = 5,
        private int $lockSeconds = 300
    ) {}

    /** Số giây còn lại của lần khóa (0 = không bị khóa). */
    public function remaining(): int
    {
        return max(0, (int) Session::get($this->key . '_locked_until', 0) - time());
    }

    public function message(): string
    {
        return 'Bạn đã nhập sai quá nhiều lần. Vui lòng thử lại sau ' . (int) ceil($this->remaining() / 60) . ' phút.';
    }

    public function fail(): void
    {
        $fails = (int) Session::get($this->key . '_fails', 0) + 1;
        if ($fails >= $this->maxAttempts) {
            Session::put($this->key . '_locked_until', time() + $this->lockSeconds);
            $fails = 0;
        }
        Session::put($this->key . '_fails', $fails);
    }

    public function clear(): void
    {
        Session::forget($this->key . '_fails');
        Session::forget($this->key . '_locked_until');
    }
}
