<?php
namespace App\Core;

/** Lớp cha của các Controller khu vực Client (khách hàng): URL, layout và "quay lại" theo khu vực Client. */
abstract class ClientController extends Controller
{
    /** Người dùng đang đăng nhập (hoặc null nếu là khách vãng lai) cho header của trang. */
    protected function layoutData(): array
    {
        return ['me' => Auth::user()];
    }

    protected function urlFor(string $route, array $query = []): string
    {
        return url($route, $query);
    }

    protected function backPrefix(): string
    {
        return BASE_URL . '/';
    }

    /** Người dùng hiện tại (middleware đã bảo đảm có đăng nhập ở các route cần đăng nhập). */
    protected function me(): array
    {
        return Auth::user() ?? [];
    }
}
