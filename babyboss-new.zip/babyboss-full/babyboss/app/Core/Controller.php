<?php
namespace App\Core;

use App\Models\{Appointment, Message};

/**
 * Lớp cha của mọi Controller. Các hàm "hook" (layoutData, urlFor, backPrefix) mặc định phục vụ
 * khu vực Admin; khu vực Client dùng ClientController để ghi đè chúng.
 */
abstract class Controller
{
    public function __construct(protected Request $request) {}

    /** Hiển thị view (mặc định bọc trong layout của khu vực). */
    protected function view(string $template, array $data = [], ?string $layout = 'layouts/main'): void
    {
        $data['flashes'] = Session::pullFlash();
        if ($layout !== null) {
            $data += $this->layoutData();
        }
        View::render($template, $data, $layout);
    }

    /** Dữ liệu dùng chung cho layout (Admin: người dùng hiện tại + số việc cần xử lý). */
    protected function layoutData(): array
    {
        return [
            'admin'     => Auth::user(),
            'navCounts' => [
                'appointments' => (new Appointment())->countPending(),
                'messages'     => (new Message())->countAwaiting(),
            ],
        ];
    }

    /** URL tới một route của khu vực hiện tại. */
    protected function urlFor(string $route, array $query = []): string
    {
        return admin_url($route, $query);
    }

    /** Đường dẫn mà trang "quay lại" (Referer) phải bắt đầu bằng, để tránh chuyển hướng ra ngoài. */
    protected function backPrefix(): string
    {
        return BASE_URL . '/admin/';
    }

    protected function flash(string $type, string $message): void
    {
        Session::flash($type, $message);
    }

    protected function redirect(string $route, array $query = [], string $fragment = ''): void
    {
        header('Location: ' . $this->urlFor($route, $query) . ($fragment !== '' ? '#' . $fragment : ''));
        exit;
    }

    protected function redirectTo(string $url): void
    {
        header('Location: ' . $url);
        exit;
    }

    /** Quay lại trang trước (giữ nguyên bộ lọc / trang); nếu không có thì về route dự phòng. */
    protected function back(string $fallbackRoute): void
    {
        $ref     = (string) ($_SERVER['HTTP_REFERER'] ?? '');
        $refHost = parse_url($ref, PHP_URL_HOST);
        $refPath = (string) parse_url($ref, PHP_URL_PATH);
        $myHost  = parse_url('//' . ($_SERVER['HTTP_HOST'] ?? ''), PHP_URL_HOST);

        if ($refHost !== null && $refHost === $myHost && str_starts_with($refPath, $this->backPrefix())) {
            $query = parse_url($ref, PHP_URL_QUERY);
            header('Location: ' . $refPath . ($query ? '?' . $query : ''));
            exit;
        }
        $this->redirect($fallbackRoute);
    }

    protected function notFound(string $message = 'Không tìm thấy dữ liệu yêu cầu.'): void
    {
        View::error(404, $message);
        exit;
    }
}
