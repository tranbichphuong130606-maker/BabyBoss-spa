<?php
use App\Core\{Config, Csrf, View};

function config(string $key, $default = null)
{
    return Config::get($key, $default);
}

/** Escape HTML — luôn dùng khi in dữ liệu ra view (chống XSS). */
function e($value): string
{
    return htmlspecialchars((string) ($value ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function base_url(string $path = ''): string
{
    return BASE_URL . '/' . ltrim($path, '/');
}

/** URL tới một route admin: admin_url('users', ['q' => 'an', 'page' => 2]). */
function admin_url(string $route = '', array $query = []): string
{
    $params = array_filter(['route' => $route] + $query, fn($v) => $v !== null && $v !== '');
    $qs     = $params ? '?' . str_replace('%2F', '/', http_build_query($params)) : '';
    return BASE_URL . '/admin/index.php' . $qs;
}

function admin_asset(string $path): string
{
    return BASE_URL . '/admin/assets/' . ltrim($path, '/');
}

function upload_url(?string $file, string $folder = 'services'): ?string
{
    return $file ? BASE_URL . '/uploads/' . $folder . '/' . rawurlencode($file) : null;
}

function csrf_field(): string
{
    return '<input type="hidden" name="_token" value="' . e(Csrf::token()) . '">';
}

/** Form GET cần kèm route vì URL admin dùng ?route=... */
function route_field(string $route): string
{
    return '<input type="hidden" name="route" value="' . e($route) . '">';
}

function partial(string $name, array $data = []): void
{
    View::partial($name, $data);
}

function money($amount): string
{
    return number_format((float) $amount, 0, ',', '.') . ' ₫';
}

function fmt_date($value, string $format = 'd/m/Y H:i'): string
{
    return $value ? date($format, strtotime((string) $value)) : '—';
}

function appt_code(int $id): string
{
    return 'LH' . str_pad((string) $id, 4, '0', STR_PAD_LEFT);
}

function duration_text(int $minutes): string
{
    if ($minutes < 60) {
        return $minutes . ' phút';
    }
    $h = intdiv($minutes, 60);
    $m = $minutes % 60;
    return $h . ' giờ' . ($m ? ' ' . $m . ' phút' : '');
}

/** Chữ cái đầu của tên (tên riêng tiếng Việt nằm cuối họ tên). */
function initial(string $name): string
{
    $parts = preg_split('/\s+/u', trim($name));
    return mb_strtoupper(mb_substr((string) end($parts), 0, 1)) ?: '?';
}

function first_name(string $name): string
{
    $parts = preg_split('/\s+/u', trim($name));
    return (string) end($parts);
}

function stars(int $n): string
{
    return str_repeat('★', $n) . str_repeat('☆', 5 - $n);
}

function today_vi(): string
{
    $days = ['Chủ nhật', 'Thứ hai', 'Thứ ba', 'Thứ tư', 'Thứ năm', 'Thứ sáu', 'Thứ bảy'];
    return $days[(int) date('w')] . ', ' . date('d/m/Y');
}

function tier_class(?string $name): string
{
    return match (mb_strtolower((string) $name)) {
        'vàng'      => 'gold',
        'kim cương' => 'diamond',
        default     => 'silver',
    };
}

function badge(string $class, string $label): string
{
    return '<span class="badge ' . e($class) . '">' . e($label) . '</span>';
}

function paw_icon(int $size = 22): string
{
    return '<svg class="icon" width="' . $size . '" height="' . $size . '" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">'
        . '<ellipse cx="5.5" cy="11" rx="2.1" ry="2.8"/><ellipse cx="18.5" cy="11" rx="2.1" ry="2.8"/>'
        . '<ellipse cx="9.6" cy="5.8" rx="2.1" ry="2.8"/><ellipse cx="14.4" cy="5.8" rx="2.1" ry="2.8"/>'
        . '<path d="M12 11.2c-3.2 0-6 3.1-6 5.8 0 1.9 1.5 3 3.2 3 1 0 1.7-.5 2.8-.5s1.8.5 2.8.5c1.7 0 3.2-1.1 3.2-3 0-2.7-2.8-5.8-6-5.8z"/></svg>';
}

/** Bộ icon nét đơn giản (24x24, stroke). */
function icon(string $name, int $size = 18): string
{
    static $paths = [
        'home'     => '<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>',
        'users'    => '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
        'user'     => '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
        'scissors' => '<circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><line x1="20" y1="4" x2="8.12" y2="15.88"/><line x1="14.47" y1="14.48" x2="20" y2="20"/><line x1="8.12" y1="8.12" x2="12" y2="12"/>',
        'calendar' => '<rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>',
        'star'     => '<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>',
        'message'  => '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
        'gift'     => '<polyline points="20 12 20 22 4 22 4 12"/><rect x="2" y="7" width="20" height="5"/><line x1="12" y1="22" x2="12" y2="7"/><path d="M12 7H7.5a2.5 2.5 0 0 1 0-5C11 2 12 7 12 7z"/><path d="M12 7h4.5a2.5 2.5 0 0 0 0-5C13 2 12 7 12 7z"/>',
        'award'    => '<circle cx="12" cy="8" r="7"/><polyline points="8.21 13.89 7 23 12 20 17 23 15.79 13.88"/>',
        'list'     => '<line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/>',
        'logout'   => '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>',
        'search'   => '<circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>',
        'plus'     => '<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>',
        'edit'     => '<path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"/>',
        'trash'    => '<polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/>',
        'check'    => '<polyline points="20 6 9 17 4 12"/>',
        'x'        => '<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>',
        'eye'      => '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>',
        'eyeoff'   => '<path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/>',
        'lock'     => '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
        'unlock'   => '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 9.9-1"/>',
        'clock'    => '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
        'sliders'  => '<line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/><line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/><line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/><line x1="1" y1="14" x2="7" y2="14"/><line x1="9" y1="8" x2="15" y2="8"/><line x1="17" y1="16" x2="23" y2="16"/>',
        'send'     => '<line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>',
        'menu'     => '<line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/>',
        'back'     => '<line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/>',
        'droplet'  => '<path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z"/>',
        'smile'    => '<circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><line x1="9" y1="9" x2="9.01" y2="9"/><line x1="15" y1="9" x2="15.01" y2="9"/>',
        'heart'    => '<path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>',
        'phone'    => '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>',
        'pin'      => '<path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/>',
        'mail'     => '<path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/>',
        'shield'   => '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
        'chevdown' => '<polyline points="6 9 12 15 18 9"/>',
        'checkc'   => '<path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/>',
        'upload'   => '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/>',
    ];
    return '<svg class="icon" width="' . $size . '" height="' . $size . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" '
        . 'stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . ($paths[$name] ?? '') . '</svg>';
}


// ---------------------------------------------------------------------------
// Khu vực Client (khách hàng)
// ---------------------------------------------------------------------------

/** URL tới một route của khu vực khách hàng: url('services/3', ['q' => 'tắm']). */
function url(string $route = '', array $query = []): string
{
    $params = array_filter(['route' => $route] + $query, fn($v) => $v !== null && $v !== '');
    if (!$params) {
        return BASE_URL . '/';
    }
    return BASE_URL . '/index.php?' . str_replace('%2F', '/', http_build_query($params));
}

/** Tài nguyên dùng chung (css, js) nằm trong thư mục /assets. */
function asset(string $path): string
{
    return BASE_URL . '/assets/' . ltrim($path, '/');
}

/** Thông tin cửa hàng lấy từ config/config.php (mục 'shop'). */
function shop(string $key, $default = '')
{
    return Config::get('shop.' . $key, $default);
}

function tel_href(string $phone): string
{
    return 'tel:' . preg_replace('/[^0-9+]/', '', $phone);
}

/** Tên hiển thị công khai: "Nguyễn Minh Anh" -> "Minh Anh". */
function short_name(string $name): string
{
    $parts = preg_split('/\s+/u', trim($name));
    return count($parts) >= 3 ? implode(' ', array_slice($parts, -2)) : implode(' ', $parts);
}

/** 4.5 -> "4,5" */
function rating_text($avg): string
{
    return number_format((float) $avg, 1, ',', '.');
}

/** 4.80 -> "4,8" (bỏ số 0 thừa) */
function fmt_weight($weight): string
{
    if ($weight === null || $weight === '') {
        return '';
    }
    return str_replace('.', ',', rtrim(rtrim(number_format((float) $weight, 2, '.', ''), '0'), '.'));
}

/** Ảnh dịch vụ; chưa có ảnh thì dùng ô màu phẳng kèm biểu tượng theo loại dịch vụ. */
function service_art(array $service): string
{
    if (!empty($service['image'])) {
        return '<div class="art has-img"><img src="' . e(upload_url($service['image'])) . '" alt="' . e($service['name']) . '" loading="lazy"></div>';
    }
    $name = mb_strtolower((string) ($service['name'] ?? ''));
    $icon = match (true) {
        str_contains($name, 'khách sạn')                           => 'home',
        str_contains($name, 'cắt') || str_contains($name, 'tỉa')   => 'scissors',
        str_contains($name, 'răng')                                => 'smile',
        str_contains($name, 'spa')                                 => 'heart',
        str_contains($name, 'tắm') || str_contains($name, 'nhuộm') => 'droplet',
        default                                                    => 'star',
    };
    return '<div class="art tone-' . ((int) ($service['id'] ?? 0) % 6) . '" aria-hidden="true"><i class="b1"></i><i class="b2"></i>' . icon($icon, 60) . '</div>';
}

/** Ảnh đại diện của bé; chưa có ảnh thì hiện hình dấu chân. */
function pet_avatar(array $pet, string $class = 'pet-avatar'): string
{
    if (!empty($pet['avatar'])) {
        return '<img class="' . e($class) . '" src="' . e(upload_url($pet['avatar'], 'pets')) . '" alt="Ảnh của ' . e($pet['name']) . '" loading="lazy">';
    }
    return '<span class="' . e($class) . ' ph" aria-hidden="true">' . paw_icon(30) . '</span>';
}
