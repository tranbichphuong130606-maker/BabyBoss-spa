<?php
/** Front controller của khu vực Client (khách hàng) — mọi request ở thư mục gốc đều đi qua file này. */
require __DIR__ . '/app/bootstrap.php';

use App\Core\{Request, Router, View};

View::area('client');                                   // dùng giao diện trong app/Views/client
$router = new Router('App\\Controllers\\Client\\', 'home');
require BASE_PATH . '/config/routes.client.php';
$router->dispatch(Request::capture());
