# BabyBoss Pet Spa — Website đặt lịch spa thú cưng

Đề tài **"Xây dựng ứng dụng web bằng PHP OOP"**, gồm hai phần chạy trên cùng một mã nguồn, một CSDL và một phiên đăng nhập:

- **Phần 1 — Client**: khách hàng xem dịch vụ, quản lý thú cưng, đặt lịch, đánh giá, tích điểm, nhắn tin.
- **Phần 2 — Admin**: quản trị người dùng, dịch vụ, lịch đặt, đánh giá, tin nhắn, điểm thưởng.

Viết thuần PHP theo mô hình **MVC**, dùng **PDO + MySQL/MariaDB**, không cần Composer hay framework. Yêu cầu **PHP 8.0+** (XAMPP bản hiện tại là đủ).

## 1. Cài đặt nhanh (XAMPP)

1. Chép thư mục `babyboss/` vào `C:\xampp\htdocs\`, bật **Apache** và **MySQL** trong XAMPP Control Panel.
2. Mở phpMyAdmin → tab **Import** → chọn `database/babyboss.sql` → **Import** (tự tạo CSDL `babyboss`, bảng và dữ liệu mẫu).
3. Nếu MySQL có mật khẩu root, sửa mục `db` trong `config/config.php`.
4. Mở **http://localhost/babyboss/** (khách hàng) hoặc **http://localhost/babyboss/admin/** (quản trị).

| Vai trò | Email | Mật khẩu |
|---|---|---|
| Quản trị viên | `admin@babyboss.vn` | `Admin@123` |
| Khách hàng hạng Kim Cương (nhiều dữ liệu nhất) | `minhanh@example.com` | `Khach@123` |
| Khách hàng hạng Bạc | `giahuy@example.com` | `Khach@123` |
| Khách hàng bị khóa (thử chặn đăng nhập) | `ducthinh@example.com` | `Khach@123` |

Đặt thư mục tên khác vẫn chạy được vì đường dẫn gốc tự nhận diện. Khi triển khai thật hãy đặt `'debug' => false` trong `config/config.php`. Thông tin cửa hàng (hotline, địa chỉ, giờ làm việc) và quy tắc đặt lịch (khung giờ, đặt trước tối thiểu/tối đa) cũng chỉnh ở file này; dữ liệu hiện tại là **dữ liệu mẫu**, hãy thay bằng thông tin thật.

## 2. Chức năng đối chiếu đề cương

**Phần 1 — Client**

| Mục đề cương | Cài đặt |
|---|---|
| Đăng ký / đăng nhập / đăng xuất (`password_hash`, `password_verify`, `$_SESSION`) | `Client\AuthController`, `Auth` |
| Trang chủ: banner, giới thiệu, dịch vụ nổi bật; danh sách dịch vụ kèm ảnh, giá, thời gian | `HomeController`, `ServiceController` |
| Tìm kiếm + phân trang dịch vụ (`LIMIT`/`OFFSET`, 6 dịch vụ/trang); các trang Trang chủ, Dịch vụ, Giới thiệu | `ServiceController`, `PageController`, `Paginator` |
| Thú cưng của tôi: thêm / sửa / xóa; upload avatar (.jpg .png .webp, đổi tên `uniqid()`) | `PetController`, `ImageUploader` |
| Đặt lịch (bé nào → dịch vụ nào → ngày giờ), lưu `appointments` trạng thái "Chờ duyệt"; xem lịch sử và trạng thái | `BookingController`, `BookingService` |
| Đánh giá 1–5 sao + nhận xét sau khi lịch hoàn thành; điểm trung bình ở trang chi tiết dịch vụ | `Client\ReviewController`, `Review` |
| Hotline + tin nhắn (tự động trả lời, chờ admin phản hồi) | `ContactController`, `Message` |
| Ví điểm: tổng điểm, lịch sử tích/tiêu, hạng Bạc – Vàng – Kim Cương; 1 điểm = 1.000 ₫ giảm trực tiếp khi đặt lịch | `Client\LoyaltyController`, `LoyaltyService` |

**Phần 2 — Admin**

| Mục đề cương | Cài đặt |
|---|---|
| Đăng nhập quản trị + phân quyền (Middleware `role === 'admin'`) | `Admin\AuthController`, `AdminMiddleware` |
| Người dùng: xem, tìm kiếm, phân trang, khóa / mở khóa, xóa | `UserController` |
| Dịch vụ: thêm / sửa / xóa, upload ảnh vào `uploads/`, tìm kiếm, phân trang | `ServiceController` |
| Lịch đặt: duyệt / hoàn thành / hủy, tìm theo tên khách hoặc ngày | `AppointmentController`, `AppointmentService` |
| Dashboard: tổng khách hàng, thú cưng, lịch chờ duyệt trong ngày | `DashboardController` |
| Đánh giá: Ẩn / Hiện / Xóa · Trả lời tin nhắn của khách | `ReviewController`, `MessageController` |
| Điểm thưởng: cộng / trừ / đặt lại điểm, lịch sử giao dịch, cấu hình tỷ lệ 1–5% và ngưỡng hạng | `LoyaltyController` |

## 3. Hai phần được ghép với nhau thế nào

Hạ tầng dùng chung: `app/bootstrap.php` (autoload, cấu hình, session, xử lý lỗi), `Router`, `View`, `Controller` và bộ model/service. Mỗi khu vực có front controller riêng (`index.php` cho Client, `admin/index.php` cho Admin), bảng route riêng, controller và giao diện riêng; hai khu vực cùng dùng `assets/css/base.css` để giao diện nhất quán. Dữ liệu chảy qua lại như sau:

| Khách làm | Admin thấy / làm | Kết quả với khách |
|---|---|---|
| Đặt lịch, có thể dùng điểm | Lịch xuất hiện ở **Lịch đặt spa** (Chờ duyệt), Dashboard đếm lịch chờ duyệt hôm nay | Trạng thái lịch cập nhật khi admin duyệt / hủy |
| — | Bấm **Hoàn thành** | Khách được cộng điểm, hạng tự nâng, hiện ở **Điểm thưởng**, và đánh giá được lịch đó |
| Gửi đánh giá | Kiểm duyệt ở **Đánh giá** (Ẩn / Hiện / Xóa) | Đánh giá bị ẩn biến mất khỏi trang dịch vụ và điểm trung bình |
| Nhắn tin (có tự động trả lời) | Trả lời ở **Tin nhắn** | Khách thấy phản hồi ngay trong trang **Liên hệ** |
| — | Khóa tài khoản | Khách không đăng nhập được, nếu đang đăng nhập thì bị đăng xuất ở lần bấm kế tiếp |
| — | Thêm / sửa / tạm ẩn dịch vụ, đổi tỷ lệ tích điểm | Trang dịch vụ và quy tắc điểm cập nhật ngay |

Phiên đăng nhập chung: sau khi đăng nhập chỉ lưu `$_SESSION['user_id']`; mỗi request, middleware đọc lại `role` và `status` từ CSDL. Admin đăng nhập ở form khách sẽ được chuyển sang khu quản trị; khách thường gõ đường dẫn admin sẽ bị chặn và đưa về trang chủ.

## 4. Cấu trúc thư mục

```
babyboss/
├── index.php                 Front controller khu vực Client
├── admin/index.php           Front controller khu vực Admin (+ admin/assets/)
├── assets/                   css/base.css (dùng chung), css/site.css (Client), js/site.js
├── app/
│   ├── bootstrap.php         Autoload PSR-4, cấu hình, session, xử lý lỗi
│   ├── Core/                 Router, Request, View, Controller, ClientController, Model, Database,
│   │                         Auth, LoginThrottle, Csrf, Session, Paginator, ImageUploader, helpers.php
│   ├── Models/               User, Pet, Service, Appointment, Review, Message,
│   │                         MembershipTier, LoyaltyTransaction, Setting
│   ├── Services/             LoyaltyService, AppointmentService, BookingService (nghiệp vụ, dùng transaction)
│   ├── Middleware/           AdminMiddleware, CustomerMiddleware
│   ├── Controllers/Admin/    8 controller quản trị
│   ├── Controllers/Client/   9 controller khách hàng
│   └── Views/admin|client/   layout, partial và view từng trang
├── config/                   config.php, routes.admin.php, routes.client.php
├── database/babyboss.sql     Schema + dữ liệu mẫu
└── uploads/services|pets/    Ảnh tải lên (có .htaccess chặn chạy PHP)
```

Luồng một request: front controller → `bootstrap` → `Router` (kiểm tra CSRF với POST) → Middleware → Controller → Model / Service → View. URL dạng `index.php?route=services/3`, nên **không cần bật mod_rewrite**.

## 5. Quy tắc nghiệp vụ

- **Đặt lịch**: chọn bé của chính mình, dịch vụ đang hiển thị, khung giờ trong danh sách, cách hiện tại tối thiểu 60 phút và tối đa 60 ngày; một bé không đặt hai lịch cùng giờ. Lịch mới luôn ở trạng thái `pending`, giá được chụp lại tại thời điểm đặt.
- **Dùng điểm khi đặt lịch**: `giảm = số điểm × giá trị 1 điểm` (mặc định 1.000 ₫), không vượt số dư và không vượt giá dịch vụ; điểm bị trừ ngay trong cùng transaction và ghi vào lịch sử (`redeem`).
- **Luồng trạng thái**: `pending → confirmed → completed`, hoặc `pending/confirmed → cancelled`; `completed` và `cancelled` là trạng thái cuối. Khách chỉ tự hủy được lịch `pending` của chính mình và được hoàn điểm đã dùng.
- **Hoàn thành lịch** (một transaction): điểm cộng = `tổng tiền × tỷ lệ của hạng hiện tại ÷ 100 ÷ giá trị 1 điểm` (làm tròn xuống), cộng dồn tổng chi tiêu để xét lên hạng, ghi một dòng `earn` kèm mã lịch.
- **Đánh giá**: chỉ cho lịch `completed`, mỗi lịch một lần (ràng buộc `UNIQUE`); đánh giá bị ẩn không hiện và không tính vào điểm trung bình.
- **Tin nhắn**: mỗi khách một hội thoại; tin đầu tiên của mỗi lượt chờ nhận một tin tự động trả lời; tối đa 5 tin đang chờ phản hồi.
- **Xóa thú cưng** đang có lịch chờ duyệt / đã xác nhận, hoặc **xóa dịch vụ** đã có lịch đặt, bị từ chối (dịch vụ nên chuyển sang "Tạm ẩn").

## 6. Bảo mật đã áp dụng

PDO prepared statement thật · `password_hash` / `password_verify` · CSRF token cho mọi form POST · escape đầu ra bằng `e()` · `session_regenerate_id` khi đăng nhập · khóa form đăng nhập 5 phút sau 5 lần sai (riêng cho Client và Admin) · kiểm tra quyền sở hữu mọi hồ sơ thú cưng / lịch hẹn · upload kiểm tra đuôi file + MIME thật + `getimagesize`, đổi tên bằng `uniqid()` · `SELECT … FOR UPDATE` khi đặt lịch, đổi trạng thái và cộng / trừ điểm · "quay lại" chỉ chấp nhận Referer cùng máy chủ (chống open redirect) · `.htaccess` chặn truy cập trực tiếp `app/`, `config/`, `database/`.

## 7. Lưu ý

- Dữ liệu mẫu chưa có ảnh dịch vụ: trang khách hiển thị ô màu kèm biểu tượng thay thế. Hãy upload ảnh thật ở **Admin → Dịch vụ spa**.
- Phông chữ (Baloo 2, Be Vietnam Pro) tải từ Google Fonts; khi không có mạng giao diện dùng phông hệ thống.
- Hotline, địa chỉ, email trong `config/config.php` và nội dung trang Giới thiệu là nội dung mẫu.
